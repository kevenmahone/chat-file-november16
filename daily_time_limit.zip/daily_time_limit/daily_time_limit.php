<?php
if(!defined("IN_MYBB")) {
    die("Direct initialization of this file is not allowed.");
}

// -------------------------------------
// Plugin Info
// -------------------------------------
function daily_time_limit_info() {
    return [
        "name" => "Daily Time Limit",
        "description" => "Limits users to a set number of minutes per day on the forum and provides a /timeleft.php page to check remaining time.",
        "website" => "https://yourforum.com",
        "author" => "ChatGPT",
        "version" => "1.2",
        "compatibility" => "18*"
    ];
}

// -------------------------------------
// Activate: create table + settings
// -------------------------------------
function daily_time_limit_activate() {
    global $db;

    // Create tracking table if needed
    if(!$db->table_exists("daily_time_limit")) {
        $db->write_query("
            CREATE TABLE `" . TABLE_PREFIX . "daily_time_limit` (
                `uid` int(10) unsigned NOT NULL,
                `date` date NOT NULL,
                `seconds` int(10) unsigned NOT NULL DEFAULT 0,
                PRIMARY KEY (`uid`, `date`)
            ) ENGINE=MyISAM DEFAULT CHARSET=utf8;
        ");
    }

    // Settings group
    $query = $db->simple_select("settinggroups", "gid", "name='daily_time_limit'");
    $group = $db->fetch_array($query);

    if(!$group) {
        $setting_group = [
            "name" => "daily_time_limit",
            "title" => "Daily Time Limit Settings",
            "description" => "Settings for the Daily Time Limit plugin.",
            "disporder" => 50,
            "isdefault" => 0
        ];
        $gid = $db->insert_query("settinggroups", $setting_group);
    } else {
        $gid = $group['gid'];
    }

    // Time limit setting
    $setting = [
        "name" => "daily_time_limit_minutes",
        "title" => "Daily Time Limit (in minutes)",
        "description" => "Maximum number of minutes each user is allowed per day.",
        "optionscode" => "text",
        "value" => "60",
        "disporder" => 1,
        "gid" => $gid
    ];
    $db->insert_query("settings", $setting);

    // Exempt groups
    $setting = [
        "name" => "daily_time_limit_exempt_groups",
        "title" => "Exempt Usergroups",
        "description" => "Comma-separated list of group IDs that are not restricted (e.g. 3,4 for admins and mods).",
        "optionscode" => "text",
        "value" => "3,4",
        "disporder" => 2,
        "gid" => $gid
    ];
    $db->insert_query("settings", $setting);

    rebuild_settings();
}

// -------------------------------------
// Deactivate: keep data & settings
// -------------------------------------
function daily_time_limit_deactivate() {
    // Keep table and settings intact
}

// -------------------------------------
// Enforce daily time limit
// -------------------------------------
$plugins->add_hook("global_start", "daily_time_limit_check");

function daily_time_limit_check() {
    global $mybb, $db;

    if(!$mybb->user['uid']) return; // Skip guests

    $limit_minutes = (int)$mybb->settings['daily_time_limit_minutes'];
    $exempt_groups = array_map('trim', explode(',', $mybb->settings['daily_time_limit_exempt_groups']));

    if($mybb->usergroup['cancp'] || $mybb->usergroup['issupermod'] || in_array($mybb->user['usergroup'], $exempt_groups)) {
        return; // Skip exempt groups
    }

    $uid = (int)$mybb->user['uid'];
    $today = date('Y-m-d');

    // Fetch record
    $query = $db->simple_select("daily_time_limit", "seconds", "uid='{$uid}' AND date='{$today}'");
    $record = $db->fetch_array($query);

    $last_activity = (int)$mybb->user['lastactive'];
    $now = TIME_NOW;
    $elapsed = $now - $last_activity;
    if($elapsed > 300) $elapsed = 300; // 5-min cap

    if($record) {
        $new_time = $record['seconds'] + $elapsed;
        $db->update_query("daily_time_limit", ["seconds" => $new_time], "uid='{$uid}' AND date='{$today}'");
    } else {
        $db->insert_query("daily_time_limit", [
            "uid" => $uid,
            "date" => $today,
            "seconds" => $elapsed
        ]);
        $new_time = $elapsed;
    }

    $limit_seconds = $limit_minutes * 60;

    if($new_time >= $limit_seconds) {
        error("Come back later — you have reached your {$limit_minutes} minutes allowed for today.");
        exit;
    }
}
?>
