<?php
define("IN_MYBB", 1);
require "./global.php";

global $db, $mybb, $header, $footer, $theme, $templates;

add_breadcrumb("Daily Time Left", "timeleft.php");

if(!$mybb->user['uid']) {
    error("You must be logged in to view your time usage.");
}

$limit_minutes = (int)$mybb->settings['daily_time_limit_minutes'];
$exempt_groups = array_map('trim', explode(',', $mybb->settings['daily_time_limit_exempt_groups']));

if($mybb->usergroup['cancp'] || $mybb->usergroup['issupermod'] || in_array($mybb->user['usergroup'], $exempt_groups)) {
    eval("\$page = \"".$templates->get("error")."\";");
    output_page("<div class='trow1' style='padding:20px;'>You are not restricted by the daily time limit.</div>");
    exit;
}

$uid = (int)$mybb->user['uid'];
$today = date('Y-m-d');
$query = $db->simple_select("daily_time_limit", "seconds", "uid='{$uid}' AND date='{$today}'");
$record = $db->fetch_array($query);

$used_seconds = (int)$record['seconds'];
$limit_seconds = $limit_minutes * 60;
$remaining_seconds = max(0, $limit_seconds - $used_seconds);
$remaining_minutes = floor($remaining_seconds / 60);

$message = "You have <strong>{$remaining_minutes} minutes</strong> remaining of your allowed daily forum time.";

eval("\$page = \"".$templates->get("error")."\";");
output_page("<div class='trow1' style='padding:20px;text-align:center;font-size:18px;'>{$message}</div>");
?>
