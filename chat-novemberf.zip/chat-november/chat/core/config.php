<?php

function load_config (): void
{
	mb_internal_encoding('UTF-8');
	define('VERSION', '1.24.6'); 	// Script version
	define('MAJOR', 2);				// Major release
	define('SUBREL', 48);			// Subrelease number
	define('DBVERSION', 60); 		// Database layout version
	define('CONF_INCLUDE', 1); 		// To avoid some one to open the file to include

	require_once dirname(__FILE__).'/chat-conf.php';

	if (MSGENCRYPTED){
		if (version_compare(PHP_VERSION, '7.2.0') < 0) {
			die ("You need at least PHP >= 7.2.x");
		}
		//Do not touch: Compute real keys needed by encryption functions
		if (strlen(ENCRYPTKEY_PASS) !== SODIUM_CRYPTO_AEAD_AES256GCM_KEYBYTES) {
			define('ENCRYPTKEY', substr(hash("sha512/256",ENCRYPTKEY_PASS),0, SODIUM_CRYPTO_AEAD_AES256GCM_KEYBYTES));
		} else {
			define('ENCRYPTKEY', ENCRYPTKEY_PASS);
		}
		if (strlen(AES_IV_PASS) !== SODIUM_CRYPTO_AEAD_AES256GCM_NPUBBYTES) {
			define('AES_IV', substr(hash("sha512/256",AES_IV_PASS), 0, SODIUM_CRYPTO_AEAD_AES256GCM_NPUBBYTES));
		} else {
			define('AES_IV', AES_IV_PASS);
		}
	}
}

function set_default_tz (): void
{
	global $U;
	if (isset($U['tz'])) {
		date_default_timezone_set($U['tz']);
	} else {
		date_default_timezone_set(get_setting('defaulttz'));
	}
}

?>