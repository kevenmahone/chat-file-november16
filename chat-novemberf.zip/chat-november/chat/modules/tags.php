<?php

/*
 * in prepare_stylesheets()
 	// Default style for the admin Tag setting page
	if ($class === 'tags') {
		$styles['tags']  = $class .' table{margin-left:auto;margin-right:auto} ';
		$styles['tags'] .= 'table table{width:100%} ';
		$styles['tags'] .= 'table table td:nth-child(1){width:8em; font-weight:bold} '; // Tag ID
		$styles['tags'] .= 'table table td:nth-child(2){width:6em;} '; // DropDown
		$styles['tags'] .= 'table table td:nth-child(3){width:3em;} '; // ID
		$styles['tags'] .= 'table table td:nth-child(4){width:11em} '; // Text
		$styles['tags'] .= 'table table td:nth-child(5){width:16em} '; // Enh Text
		$styles['tags'] .= 'table table td:nth-child(6){width:5em} '; // Btn Change / Add
	}
 * somewhere after if ($class === 'filters') {
 * in route_setup()
 * somewhere in array $C['bool_settings']=[
 		'allow_emojis' 			=> _('Allow smiley\'s in messages'),
 * in send_admin()
 * find
 		$views=['sessions' => _('View active sessions'), 'filter' => _('Filter'), 'linkfilter' => _('Linkfilter'))];
 * replace it with :
 		$views=['sessions' => _('View active sessions'), 'filter' => _('Filter'), 'linkfilter' => _('Linkfilter'), 'tags' => _('Tags')];
 * in send_post()
 * to have a clean post frame a add a table who will embeb the existing table
	// Main table with 3 areas ( start 20% middle 60% end 20% )
	echo '<table><tr>';

	// Start area (for tag's & extra buttons)
	echo '<td width="20%">';
    if (get_setting('allow_tags')) {
		$only_one = get_setting('only_one_tag');

		echo form('post');
		echo hidden('postid', $U['postid']);	

		echo insert_tag_drop ( (bool) $only_one );
	} else {
		echo form('post');
		echo hidden('postid', $U['postid']);	
	}
	echo '</td>';

	// Middle area ( typing zone )
	echo '<td width="60%">';
	// here come the existing code for the post table
	// after </table> on end of existing post table
	echo '</td>';
	// End area ( post rules & room's )
	echo '<td width="20%">';
	echo </td>;
	echo </tr></table>';
	
 * in update_db()
 * where [XXX] is the next value to DBVERSION defined in load_config() change DBVERSION in load_config() to [XXX]
    if ($dboversion<[XXX]) {
 		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('allow_tags', '0');");
		$dbo->exec('INSERT INTO ' . PREFIX . "settings (setting,value) VALUES ('only_one_tag', '0');");
		$dbo->exec('CREATE TABLE ' . PREFIX . "tags (id $primary, tag_dropdown varchar(10) NOT NULL , tag_id smallint(4) NOT NULL , tag_text varchar(30) NOT NULL , tag_ehtext varchar(200) NOT NULL)$diskengine$charset;");
	}
 * in validate_input()
 * find : 	$message = apply_linkfilter($message);
 * add the following
	if ( $allow_tags ) {
		if ($only_one_tag) {

		} else {

		}
		$tags = apply_tags();
		if (!empty($tags)) {
			$message = $tags . $message;
		}
	}

 * in restore_backup()
 * just before : 	if(isset($_POST['members']) && isset($code['members'])){
 * add the following
	if(isset($_POST['tags']) && isset($code['tags'])) {
		$dbo->exec('DELETE FROM ' . PREFIX . 'tags;');
		$dbo->exec('ALTER TABLE ' . PREFIX . 'tags AUTO_INCREMENT=0;');
		$stmt=$dbo->prepare('INSERT INTO ' . PREFIX . 'tags (tag_dropdown, tag_id, tag_text, tag_ehtext) VALUES (?, ?, ?, ?);');
		foreach($code['tags'] as $tag){
			$stmt->execute([$tag['tag_dropdown'], $tag['tag_id'], $tag['tag_text'], $tag['tag_ehtext']]);
		}
		if(MEMCACHED){
			$memcached->delete(DBNAME . '-' . PREFIX . 'tags');
		}
	}
 * in send_backup()
 * just before : 	if(isset($_POST['members'])){
 * add the following
		if(isset($_POST['tags'])){
			$result=$dbo->query('SELECT * FROM ' . PREFIX . 'tags;');
			while($tags=$result->fetch(PDO::FETCH_ASSOC)){
				$code['tags'][]=['tag_dropdown'=>$tags['tag_dropdown'], 'tag_id'=>$tags['tag_id'], 'tag_text'=>$tags['tag_text'], 'tag_ehtext'=>$tags['tag_ehtext']];
			}
		}
 * just before :	if(isset($_POST['members'])){
 * add the following
	if(isset($_POST['tags'])){
		$chktags=' checked';
	}else{
		$chktags='';
	}
 * just before : 	echo '<label><input type="checkbox" name="tags" id="backuptags" value="1"'.$chktags.'>'._('Tags').'</label>';
 * add the following line
		echo '<label><input type="checkbox" name="members" id="backupmembers" value="1"'.$chkmembers.'>'._('Members').'</label>';
 * just bedore :	echo '<label><input type="checkbox" name="members" id="restoremembers" value="1"'.$chkmembers.'>'._('Members').'</label>';
 * add the following line
		echo '<label><input type="checkbox" name="tags" id="restoretags" value="1"'.$chktags.'>'._('Tags').'</label>';
	
 * hope this time i dont have missed anything :)
*/

function apply_tags () : string
{
	$tagstring    ='';
	$allow_tags   = get_setting('allow_tags');
	$only_one_tag = get_setting('only_one_tag');

	if ($allow_tags) {

		if ($only_one_tag) {
			if (isset($_POST['tag_tag'])) {
				if ($_POST['tag_tag'] != "t_none") {
					$tagvalue = $_POST['tag_tag'];
					$atagid = explode('_', $tagvalue);
					$tag_id = (int) $atagid[1];
					$tag_tag = get_the_tag('tag_tag', $tag_id);
					if (!empty($tag_tag)) {
						$tagstring .= $tag_tag;
					}				
				}	
			}
		} else {
			if (isset($_POST['tag_age'])) {
				if ($_POST['tag_age'] != "a_none") {
					$tagvalue = $_POST['tag_age'];
					$atagid = explode('_', $tagvalue);
					$tag_id = (int) $atagid[1];
					$age_tag = get_the_tag('tag_age', $tag_id);
					if (!empty($age_tag)) {
						$tagstring .= $age_tag;
					}
				}
			}
			if (isset($_POST['tag_gen'])) {
				if ($_POST['tag_gen'] != "g_none") {
					$tagvalue = $_POST['tag_gen'];
					$atagid = explode('_', $tagvalue);
					$tag_id = (int) $atagid[1];
					$gen_tag = get_the_tag('tag_gen', $tag_id);				
					if (!empty($gen_tag)) {
						$tagstring .= $gen_tag;
					}
				}
			}
			if (isset($_POST['tag_act'])) {
				if ($_POST['tag_act'] != "ac_none") {
					$tagvalue = $_POST['tag_act'];
					$atagid = explode('_', $tagvalue);
					$tag_id = (int) $atagid[1];
					$act_tag = get_the_tag('tag_act', $tag_id);							
					if (!empty($act_tag)) {
						$tagstring .= $act_tag;
					}
				}
			}
		}
	}

	return $tagstring;
}

function insert_tag_drop ( bool $only_one ) : string
{
	$dropdowns  = '';
	if (!$only_one) {
		// Age dropdown
		$options[] = '';
		$options    = fill_tag_dropdown ('tag_age', false );
		$dropdowns .= '<td style="text-align:right">'._('Age').'</td><td style="text-align:left">';
		$dropdowns .= ': <select name="tag_age" size="1" style="width: 80%">';
		$dropdowns .= '<option selected value="a_none"> </option>';
		foreach ($options as $option) {
			$httag = $option['tag_text'];
			$value = sprintf ('a_%04d', (int) $option['tag_id']);
			$dropdowns .= '<option value="'.$value.'">'.$httag.'</option>';
		}
		$dropdowns .= '</select></td>';
		$dropdowns .= '</tr><tr>';
		// Sex dropdown
		$options[] = '';
		$options    = fill_tag_dropdown ('tag_gen', false );
		$dropdowns .= '<td style="text-align:right">'._('Gender').'</td><td style="text-align:left">';
		$dropdowns .= ': <select name="tag_gen" size="1" style="width: 80%">';
		$dropdowns .= '<option selected value="g_none"> </option>';
		foreach ($options as $option) {
			$httag = $option['tag_text'];
			$value = sprintf ('g_%04d', (int) $option['tag_id']);
			$dropdowns .= '<option value="'.$value.'">'.$httag.'</option>';
		}
		$dropdowns .= '</select></td>';
		$dropdowns .= '</tr><tr>';
		// Activity dropdown
		$options[] = '';
		$options    = fill_tag_dropdown ('tag_act', true );
		$dropdowns .= '<td style="text-align:right">'._('Activity').'</td><td style="text-align:left">';
		$dropdowns .= ': <select name="tag_act" size="1" style="width: 80%">';
		$dropdowns .= '<option selected value="ac_none"> </option>';
		foreach ($options as $option) {
			$httag = $option['tag_text'];
			$value = sprintf ('ac_%04d', (int) $option['tag_id']);
			$dropdowns .= '<option value="'.$value.'">'.$httag.'</option>';
		}
		$dropdowns .= '</select></td>';
	} else {
		// Tags dropdown
		$options[] = '';
		$options    = fill_tag_dropdown ('tag_tag', false );
		$dropdowns .= '<td style="text-align:right">'._('Tags').'</td><td style="text-align:left">';
		$dropdowns .= ': <select name="tag_tag" size="1" style="width: 80%">';
		$dropdowns .= '<option selected value="t_none"> </option>';
		foreach ($options as $option) {
			$httag = $option['tag_text'];
			$value = sprintf ('t_%04d', (int) $option['tag_id']);
			$dropdowns .= '<option value="'.$value.'">'.$httag.'</option>';
		}
		$dropdowns .= '</select></td>';
		$dropdowns .= '</tr><tr>';
		$dropdowns .= '<td></td>';
		$dropdowns .= '</tr><tr>';
		$dropdowns .= '<td></td>';
	}

	return $dropdowns;
}

function manage_tags () : string 
{
	global $dbo, $memcached;
	$error = '';
	if (isset($_POST['id'])) {
		if (isset($_POST['tag_drop']) && $_POST['tag_drop']==='tag_') {
			$error = _('Please select the dropdown box where to add this tag');
		} else {
			if (empty($_POST['tag_id'])) {
				$error = _('Please enter a tag ID to order this tag');
			} else {
				if (empty($_POST['tag_ehtext'])) {
					$error = _('Please fill also the enhance text for this tag');
				} else {
					if (preg_match('/^[0-9]+$/', $_POST['id'])) {
						if (empty($_POST['tag_text'])) {
							$stmt=$dbo->prepare('DELETE FROM ' . PREFIX . 'tags WHERE id=?;');
							$stmt->execute([$_POST['id']]);
							$error = _('Tag deleted from database');
						} else {
							$stmt=$dbo->prepare('UPDATE ' . PREFIX . 'tags SET tag_dropdown=?, tag_id=?, tag_text=?, tag_ehtext=? WHERE id=?;');
							$stmt->execute([$_POST['tag_drop'], $_POST['tag_id'], $_POST['tag_text'], $_POST['tag_ehtext'], $_POST['id']]);
							$error = _('Tag updated in database');
						}
					} elseif ($_POST['id']==='+') {
						$stmt=$dbo->prepare('INSERT INTO ' . PREFIX . 'tags (tag_dropdown, tag_id, tag_text, tag_ehtext) VALUES (?, ?, ?, ?);');
						$stmt->execute([$_POST['tag_drop'], $_POST['tag_id'], $_POST['tag_text'], $_POST['tag_ehtext']]);
						$error = _('Tag added to database');
					}
					if (MEMCACHED) {
						$memcached->delete(DBNAME . '-' . PREFIX . 'tags');
					}
				}
			}
		}
	}
	return $error;
}

function fill_tag_dropdown (string $witch, bool $ordered) : array
{
	global $dbo, $memcached;
	$tags = [];
	if (MEMCACHED) {
		$tags=$memcached->get(DBNAME . '-' . PREFIX . 'tags');
	}
	if (!MEMCACHED || $memcached->getResultCode()!==Memcached::RES_SUCCESS) {
		$tags = [];
		if ($ordered) {
			$result=$dbo->query('SELECT tag_id, tag_text  FROM ' . PREFIX . 'tags where tag_dropdown="'.$witch.'" ORDER BY tag_text ASC;');
		} else {
			$result=$dbo->query('SELECT tag_id, tag_text  FROM ' . PREFIX . 'tags where tag_dropdown="'.$witch.'";');
		}
		while ($tag=$result->fetch(PDO::FETCH_ASSOC)) {
			$tags[] = ['tag_id' => $tag['tag_id'], 'tag_text' => $tag['tag_text']];
		}
	}

	return $tags;
}

function get_the_tag ( string $drop, int $id ) : string
{
	global $dbo, $memcached;
	$the_tag = '';
	$result=$dbo->query('SELECT tag_id, tag_ehtext  FROM ' . PREFIX . 'tags where tag_dropdown="'.$drop.'" and tag_id="'.$id.'";');
	$tag=$result->fetch(PDO::FETCH_ASSOC);
	$the_tag=$tag['tag_ehtext'];

	return $the_tag;
}

function get_tags () : array 
{
	global $dbo, $memcached;
	$tags=[];
	if (MEMCACHED) {
		$tags=$memcached->get(DBNAME . '-' . PREFIX . 'tags');
	}
	if (!MEMCACHED || $memcached->getResultCode() !== Memcached::RES_SUCCESS) {
		$tags=[];
		$result=$dbo->query('SELECT * FROM ' . PREFIX . 'tags;');
		while($tag=$result->fetch(PDO::FETCH_ASSOC)){
			$tags[]=['id'=>$tag['id'], 'dropdown'=>$tag['tag_dropdown'], 'tag_id'=>$tag['tag_id'], 'text'=>$tag['tag_text'], 'ehtext'=>$tag['tag_ehtext']];
		}
		if (MEMCACHED) {
			$memcached->set(DBNAME . '-' . PREFIX . 'tags', $tags);
		}
	}
	return $tags;
}

function get_tagdropdowns (string $witch) : string 
{
    $result = '';

    $result  = '<select name="tag_drop" size="1" style="width: 80%">';
    $result .= '<option ';
    if($witch===''){
		$result .= 'selected ';
	}
    $result .= 'value="tag_"> </option><option ';
    if($witch==='tag_age'){
		$result .= 'selected ';
	}
    $result .= 'value="tag_age">Age</option><option ';
    if($witch==='tag_gen'){
		$result .= 'selected ';
	}
    $result .= 'value="tag_gen">Gender</option><option ';
    if($witch==='tag_act'){
		$result .= 'selected ';
	}
    $result .= 'value="tag_act">Activity</option><option ';
    if($witch==='tag_tag'){
		$result .= 'selected ';
	}
    $result .= 'value="tag_tag">Tags</option><option ';
    if($witch==='tag_spe'){
		$result .= 'selected ';
	}
    $result .= 'value="tag_spe">Special</option>';
    $result .= '</select>';

    return $result;
}

function send_tags (string $arg='') : void
{
	global $U;
	print_start('tags');
	echo '<h2>'._('Tags')."</h2><i>$arg</i><table>";
	thr();
	echo '<tr><th><table><tr>';
	echo '<td>'._('Tag ID').'</td>';
	echo '<td>'._('Drop').'</td>';
	echo '<td>'._('Id').'</td>';
	echo '<td>'._('Text').'</td>';
	echo '<td>'._('Enh Text').'</td>';
	echo '<td>'._('Apply').'</td>';
	echo '</tr></table></th></tr>';
	echo '<tr><td colspan="6"><hr></td></tr>';

    $tags=get_tags();
	foreach($tags as $tag){
		echo '<tr><td>';
		echo '<table><tr><td>';
		echo form('admin', 'tags').hidden('id', $tag['id']);
		echo ''. _('Tag'). " " .$tag['id']. ":</td>";
		echo '<td>' . get_tagdropdowns($tag['dropdown']) . '</td>';
        echo '<td><input type="text" name="tag_id" value="'.$tag['tag_id'].'" size="6" style="'.$U['style'].'"></td>';
		echo '<td><input type="text" name="tag_text" value="'.htmlspecialchars($tag['text']).'" size="15" style="'.$U['style'].'"></td>';
		echo '<td><input type="text" name="tag_ehtext" value="'.htmlspecialchars($tag['ehtext']).'" size="25" style="'.$U['style'].'"></td>';
		echo '<td class="tagsubmit">'.submit(_('Change')).'</td></tr></table></form></td></tr>';
	}
	echo '<tr><td colspan="6"><hr></td></tr>';
	echo '<tr><td>';
	echo form('admin', 'tags').hidden('id', '+');
	echo '<table><tr><td>'._('New').'</td>';
    echo '<td>' . get_tagdropdowns('') . '</td>';
    echo '<td><input type="text" name="tag_id"     size="6" style="'.$U['style'].'"></td>';
    echo '<td><input type="text" name="tag_text"   size="15" style="'.$U['style'].'"></td>';
    echo '<td><input type="text" name="tag_ehtext" size="25" style="'.$U['style'].'"></td>';
    echo '<td class="tagsubmit">'.submit(_('Add')).'</td></tr></table></form></td></tr>';
	echo '</td></tr>';
	echo '<tr><td colspan="6"><hr></td></tr>';
	echo '</table><br>';
	echo form('admin', 'tags').submit(_('Reload')).'</form>';
	echo '<br>';

	print_end();
}


?>