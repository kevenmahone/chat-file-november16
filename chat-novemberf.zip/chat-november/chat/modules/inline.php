<?php

function route_inline () : void
{
	global $U;

	if ($U['status'] < 2) {
		send_access_denied();
	}
	if (!isset($_POST['do'])) {
		return;
	} elseif ($_POST['do'] === 'delmsg') {
		if (isset($_POST['msg_id'])) {
			del_message_by_id ($_POST['msg_id']);
		}
	} elseif ($_POST['do'] === 'kick') {
		if (isset($_POST['poster'])) {
			$KickMessage   = _('You have been kicked by staff member, try to better follow the rules next time.');
			$KickedUser[]  = $_POST['poster'];
			kick_chatter ($KickedUser, $KickMessage, false);
		}
	} elseif ($_POST['do'] === 'purge') {
		if (isset($_POST['poster'])) {
			$KickMessage   = _('You have been kicked by staff member, try to better follow the rules next time.');
			$KickedUser[]  = $_POST['poster'];
			kick_chatter ($KickedUser, $KickMessage, true);
		}
    }
	send_messages();

}

function create_inline_menu ( array $message, string $filter, int $modroom) : string
{
    global $U;

    $InlineMenu     = '';
	$allowinline    = get_setting('allow_inline_commands');

    if ($allowinline) {
        if (($U['status'] >= 3 && $message['delstatus'] < $U['status']) || ($U['nickname'] == $message['poster']) ) {
            // Delete message button
            $InlineMenu .= '&nbsp;';
            $InlineMenu .= '<span class="inline-tool">';
            $InlineMenu .= form('inline', 'delmsg' );
            $InlineMenu .= hidden('msg_id', $message['id'] );
            $InlineMenu .= hidden('modroom', $modroom);
            if (!empty($filter)) {
                $InlineMenu .= hidden('sendto', $filter);
                $InlineMenu .= hidden('filter', $filter);
            }
            $InlineMenu .= submit('x', 'title="delete message" class="inline-tool-button"');
            $InlineMenu .= '</form></span>';
            // No kick or purge button in conversation mode
            if (empty($filter)) {
                if ($U['status'] >= 5 && $message['delstatus'] < $U['status']) {
                    // kick user button
                    $InlineMenu .= '&nbsp;';
                    $InlineMenu .= '<span class="inline-tool">';
                    $InlineMenu .= form('inline', 'kick' );
                    $InlineMenu .= hidden('modroom', $modroom);
                    $InlineMenu .= hidden('poster', $message['poster'] );
                    $InlineMenu .= submit('k', 'title="kick user" class="inline-tool-button"');
                    $InlineMenu .= '</form></span>&nbsp;';
                    // kick & purge message
                    $InlineMenu .= '&nbsp;';
                    $InlineMenu .= '<span class="inline-tool">';
                    $InlineMenu .= form('inline', 'purge' );
                    $InlineMenu .= hidden('modroom', $modroom);
                    $InlineMenu .= hidden('poster', $message['poster'] );
                    $InlineMenu .= submit('p', 'title="kick user and purge messages" class="inline-tool-button"');
                    $InlineMenu .= '</form></span>&nbsp;';
                }
            }
        }
        if (!empty($InlineMenu)) {
            $InlineMenu = '<nobr>' . $InlineMenu . '</nobr>';
        }
    }

    return $InlineMenu;
}

?>