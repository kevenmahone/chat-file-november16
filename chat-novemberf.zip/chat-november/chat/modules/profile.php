<?php

function send_profile (string $arg=''): void
{
	global $U, $dbo, $language;
	print_start('profile');
	echo form('profile', 'save').'<h2>'._('Your Profile')."</h2><i>$arg</i><table>";
	thr();
	$ignored=[];
	$stmt=$dbo->prepare('SELECT ign FROM ' . PREFIX . 'ignored WHERE ignby=? ORDER BY LOWER(ign);');
	$stmt->execute([$U['nickname']]);
	while($tmp=$stmt->fetch(PDO::FETCH_ASSOC)){
		$ignored[]=htmlspecialchars($tmp['ign']);
	}
	if(count($ignored)>0){
		echo '<tr><td><table id="unignore"><tr><th>'._("Don't ignore anymore").'</th><td>';
		echo '<select name="unignore" size="1"><option value="">'._('(choose)').'</option>';
		foreach($ignored as $ign){
			echo "<option value=\"$ign\">$ign</option>";
		}
		echo '</select></td></tr></table></td></tr>';
		thr();
	}
	echo '<tr><td><table id="ignore"><tr><th>'._('Ignore').'</th><td>';
	echo '<select name="ignore" size="1"><option value="">'._('(choose)').'</option>';
	$stmt=$dbo->prepare('SELECT DISTINCT poster, style FROM ' . PREFIX . 'messages INNER JOIN (SELECT nickname, style FROM ' . PREFIX . 'sessions UNION SELECT nickname, style FROM ' . PREFIX . 'members) AS t ON (' . PREFIX . 'messages.poster=t.nickname) WHERE poster!=? AND poster NOT IN (SELECT ign FROM ' . PREFIX . 'ignored WHERE ignby=?) ORDER BY LOWER(poster);');
	$stmt->execute([$U['nickname'], $U['nickname']]);
	while($nick=$stmt->fetch(PDO::FETCH_NUM)){
		echo '<option value="'.htmlspecialchars($nick[0])."\" style=\"$nick[1]\">".htmlspecialchars($nick[0]).'</option>';
	}
	echo '</select></td></tr></table></td></tr>';
	thr();
	$max_refresh_rate = get_setting('max_refresh_rate');
	$min_refresh_rate = get_setting('min_refresh_rate');
	echo '<tr><td><table id="refresh"><tr><th>'.sprintf(_('Refresh rate (%1$d-%2$d seconds)'), $min_refresh_rate, $max_refresh_rate).'</th><td>';
	echo '<input type="number" name="refresh" size="3" min="'.$min_refresh_rate.'" max="'.$max_refresh_rate.'" value="'.$U['refresh'].'"></td></tr></table></td></tr>';
	thr();
	preg_match('/#([0-9a-f]{6})/i', $U['style'], $matches);
	echo '<tr><td><table id="colour"><tr><th>'._('Font colour')." (<a href=\"$_SERVER[SCRIPT_NAME]?action=colours&amp;session=$U[session]&amp;lang=$language\" target=\"view\">"._('View examples').'</a>)</th><td>';
	echo "<input type=\"color\" value=\"#$matches[1]\" name=\"colour\"></td></tr></table></td></tr>";
	thr();
	echo '<tr><td><table id="bgcolour"><tr><th>'._('Background colour')." (<a href=\"$_SERVER[SCRIPT_NAME]?action=colours&amp;session=$U[session]&amp;lang=$language\" target=\"view\">"._('View examples').'</a>)</th><td>';
	echo "<input type=\"color\" value=\"#$U[bgcolour]\" name=\"bgcolour\"></td></tr></table></td></tr>";
	thr();
	if($U['status']>=3){
		echo '<tr><td><table id="font"><tr><th>'._('Fontface').'</th><td><table>';
		echo '<tr><td>&nbsp;</td><td><select name="font" size="1"><option value="">* '._('Room Default').' *</option>';
		$F=load_fonts();
		foreach($F as $name=>$font){
			echo "<option style=\"$font\" ";
			if(strpos($U['style'], $font)!==false){
				echo 'selected ';
			}
			echo "value=\"$name\">$name</option>";
		}
		echo '</select></td><td>&nbsp;</td><td><label><input type="checkbox" name="bold" id="bold" value="on"';
		if(strpos($U['style'], 'font-weight:bold;')!==false){
			echo ' checked';
		}
		echo '><b>'._('Bold').'</b></label></td><td>&nbsp;</td><td><label><input type="checkbox" name="italic" id="italic" value="on"';
		if(strpos($U['style'], 'font-style:italic;')!==false){
			echo ' checked';
		}
		echo '><i>'._('Italic').'</i></label></td><td>&nbsp;</td><td><label><input type="checkbox" name="small" id="small" value="on"';
		if(strpos($U['style'], 'font-size:smaller;')!==false){
			echo ' checked';
		}
		echo '><small>'._('Small').'</small></label></td></tr></table></td></tr></table></td></tr>';
		thr();
	}
	echo '<tr><td>'.style_this(htmlspecialchars($U['nickname'])." : "._('Example for your chosen font'), $U['style']).'</td></tr>';
	thr();
	if($U['status']>=3 && get_setting('hide_sys_mess')){
		echo "<tr><td><table id=\"hide_sysmess\"><tr><th>"._('Hide system message when enter or leave the chat').'</th><td>';
		echo "<label><input type=\"checkbox\" name=\"hide_sysmess\" value=\"on\"";
		if($U['hide_sysmess']){
			echo ' checked';
		}
		echo '><b>'._('Enabled').'</b></label></td></tr></table></td></tr>';
		thr();
	}
	if($U['status']>=3 && get_setting('user_sys_mess')){
		$UserEntry = '';
		$UserExit  = '';
		if (empty($U['user_entry'])) {
			$UserEntry = htmlspecialchars(str_replace('%s ', '', get_setting('msgenter')));
		} else {
			$UserMess  = stripslashes($U['user_entry']);
			$UserEntry = str_replace('%s ', '', $UserMess);
		}
		if (empty($U['user_exit'])) {
			$UserExit = htmlspecialchars(str_replace('%s ', '', get_setting('msgexit')));
		} else {
			$UserMess = stripslashes($U['user_exit']);
			$UserExit = str_replace('%s ', '', $UserMess);
		}
		echo "<tr><td><table id=\"user_entry\"><tr><th>"._('User entry message').'</th><td><input type="text" name="user_entry" value="'.$UserEntry.'" size="30"></td></tr></table></td></tr>';
		echo "<tr><td><table id=\"user_exit\"><tr><th>"._('User exit message').'</th><td><input type="text" name="user_exit" value="'.$UserExit.'" size="30"></td></tr></table></td></tr>';
		thr();
	}
	if ($U['status']>=2 && get_setting('allow_avatars')) {
		$UserCaption = htmlspecialchars(str_replace('%s ', '', $U['user_caption']));
		if (empty($U['user_caption'])) {
			$UserCaption = htmlspecialchars( _('Friend') );
		} else {
			$UserMess    = stripslashes($U['user_caption']);
			$UserCaption = htmlspecialchars(str_replace('%s ', '', $UserMess));
		}
		echo "<tr><td><table id=\"user_caption\"><tr><th>"._('User caption').'</th><td><input type="text" name="user_caption" value="'.$UserCaption.'" size="30"></td></tr></table></td></tr>';
		thr();
	}
	$bool_settings=[
		'timestamps' 	=> _('Show Timestamps'),
		'nocache' 		=> _('Autoscroll (for old browsers or top-to-bottom sort).'),
		'sortupdown' 	=> _('Sort messages from top to bottom'),
		'hidechatters' 	=> _('Hide list of chatters'),
	];
	if (get_setting('imgembed')) {
		$bool_settings['embed'] = _('Embed images');
	}
	if ($U['status'] >= 3 && get_setting('allow_conv_mode')) {
		$bool_settings['conv_mode'] = _('Use conversation mode when clicking a nick in chatter list');
	}
	if ($U['status'] >= 5 && get_setting('incognito')) {
		$bool_settings['incognito'] = _('Incognito mode');
	}
	foreach($bool_settings as $setting => $title){
		echo "<tr><td><table id=\"$setting\"><tr><th>".$title.'</th><td>';
		echo "<label><input type=\"checkbox\" name=\"$setting\" value=\"on\"";
		if($U[$setting]){
			echo ' checked';
		}
		echo '><b>'._('Enabled').'</b></label></td></tr></table></td></tr>';
		thr();
	}
	if($U['status']>=2 && get_setting('eninbox')){
		echo '<tr><td><table id="eninbox"><tr><th>'._('Enable offline inbox').'</th><td>';
		echo '<select name="eninbox" id="eninbox">';
		echo '<option value="0"';
		if($U['eninbox']==0){
			echo ' selected';
		}
		echo '>'._('Disabled').'</option>';
		echo '<option value="1"';
		if($U['eninbox']==1){
			echo ' selected';
		}
		echo '>'._('For everyone').'</option>';
		echo '<option value="3"';
		if($U['eninbox']==3){
			echo ' selected';
		}
		echo '>'._('For members only').'</option>';
		echo '<option value="5"';
		if($U['eninbox']==5){
			echo ' selected';
		}
		echo '>'._('For staff only').'</option>';
		echo '</select></td></tr></table></td></tr>';
		thr();
	}
	echo '<tr><td><table id="tz"><tr><th>'._('Time zone').'</th><td>';
	echo '<select name="tz">';
	$tzs=timezone_identifiers_list();
	foreach($tzs as $tz){
		echo "<option value=\"$tz\"";
		if($U['tz']==$tz){
			echo ' selected';
		}
		echo ">$tz</option>";
	}
	echo '</select></td></tr></table></td></tr>';
	thr();
	if($U['status'] >= 2) {
		echo '<tr><td><table id="changepass"><tr><th>'._('Change Password').'</th></tr>';
		echo '<tr><td><table>';
		echo '<tr><td>&nbsp;</td><td>'._('Old password:').'</td><td><input type="password" name="oldpass" size="20" autocomplete="current-password"></td></tr>';
		echo '<tr><td>&nbsp;</td><td>'._('New password:').'</td><td><input type="password" name="newpass" size="20" autocomplete="new-password"></td></tr>';
		echo '<tr><td>&nbsp;</td><td>'._('Confirm new password:').'</td><td><input type="password" name="confirmpass" size="20" autocomplete="new-password"></td></tr>';
		echo '</table></td></tr></table></td></tr>';
		thr();
	}
	if ($U['status'] >= 3) {
		if (get_setting('allow_user_rename')) {
			echo '<tr><td><table id="changenick"><tr><th>'._('Change Nickname').'</th><td><table>';
			echo '<tr><td>&nbsp;</td><td>'._('New nickname:').'</td><td><input type="text" name="newnickname" size="20" autocomplete="username">';
			echo '</table></td></tr></table></td></tr>';
			thr();
		}
	}
	echo '<tr><td>'.submit(_('Save changes')).'</td></tr></table></form>';
	if($U['status']>1 && $U['status']<8){
		echo '<br>'.form('profile', 'delete').submit(_('Delete account'), 'class="delbutton"').'</form>';
	}
	echo '<br>';
	echo language_selector();
	echo '<br>'.form('view').submit(_('Back to the chat.'), 'class="backbutton"').'</form>';
	print_end();
}

function set_new_nickname () : string 
{
	global $U, $dbo;

	$_POST['newnickname'] = preg_replace('/\s/', '', $_POST['newnickname']);
	if (!valid_nick($_POST['newnickname'])) {
		return sprintf(_('Invalid nickname (%1$d characters maximum and has to match the regular expression "%2$s")'), get_setting('maxname'), get_setting('nickregex'));
	}
	$stmt	= $dbo->prepare('SELECT id FROM ' . PREFIX . 'sessions WHERE nickname=? UNION SELECT id FROM ' . PREFIX . 'members WHERE nickname=?;');
	$stmt->execute([$_POST['newnickname'], $_POST['newnickname']]);
	if ($stmt->fetch(PDO::FETCH_NUM)) {
		return _('Nickname is already taken');
	} else {
		// Make sure members can not read private messages of previous guests with the same name
		$stmt	= $dbo->prepare('UPDATE ' . PREFIX . 'messages SET poster = "" WHERE poster = ? AND poststatus = 9;');
		$stmt->execute([$_POST['newnickname']]);
		$stmt	= $dbo->prepare('UPDATE ' . PREFIX . 'messages SET recipient = "" WHERE recipient = ? AND poststatus = 9;');
		$stmt->execute([$_POST['newnickname']]);
		// change names in all tables
		$stmt	= $dbo->prepare('UPDATE ' . PREFIX . 'members SET nickname=? WHERE nickname=?;');
		$stmt->execute([$_POST['newnickname'], $U['nickname']]);
		$stmt	= $dbo->prepare('UPDATE ' . PREFIX . 'sessions SET nickname=? WHERE nickname=?;');
		$stmt->execute([$_POST['newnickname'], $U['nickname']]);
		$stmt	= $dbo->prepare('UPDATE ' . PREFIX . 'messages SET poster=? WHERE poster=?;');
		$stmt->execute([$_POST['newnickname'], $U['nickname']]);
		$stmt	= $dbo->prepare('UPDATE ' . PREFIX . 'messages SET recipient=? WHERE recipient=?;');
		$stmt->execute([$_POST['newnickname'], $U['nickname']]);
		$stmt	= $dbo->prepare('UPDATE ' . PREFIX . 'ignored SET ignby=? WHERE ignby=?;');
		$stmt->execute([$_POST['newnickname'], $U['nickname']]);
		$stmt	= $dbo->prepare('UPDATE ' . PREFIX . 'ignored SET ign=? WHERE ign=?;');
		$stmt->execute([$_POST['newnickname'], $U['nickname']]);
		$stmt	= $dbo->prepare('UPDATE ' . PREFIX . 'inbox SET poster=? WHERE poster=?;');
		$stmt->execute([$_POST['newnickname'], $U['nickname']]);
		$stmt	= $dbo->prepare('UPDATE ' . PREFIX . 'notes SET editedby=? WHERE editedby=?;');
		$stmt->execute([$_POST['newnickname'], $U['nickname']]);
		$U['nickname']	= $_POST['newnickname'];
	}
	return '';
}

function amend_profile (): void
{
	global $U;

    $maxrefresh		= get_setting('max_refresh_rate');
	if (isset($_POST['refresh'])) {
		$U['refresh']	 = $_POST['refresh'];
	}
	if ($U['refresh']	 < 5) {
		$U['refresh']	 = 5;
	} elseif ($U['refresh'] > $maxrefresh) {
		$U['refresh']	 = $maxrefresh;
	}
	if (preg_match('/^#([a-f0-9]{6})$/i', $_POST['colour'], $match)) {
		$colour			 = $match[1];
	} else {
		preg_match('/#([0-9a-f]{6})/i', $U['style'], $matches);
		$colour			 = $matches[1];
	}
	if (preg_match('/^#([a-f0-9]{6})$/i', $_POST['bgcolour'], $match)) {
		$U['bgcolour']	 = $match[1];
	}
	$U['style']		= "color:#$colour;";
	if ($U['status'] >= 3) {
		$F				 = load_fonts();
		if (isset($F[$_POST['font']])) {
			$U['style'] .= $F[$_POST['font']];
		}
		if (isset($_POST['small'])) {
			$U['style'] .= 'font-size:smaller;';
		}
		if (isset($_POST['italic'])) {
			$U['style'] .= 'font-style:italic;';
		}
		if (isset($_POST['bold'])) {
			$U['style'] .= 'font-weight:bold;';
		}
	}
	if ($U['status'] >= 3 && isset($_POST['user_entry']) && get_setting('user_sys_mess')) {
		$Entry 			 = addslashes($_POST['user_entry']);
		$U['user_entry'] = '%s '.$Entry;
	}
	if ($U['status']>=3 && isset($_POST['user_exit']) && get_setting('user_sys_mess')) {
		$Exit 			 = addslashes($_POST['user_exit']);
		$U['user_exit']  = '%s '.$Exit;
	}
	if ($U['status'] >= 2 && isset($_POST['user_caption'])) {
		$Caption 		 = addslashes($_POST['user_caption']);
		$U['user_caption'] = htmlspecialchars($Caption);
	}
	if ($U['status'] >= 3 && isset($_POST['hide_sysmess']) && get_setting('hide_sys_mess')){
		$U['hide_sysmess']= 1;
	} else {
		$U['hide_sysmess']= 0;
	}
	if ($U['status'] >= 3 && isset($_POST['conv_mode']) && get_setting('allow_conv_mode')){
		$U['conv_mode']= 1;
	} else {
		$U['conv_mode']= 0;
	}
	if ($U['status'] >= 5 && isset($_POST['incognito']) && get_setting('incognito')){
		$U['incognito']	 = 1;
	}else{
		$U['incognito']	 = 0;
	}
	if (isset($_POST['tz'])) {
		$tzs			 = timezone_identifiers_list();
		if (in_array($_POST['tz'], $tzs)) {
			$U['tz']	 = $_POST['tz'];
		}
	}
	if (isset($_POST['eninbox']) && $_POST['eninbox'] >= 0 && $_POST['eninbox'] <= 5) {
		$U['eninbox'] 	 = $_POST['eninbox'];
	}
	$bool_settings		 = ['timestamps', 'embed', 'nocache', 'sortupdown', 'hidechatters'];
	foreach ($bool_settings as $setting) {
		if (isset($_POST[$setting])) {
			$U[$setting] = 1;
		}else{
			$U[$setting] = 0;
		}
	}
}

function save_profile () : string 
{
	global $U, $dbo;
	
	amend_profile();
	$stmt	= $dbo->prepare('UPDATE ' . PREFIX . 'sessions SET refresh=?, style=?, bgcolour=?, timestamps=?, embed=?, incognito=?, nocache=?, tz=?, eninbox=?, sortupdown=?, hidechatters=?, hide_sysmess=?, user_entry=?, user_exit=?, user_caption=?, conv_mode=? WHERE session=?;');
	$stmt->execute([$U['refresh'], $U['style'], $U['bgcolour'], $U['timestamps'], $U['embed'], $U['incognito'], $U['nocache'], $U['tz'], $U['eninbox'], $U['sortupdown'], $U['hidechatters'], $U['hide_sysmess'], $U['user_entry'], $U['user_exit'], $U['user_caption'], $U['conv_mode'], $U['session']]);
	if ($U['status'] >= 2) {
		$stmt	= $dbo->prepare('UPDATE ' . PREFIX . 'members SET refresh=?, bgcolour=?, timestamps=?, embed=?, incognito=?, style=?, nocache=?, tz=?, eninbox=?, sortupdown=?, hidechatters=?, hide_sysmess=?, user_entry=?, user_exit=?, user_caption=?, conv_mode=?  WHERE nickname=?;');
		$stmt->execute([$U['refresh'], $U['bgcolour'], $U['timestamps'], $U['embed'], $U['incognito'], $U['style'], $U['nocache'], $U['tz'], $U['eninbox'], $U['sortupdown'], $U['hidechatters'], $U['hide_sysmess'], $U['user_entry'], $U['user_exit'], $U['user_caption'], $U['conv_mode'], $U['nickname']]);
	}
	if (!empty($_POST['unignore'])) {
		$stmt	= $dbo->prepare('DELETE FROM ' . PREFIX . 'ignored WHERE ign=? AND ignby=?;');
		$stmt->execute([$_POST['unignore'], $U['nickname']]);
	}
	if (!empty($_POST['ignore'])) {
		$stmt	= $dbo->prepare('SELECT null FROM ' . PREFIX . 'messages WHERE poster=? AND poster NOT IN (SELECT ign FROM ' . PREFIX . 'ignored WHERE ignby=?);');
		$stmt->execute([$_POST['ignore'], $U['nickname']]);
		if ($U['nickname'] !== $_POST['ignore'] && $stmt->fetch(PDO::FETCH_NUM)) {
			$stmt	= $dbo->prepare('INSERT INTO ' . PREFIX . 'ignored (ign, ignby) VALUES (?, ?);');
			$stmt->execute([$_POST['ignore'], $U['nickname']]);
		}
	}
	if ($U['status'] > 1 && !empty($_POST['newpass'])) {
		if (!valid_pass($_POST['newpass'])) {
			return sprintf(_('Invalid password (At least %1$d characters and has to match the regular expression "%2$s")'), get_setting('minpass'), get_setting('passregex'));
		}
		if (!isset($_POST['oldpass'])) {
			$_POST['oldpass']	= '';
		}
		if (!isset($_POST['confirmpass'])) {
			$_POST['confirmpass']	= '';
		}
		if ($_POST['newpass'] !== $_POST['confirmpass']) {
			return _('Password confirmation does not match!');
		} else {
			$U['newhash']	= password_hash($_POST['newpass'], PASSWORD_DEFAULT);
		}
		if (!password_verify($_POST['oldpass'], $U['passhash'])) {
			return _('Wrong Password!');
		}
		$U['passhash']	= $U['newhash'];
		$stmt	= $dbo->prepare('UPDATE ' . PREFIX . 'sessions SET passhash=? WHERE session=?;');
		$stmt->execute([$U['passhash'], $U['session']]);
		$stmt	= $dbo->prepare('UPDATE ' . PREFIX . 'members SET passhash=? WHERE nickname=?;');
		$stmt->execute([$U['passhash'], $U['nickname']]);
	}
	if (get_setting('allow_user_rename')) {
		if ($U['status'] > 1 && !empty($_POST['newnickname'])) {
			$msg	= set_new_nickname();
			if ($msg !== '') {
				return $msg;
			}
		}
	}
	return _('Your profile has successfully been saved.');
}

?>