<?php

// Move between rooms
function change_room () : string
{
	global $U, $dbo;
	if (isset($_POST['room'])) {
		// Back to Main Chat
		if ($_POST['room'] === '*') {
			// The room is gone return the user to Main Chat
			$stmt=$dbo->prepare('UPDATE ' . PREFIX . 'sessions SET roomid=NULL WHERE id = ?;');
			$stmt->execute([$U['id']]);
		} else {
			// Does the user have access to the room system ?
			if ($U['status'] >= (int)get_setting('roomaccess')) {
				// Get all room infos
				if ($_POST['room']=== '@') {
					$stmt	= $dbo->prepare('SELECT * FROM ' . PREFIX . 'rooms WHERE name = ?;');
					$Select	= $stmt->execute([$_POST['name']]);
				} else {
					$stmt	= $dbo->prepare('SELECT * FROM ' . PREFIX . 'rooms WHERE id = ?;');
					$Select	= $stmt->execute([$_POST['room']]);
				}
				$Select	= $stmt->fetch(PDO::FETCH_ASSOC);
				if ($Select !== false) {
					// Check if the user is the room creator
					if ($U['nickname'] != $Select['creator']) {
						// Check if room is password protected
						if (!empty($Select['password'])) {
							// There is a password for that room
							// Check if user entered a password to access that room
							if (isset($_POST['password'])) {
								// Check if user has given a wrong password
								if ($_POST['password'] != $Select['password']) {
									return _('Wrong password .. Try again');
								}
							} else {
								// User not given any password
								return _('Please enter the room password');
							}
						}
					} else {
						// As room creator no need to enter password
						// Room should also be displayed in the room combo @ Post
					}
					// There we go to an opened & present room
					$stmt = $dbo->prepare('UPDATE ' . PREFIX . 'sessions SET roomid = (SELECT id FROM ' . PREFIX . 'rooms WHERE id = ? AND access <= ?) WHERE id = ?;');
					$stmt->execute([$Select['id'],$U['status'], $U['id']]);
				} else {
					return _('Room selection error !');
				}
			}
		}
	}
	return '';
}

// Print the room's table to the post box
function print_rooms()
{
	global $dbo, $U;
	echo '<table id="roomtable"><tbody>';
	echo '<tr><td>';
	echo _('Rooms :');
	echo '</td></tr>';
	echo '<tr><td>';
	echo form_target('view', 'view');
	echo '<select name="room"  style="width: 70%">';
	echo '<option title="messages & pm" value="*">[Main Chat]</option>';
	$stmt = $dbo->prepare('SELECT * FROM ' . PREFIX . 'rooms WHERE access <= ? ORDER BY id ASC;');
	$stmt->execute([$U['status']]);
	if (!$rooms = $stmt->fetchAll(PDO::FETCH_ASSOC)) {
		$rooms = [];
	}
	foreach ($rooms as $room) {
		$stmt = $dbo->prepare('SELECT id FROM ' . PREFIX . 'sessions WHERE roomid = ?;');
		$stmt->execute([$room['id']]);
		$num = count($stmt->fetchAll());
		if ($room['type'] == 0 || $U['nickname'] == $room['creator']) {
			if ($room['display'] == 0) {
				echo '<option title="messages & pm" value="'.$room['id'].'"';
	
			} elseif ($room['display'] == 1) {
				echo '<option title="messages only" value="'.$room['id'].'"';
	
			} elseif ($room['display'] == 2) {
				echo '<option title="pm only" value="'.$room['id'].'"';
			}
			if ($U['roomid'] === $room['id']) {
				echo ' selected';
			}
			echo '>'.$room['name'].' ('.$num.')</option>';
		}
	}
	echo '</select>'.submit('Switch').'</form>';
	echo '</td></tr>';
	echo '</tody></table>';
}

// Room access level text's
function get_room_acces_text (int $iLevel) : string
{
	$sReturn = '';

	if ($iLevel == 1) {
		$sReturn .= 'Guests';
	} elseif ($iLevel == 2) {
		$sReturn .= 'Friends';
	} elseif ($iLevel == 3) {
		$sReturn .= 'Members';
	} elseif ($iLevel == 5) {
		$sReturn .= 'Moderators';
	} elseif ($iLevel == 6) {
		$sReturn .= 'Super Mods';
	} elseif ($iLevel == 7) {
		$sReturn .= 'Admins';
	} elseif ($iLevel == 8) {
		$sReturn .= 'SNR Admins';
	} elseif ($iLevel == 10) {
		$sReturn .= 'Disabled';
	}

	return $sReturn;
}

// Room acces dropdown box for room admin
function build_room_acces_dropdown ($status, $access='') : string 
{

	$options	= array(1, 2, 3, 5, 6, 7, 8, 10);
	$HtlmCombo	= '<td><select name="access">';

	foreach ($options as $option) {
		if ($status < $option) {
			break;
		}
		if ($option >= get_setting('roomaccess')) {
			$HtlmCombo .= '<option value="'.$option.'"';
			if ($access != '') {
				if ($access == $option) {
					$HtlmCombo .= ' selected';
				}
			}
			$HtlmCombo .= '>'.get_room_acces_text ($option).'</option>';
		}
	}
	$HtlmCombo .= '</select></td>';

	return $HtlmCombo;
}

// Room access level text's
function get_room_type_text (int $iLevel) : string
{
	$sReturn = '';

	if ($iLevel == 0) {
		$sReturn .= 'Visible';
	} elseif ($iLevel == 1) {
		$sReturn .= 'Hidden';
	}

	return $sReturn;
}

// Room type dropdown box for room admin
function build_room_type_dropdown ($type=0) : string
{
	$options	= array(0, 1);
	$HtlmCombo	= '<td><select name="type">';

	foreach ($options as $option) {
		$HtlmCombo .= '<option value="'.$option.'"';
		if ($type == $option) {
			$HtlmCombo .= ' selected';
		}
		$HtlmCombo .= '>'.get_room_type_text ($option).'</option>';
	}
	$HtlmCombo .= '</select></td>';
	return $HtlmCombo;
}

// Room access level text's
function get_room_display_text (int $iLevel) : string
{
	$sReturn = '';

	if ($iLevel == 0) {
		$sReturn .= 'Message & Pm';
	} elseif ($iLevel == 1) {
		$sReturn .= 'Message only';
	} elseif ($iLevel == 2) {
		$sReturn .= 'Pm only';
	}

	return $sReturn;
}

// Room display dropdown for room admin
function build_room_display_dropdown ($type=0) : string
{
	$options	= array(0, 1, 2);
	$HtlmCombo	= '<td><select name="display">';

	foreach ($options as $option) {
		$HtlmCombo .= '<option value="'.$option.'"';
		if ($type == $option) {
			$HtlmCombo .= ' selected';
		}
		$HtlmCombo .= '>'.get_room_display_text ($option).'</option>';
	}
	$HtlmCombo .= '</select></td>';
	return $HtlmCombo;
}

// Room retrieve from db
// $UserStatus 		-> The user status to selection only room where the user have access to
// $OnlyVisible 	-> true only select rooms with type is Visible
function get_rooms (int $UserStatus, bool $OnlyVisible = false) : array
{
	global $dbo;

	$aRoom = [];
	if ($OnlyVisible == false) {
		$stmt = $dbo->prepare('SELECT * FROM ' . PREFIX . 'rooms WHERE access <= ? ORDER BY id ASC;');
	} else {
		$stmt = $dbo->prepare('SELECT * FROM ' . PREFIX . 'rooms WHERE access <= ? AND type = 0 ORDER BY id ASC;');
	}
	$stmt->execute([$UserStatus]);
	if (!$aRoom = $stmt->fetchAll(PDO::FETCH_ASSOC)) {
		$aRoom = [];
	}


	return $aRoom;
}

function get_rooms_count (bool $UserRoom=false) : int
{
	global $dbo;

	if ($UserRoom == false) {
		$RoomCount = $dbo->query('SELECT COUNT(*) FROM ' . PREFIX . 'rooms WHERE permanent = 1 AND type = 0')->fetch(PDO::FETCH_NUM);
	} else {
		$RoomCount = $dbo->query('SELECT COUNT(*) FROM ' . PREFIX . 'rooms WHERE permanent = 0 AND type = 0')->fetch(PDO::FETCH_NUM);
	}

	return (int) $RoomCount[0];
}

function get_room_by_id (int $id) : array 
{
	global $dbo;

	$aResult = [];
	$stmt = $dbo->prepare('SELECT * FROM ' . PREFIX . 'rooms WHERE id = ?;');
	$stmt->execute([$id]);
	if (!$aResult = $stmt->fetchAll(PDO::FETCH_ASSOC)) {
		$aResult = [];
	}
	return $aResult[0];
}

// Admin room page
function send_rooms ($arg='')
{
	global $U, $dbo;

	print_start('roomadmin');
	echo '<h2>'._('Chat Rooms').'</h2><i>'.$arg.'</i>';

	echo '<table>';
	thr();
	echo '<tr>';
	show_room_table_header ( true );
	echo '</tr>';

	thr();

	if (!$rooms = get_rooms ($U['status'])) {
		$rooms = [];
	}

	foreach ($rooms as $room) {
		$checkedlink = $checkedpm = '';
		$expire 	 = (int) get_setting('roomexpire');
		$roomexpire	 = get_timeout($room['time'], $expire);

		if ($room['permanent'] && $U['status'] <= 6) {
			continue;
		}
		if ($room['permanent']) {
			$checkedpm		= ' checked';
		}
		if ($room['withlink']) {
			$checkedlink	= ' checked';
		}
		echo '<tr><td>';
		echo form('admin', 'rooms').hidden('id', $room['id']);
		if ($U['nickname'] == $room['creator'] || $U['status'] >= 6) {
			echo '<table><tr>';
			echo '<td>'.('Room ').$room['id'].':</td>';
			echo '<td><input type="text" name="name" value="'.$room['name'].'" size="20" style="'.$U['style'].'"></td>';
			if ($U['status'] > 7) {
				echo '<td><input type="text" name="password" value="'.$room['password'].'" size="20" style="'.$U['style'].'"></td>';
			} else {
				echo '<td><input type="password" name="password" value="'.$room['password'].'" size="20" style="'.$U['style'].'"></td>';
			}
			echo build_room_acces_dropdown ($U['status'], $room['access']);
			if ($U['status'] > 6) {
				echo '<td><label><input type="checkbox" name="permanent" value="1"'.$checkedpm.'></label></td>';
			} else {
				echo '<td>&nbsp;</td>';
			}
			echo build_room_type_dropdown ($room['type']);
			echo build_room_display_dropdown ($room['display']);
			echo '<td><label><input type="checkbox" name="link" value="1"'.$checkedlink.'></label></td>';
			echo '<td class="roomsubmit">'.submit(_('Change')).'</td>';
			if ($room['permanent']) {
				echo '<td>'._('--:--').'</td>';
			} else {
				echo '<td>'.$roomexpire.'</td>';
			}

			echo '</tr></table>';
		}
		echo '</form></td>';
		echo '</tr>';
	}
	thr();
	echo '<tr><td>';

	echo form('admin', 'rooms').hidden('id', '+');
	echo '<table><tr>';
	echo '<td>'._('New Room').'</td>';
	echo '<td><input type="text" name="name" value="" size="20" style="'.$U['style'].'"></td>';
	echo '<td><input type="text" name="password" value="" size="20" style="'.$U['style'].'"></td>';
	echo build_room_acces_dropdown ($U['status']);

	if ($U['status'] > 6) {
		echo '<td><label><input type="checkbox" name="permanent" value="1"></label></td>';
    } else {
		echo '<td>&nbsp;</td>';
	}

	echo build_room_type_dropdown ();
	echo build_room_display_dropdown ();
	echo '<td><label><input type="checkbox" name="link" value="1"></label></td>';
	echo '<td class="roomsubmit">'.submit(_('Add')).'</td>';
	echo '<td>--:--</td>';
	echo '</tr></table></form></td></tr>';
	echo '</table><br>';
	echo form('admin', 'rooms').submit(_('Reload')).'</form>';
	print_end();
}

// Admin room page management (with coherancy checks)
function manage_rooms ()
{
	global $U, $dbo;
	if (!isset($_POST['id']) || !isset($_POST['access']) || !isset($_POST['name']) || $U['status'] < $_POST['access']) {
		return;
	}
	if (!preg_match('/^[A-Za-z0-9\[\] \-]{0,50}$/', $_POST['name'])) {
		return _('Invalid Name.');
	}
	if (!preg_match('/^[A-Za-z0-9\[\] \-]{0,50}$/', $_POST['password'])) {
		return _('Invalid Password.');
	}
	if (isset($_POST['permanent']) && $_POST['permanent'] && $U['status'] > 6) {
		$permanent = 1;
	} else {
		$permanent = 0;
	}
	if (isset($_POST['link']) && $_POST['link'] && $U['status'] > 6) {
		$allowlinks = 1;
	} else {
		$allowlinks = 0;
	}
	if ($_POST['id'] === '+' && $_POST['name'] !== '') {
		$stmt	= $dbo->prepare('SELECT null FROM ' . PREFIX . 'rooms WHERE name=?');
		$stmt->execute([$_POST['name']]);
		if ($stmt->fetch(PDO::FETCH_NUM)) {
			return _('A room with this name already exist');
		}
		$stmt	= $dbo->prepare('INSERT INTO ' . PREFIX . 'rooms (name, password, creator, access, time, permanent, type, display, withlink) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);');
		$stmt->execute([$_POST['name'], $_POST['password'], $U['nickname'], $_POST['access'], time(), $permanent, $_POST['type'], $_POST['display'], $allowlinks]);
	} elseif ($_POST['name'] !== '') {
		$stmt	= $dbo->prepare('SELECT null FROM ' . PREFIX . 'rooms WHERE name = ? AND id != ?;');
		$stmt->execute([$_POST['name'], $_POST['id']]);
		if ($stmt->fetch(PDO::FETCH_NUM)) {
			return;
		}
		if ($U['status'] < 7) {
			$stmt=$dbo->prepare('SELECT null FROM ' . PREFIX . 'rooms WHERE id = ? AND permanent = 1;');
			$stmt->execute([$_POST['id']]);
			if ($stmt->fetch(PDO::FETCH_NUM)) {
				return;
			}
		}
		$stmt	= $dbo->prepare('UPDATE ' . PREFIX . 'rooms SET name = ?, password = ?, access = ?, time = ?, permanent = ?, type = ?, display = ?, withlink = ? WHERE id = ? AND access <= ?;');
		$stmt->execute([$_POST['name'], $_POST['password'], $_POST['access'], time(), $permanent, $_POST['type'], $_POST['display'], $allowlinks, $_POST['id'], $U['status']]);
		$stmt	= $dbo->prepare('UPDATE ' . PREFIX . 'sessions SET roomid=NULL WHERE roomid=? AND status<?;');
		$stmt->execute([$_POST['id'], $_POST['access']]);
	} else {
		remove_room(false, $_POST['id'], $U['status']);
	}
}

// Room delete routine to clean up message db & move user's to main room if lost in cyberspace 
function remove_room ($all = false, $id = '', $status = 10)
{
	global $dbo;

	if ($all) {
		//placeholder
	} else {
		$stmt = $dbo->prepare('SELECT id FROM ' . PREFIX . 'rooms WHERE id = ? AND access <= ?;');
		$stmt->execute([$id, $status]);
		if ($room = $stmt->fetch(PDO::FETCH_ASSOC)) {
			// Delete room for room table
			$stmt = $dbo->prepare('DELETE FROM ' . PREFIX . 'rooms WHERE id = ?;');
			$stmt->execute([$room['id']]);
			// Delete all messages send to the just deleted room
			$stmt = $dbo->prepare('DELETE FROM ' . PREFIX . 'messages WHERE roomid = ?;');
			$stmt->execute([$room['id']]);
			// Move user's who stay in the deleted rom to the Main Chat
			$stmt = $dbo->prepare('UPDATE ' . PREFIX . 'sessions SET roomid=NULL WHERE roomid = ?;');
			$stmt->execute([$room['id']]);
		}
	}
}

function show_room_table_header (bool $Admin = false) : void 
{
	global $U;

	echo '<th><table><tr>';
	if ($Admin == true) {						// ID
		echo '<td>'._('Room ID:').'</td>';
	} else {
		echo '<td>'.('N°').'</td>' ;
	}
	echo '<td>'.('Name').'</td>';				// Name
	echo '<td>'.('Password').'</td>' ;			// Password
	echo '<td>'.('Access').'</td>';				// Access Access ( Who can access )
	if ($Admin == true) {						// Permanent
		if ($U['status'] > 6) {
			echo '<td>'._('Permanent').'</td>';
		} else {
			echo '<td>&nbsp;</td>';
		}
	}
	echo '<td>'.('Type').'</td>';				// Type ( Visible /Hidden )
	echo '<td>'.('Display').'</td>';			// Display ( Messages & Pm's / Messages only / Pm's only)
	if ($Admin == true) {						
		echo '<td>'._('Links').'</td>';			// Links (allowed or not)
		echo '<td>'._('Apply').'</td>';			// Button zone (Change / Add)
		echo '<td>'._('Expires in').'</td>';	// Expire
	} else {
		echo '<td>'.('Links').'</td>';			// Links (allowed or not)
		echo '<td>'._('Switch').'</td>';		// Button zone (Switch / Add)
	}
	echo '</tr></table></th>';
	return;
}

function show_room_description (array $TheRoom ) : void 
{
	global $U;

	echo '<tr>';
	echo '<td>';
	echo form_target('view', 'view');
	echo hidden('room', $TheRoom['id']);
	echo '<table><tr>';
	echo '<td></td>' ;													// ID
	echo '<td><label>'.$TheRoom['name'].'</label></td>';				// Name
	echo '<td><label>';													// Password
	if (!empty($TheRoom['password'])) {
		if ($U['status'] > 7) {
			echo $TheRoom['password'];
		} elseif ($TheRoom['creator'] == $U['nickname']) {
			echo $TheRoom['password'];
		} else {
			echo _('With password');
		}
	} else {
		echo _('No password');
	}
	echo '</label></td>';
	echo '<td>'.get_room_acces_text ($TheRoom['access']).'</td>';		// Access
	echo '<td>'.get_room_type_text ($TheRoom['type']).'</td>';			// Type
	echo '<td>'.get_room_display_text ($TheRoom['display']).'</td>';	// Content
	echo '<td>';														// Links
	if ($TheRoom['withlink'] == 1) {
		echo 'Links';
	} else {
		echo 'No Links';
	}
	echo '</td>';
	echo '<td class="roomsubmit">'.submit(_('Switch')).'</td>';			// Switch / Add
	echo '</tr></table>';
	echo '</form></td>';
	echo '</tr>';

	return;
}

function get_modroom_infos ( array $message, bool $modroom ) : array 
{
	global $dbo, $U;

	$Infos		 = [];

	// Modification for modrooms in chat rooms
	$roomname	 = '';
	$Infos[0]	 = true;
	$Infos[1]	 = '[Main Chat]';

	if ($modroom && !$message['allrooms']) {
		$roomname = 'Main Chat';
		if ($message['roomid'] != null) {
			$stmt1 = $dbo->prepare('SELECT name, type, password FROM ' . PREFIX . 'rooms WHERE id = ? AND access <= ?');
			$stmt1->execute([$message['roomid'], $U['status']]);
			if (!$name = $stmt1->fetch(PDO::FETCH_ASSOC)) {
				$Infos[0] = false;
			} elseif (!empty($name['password'])) {
				$Infos[0] = false;
			} elseif ($name['type'] == 1) {
				$Infos[0] = false;
			}
			if (preg_match_all( '/\[(.*)\]/', $name['name'], $Matches,  PREG_SET_ORDER | PREG_UNMATCHED_AS_NULL)) {
				$roomname = $Matches[0][1];
			} else {
				$roomname = $name['name'];
			}
		}
		$Infos[1] = '['.$roomname.']';
	}

	return $Infos;

}

// Room button ... display existing room ... allow room creation from roomcreator level ... switch to other room ... switch to secret room's 
function rooms ($arg='')
{
	global $U, $dbo;

	print_start('btnrooms');
	$iCAcces	= get_setting('roomcreateaccess');
	
	echo '<h2>'._('Chat Rooms').'</h2><i>'.$arg.'</i>';
	echo '<table>';
	thr();
	echo '<tr>';
	echo show_room_table_header();
	echo '</tr>';

	if (!$rooms = get_rooms ($U['status'])) {
		$rooms = [];
	}

	thr();
	// Display Permanent room's
	if (get_rooms_count() > 0) {
		echo '<tr><td><center>'._('Permanent room\'s').'</center></td><tr>';
		thr();
		foreach ($rooms as $room) {
			if ($room['permanent'] == '1') {
				show_room_description ($room);
			}
		}

		thr();
	}

	if (get_rooms_count(true) > 0) {
		echo '<tr><td><center>'._('Temporary member room\'s').'</center></td><tr>';
		thr();
		// Display User's room's without password
		foreach ($rooms as $room) {
			if ($room['permanent'] == '0') {
				if (empty($room['password'])) {
					// Visible Rooms
					if ($room['type'] == 0) {
						show_room_description ($room);
					// Hidden Rooms
					} elseif ($room['type'] == 1) {
						if ($room['creator'] == $U['nickname']) {
							show_room_description ($room);
						} elseif ($U['status'] >= 7) {
							show_room_description ($room);
						}
					}
				}
			}
		}

		// Display User's room's with password
		foreach ($rooms as $room) {
			if ($room['permanent'] == '0') {
				if (!empty($room['password'])) {
					// Is the room creator the current user ?
					if ($room['creator'] == $U['nickname']) {
						show_room_description ($room);
					// is the current user admin or super admin ?
					} elseif ($U['status'] >= 7) {
						show_room_description ($room);
					}
				}
			}
		}
	}

	$expire 	 = (int) get_setting('roomexpire');
	$roomexpire	 = get_timeout(time(), $expire);

	// Create an User Room
	if ($U['status'] >= $iCAcces) {
		echo '<tr><td><center>'.sprintf( _('Create a member room. Member room expire after %d minutes when last user is gone'), $expire).'</center></td><tr>';
		thr();
		echo '<tr><td>';
		echo form('admin', 'createrooms').hidden('id', '+');
		echo '<table><tr>';
		echo '<td>'._('New Room').'</td>';
		echo '<td><input type="text" name="name" value="" size="20" style="'.$U['style'].'"></td>';
		echo '<td><input type="text" name="password" value="" size="20" style="'.$U['style'].'"></td>';
		echo build_room_acces_dropdown ($U['status'], get_setting('roomaccess'));
		echo build_room_type_dropdown (0);
		echo build_room_display_dropdown (0);
		echo '<td><label><input type="checkbox" name="link" value="1">'.' '.'</label></td>';
		echo '<td class="roomsubmit">'.submit(_('Add')).'</td>';
		echo '</tr></table></form>';
		echo '</td></tr>';
	}

	thr();
	echo '<tr><td><center>'._('To enter in a private or hidden room, Type room name and password if needed').'</center></td><tr>';
	thr();
	echo '<tr><td>';
	echo form('view', 'view');
	echo hidden('room', '@');
	echo '<table><tr>';
	echo '<td>'._('Switch to').'</td>';
	echo '<td><input type="text" name="name" value="" size="20" style="'.$U['style'].'"></td>';
	echo '<td><input type="text" name="password" value="" size="20" style="'.$U['style'].'"></td>';
	echo '<td>&nbsp;</td>';
	echo '<td>&nbsp;</td>';
	echo '<td>&nbsp;</td>';
	echo '<td>&nbsp;</td>';
	echo '<td class="roomsubmit">'.submit(_('Switch')).'</td>';
	echo '</tr></table></form>';
	echo '</td></tr>';

	echo '</table><br>';

	echo form_target('view', 'rooms').submit(_('Reload')).'</form>';
    print_end();
}

?>