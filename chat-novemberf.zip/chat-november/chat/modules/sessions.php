<?php

//  session management
function check_member (string $password) : bool 
{
	global $U, $dbo;
	$tmp['nickname'] = strtolower($U['nickname']);
	$stmt = $dbo->prepare('SELECT * FROM ' . PREFIX . 'members WHERE LOWER(nickname) = ?;');
	$stmt->execute([$tmp['nickname']]);
	if ($temp = $stmt->fetch(PDO::FETCH_ASSOC)) {
		if (get_setting('dismemcaptcha') == 0) {
			check_captcha($_POST['challenge'] ?? '', $_POST['captcha'] ?? '');
		}
		if ($temp['passhash'] === md5(sha1(md5($U['nickname'].$password)))) {
			// old hashing method, update on the fly
			$temp['passhash'] = password_hash($password, PASSWORD_DEFAULT);
			$stmt = $dbo->prepare('UPDATE ' . PREFIX . 'members SET passhash=? WHERE nickname=?;');
			$stmt->execute([$temp['passhash'], $U['nickname']]);
		}
		if (password_verify($password, $temp['passhash'])) {
			$U    = $temp;
			$stmt = $dbo->prepare('UPDATE ' . PREFIX . 'members SET lastlogin=? WHERE nickname=?;');
			$stmt->execute([time(), $U['nickname']]);
			return true;
		} else {
			$stmt = $dbo->prepare('UPDATE ' . PREFIX . 'members SET loginfails=? WHERE nickname=?;');
			$stmt->execute([$temp['loginfails']+1, $temp['nickname']]);
			send_error(_('This nickname is a registered member.')."<br>"._('Wrong Password!'));
		}
	}
	return false;
}

function add_user_defaults (string $password) : void
{
	global $U;
	$U['refresh']      = get_setting('defaultrefresh');
	$U['bgcolour']     = get_setting('colbg');
	if (!isset($_POST['colour']) || !preg_match('/^[a-f0-9]{6}$/i', $_POST['colour']) || abs(greyval($_POST['colour']) - greyval(get_setting('colbg'))) < 75) {
		do {
			$colour = sprintf ('%06X', mt_rand(0, 16581375));
		} while (abs (greyval($colour) - greyval(get_setting('colbg'))) < 75);
	} else {
		$colour = $_POST['colour'];
	}
	$U['style']			= "color:#$colour;";
	$U['timestamps']	= get_setting('timestamps');
	$U['embed']			= 1;
	$U['incognito']		= 0;
	$U['status']		= 1;
	$U['nocache']		= get_setting('sortupdown');
	if ($U['nocache']) {
		$U['nocache_old']	= 0;
	} else {
		$U['nocache_old']	= 1;
	}
	$U['loginfails']	= 0;
	$U['tz']			= get_setting('defaulttz');
	$U['eninbox']		= 0;
	$U['sortupdown']	= get_setting('sortupdown');
	$U['hidechatters']	= 0;
	$U['hide_sysmess']	= 0;
	$U['conv_mode'] 	= 0;
	$U['user_entry']	= get_setting('msgenter');
	$U['user_exit']		= get_setting('msgexit');
	$U['user_caption']	= '';
	$U['passhash']		= password_hash($password, PASSWORD_DEFAULT);
	$U['entry']			= $U['lastpost'] = time();
}

function create_session(bool $setup, string $nickname, string $password) : void
{
	global $U;
	$U['nickname'] 	= preg_replace('/\s/', '', $nickname);
	$useragent 		= '';
	if (check_member ($password)) {
		if ($setup && $U['status'] >= 7) {
			$U['incognito'] = 1;
		}
		$U['entry'] = $U['lastpost'] = time();
	} else {
		add_user_defaults ($password);
		check_captcha($_POST['challenge'] ?? '', $_POST['captcha'] ?? '');
		$useragent	= htmlspecialchars($_SERVER['HTTP_USER_AGENT']);

		$ga			= (int) get_setting('guestaccess');
		if (!valid_nick($U['nickname'])) {
			send_error(sprintf(_('Invalid nickname (%1$d characters maximum and has to match the regular expression "%2$s")'), get_setting('maxname'), get_setting('nickregex')));
		}
		if (!valid_pass($password)) {
			send_error(sprintf(_('Invalid password (At least %1$d characters and has to match the regular expression "%2$s")'), get_setting('minpass'), get_setting('passregex')));
		}

		if ($ga === 0) {
			send_error(_('Sorry, currently members only!'));
		} elseif (in_array($ga, [2, 3], true)) {
			$U['entry'] = 0;
		}

		if (get_setting('englobalpass') != 0 && isset($_POST['globalpass']) && $_POST['globalpass'] != get_setting('globalpass')) {
			send_error(_('Wrong global Password!'));
		}

		if (isset($useragent) && $U['status'] <= 2) {
			if (!get_setting('allow_mobile')) {
				$mDevices = array('Mobile' , 'Android' , 'iPhone' , 'iOS', 'PrivacyBrowser', 'ELinks', 'PlayStation' );
				if (stripos_array($mDevices, $useragent)) {
					send_error(_('Sorry, no mobile devices , Android OS or tablets allowed'));
				}
			}
		}
	}
	try {
		$U[ 'postid' ] = bin2hex( random_bytes( 3 ) );
	} catch(Exception $e) {
		send_error($e->getMessage());
	}
	write_new_session($password);
}

function stripos_array($array, $text) : bool 
{
	foreach ($array as $value) {
	   if (stripos($text, $value) !== FALSE) {
			return TRUE;
	   }
	}
	return FALSE;
} 

function write_new_session(string $password) : void
{
	global $U, $dbo, $chat_session, $language;

	$SendTo		 = "s *";
	$nocache	 = substr(time(), -6);
	$nicktags	 = get_setting('nicktags');
	$EnterMess	 = get_setting('msgenter');
	$sys_mess	 = 1;
	$stmt		 = $dbo->prepare('SELECT * FROM ' . PREFIX . 'sessions WHERE nickname=?;');
	$stmt->execute([$U['nickname']]);
	if ($temp  = $stmt->fetch(PDO::FETCH_ASSOC)) {
		// check whether alrady logged in
		if (password_verify($password, $temp['passhash'])) {
			$U = $temp;
			check_kicked();
			set_secure_cookie(COOKIENAME, $U['session']);
		} else {
			send_error(_('A user with this nickname is already logged in.')."<br>"._('Wrong Password!'));
		}
	} else {
		// create new session
		$stmt  = $dbo->prepare('SELECT null FROM ' . PREFIX . 'sessions WHERE session = ?;');
		do {
			try {
				$U[ 'session' ] = bin2hex( random_bytes( 16 ) );
			} catch(Exception $e) {
				send_error($e->getMessage());
			}
			$stmt->execute([$U['session']]);
		} while ($stmt->fetch(PDO::FETCH_NUM)); // check for hash collision

		if (isset($_SERVER['HTTP_USER_AGENT'])) {
			$useragent 	= htmlspecialchars($_SERVER['HTTP_USER_AGENT']);
		} else {
			$useragent 	= '';
		}

		if (get_setting('trackip')) {
			$ip			= $_SERVER['REMOTE_ADDR'];
		} else {
			$ip			= '';
		}

		$stmt=$dbo->prepare('INSERT INTO ' . PREFIX . 'sessions (session, nickname, status, refresh, style, lastpost, passhash, useragent, bgcolour, entry, timestamps, embed, incognito, ip, nocache, tz, eninbox, sortupdown, hidechatters, conv_mode, hide_sysmess, user_entry, user_exit, user_caption, nocache_old, postid) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);');
		$stmt->execute([$U['session'], $U['nickname'], $U['status'], $U['refresh'], $U['style'], $U['lastpost'], $U['passhash'], $useragent, $U['bgcolour'], $U['entry'], $U['timestamps'], $U['embed'], $U['incognito'], $ip, $U['nocache'], $U['tz'], $U['eninbox'], $U['sortupdown'], $U['hidechatters'], $U['conv_mode'], $U['hide_sysmess'], $U['user_entry'], $U['user_exit'], $U['user_caption'], $U['nocache_old'], $U['postid']]);
		$chat_session = $U['session'];
		set_secure_cookie(COOKIENAME, $U['session']);

		if (get_setting('hide_sys_mess')) {
			if($U['hide_sysmess']){
				$sys_mess = 0;
			} else {
				$sys_mess = 1;
			}
		}
		if (get_setting('user_sys_mess')) {
			if (!empty($U['user_entry'])) {
				$EnterMess =  stripslashes($U['user_entry']);
			}
		}
		if ($U['status'] >= 3 && !$U['incognito']) {
			if ($sys_mess == 1) {
				$nncc = '';
				if ($nicktags) {
					$lang = '&lang=' . $language;
					if (!empty($nocache)) {
						$nncc = '&nc=' . $nocache;
					}
					$nick = '&nickname='.$U['nickname'];
					$send = '&sendto=' . $SendTo;
					$nicklink   = '<a class="nicklink" href="'.$_SERVER['SCRIPT_NAME'].'?action=post'. $lang . $nncc . $nick . $send.'" target="post" >'. style_this(htmlspecialchars($U['nickname']), $U['style']) .'</a>';
					add_system_message(sprintf($EnterMess, $nicklink), '');
				} else {
					add_system_message(sprintf($EnterMess, style_this(htmlspecialchars($U['nickname']), $U['style'])), '');
				}	
			}
		}
	}
}

function show_fails () : void
{
	global $dbo, $U;
	$stmt=$dbo->prepare('SELECT loginfails FROM ' . PREFIX . 'members WHERE nickname = ?;');
	$stmt->execute([$U['nickname']]);
	$temp=$stmt->fetch(PDO::FETCH_NUM);
	if($temp && $temp[0]>0){
		print_start('failednotice');
		echo $temp[0] . "&nbsp;" . _('Failed login attempt(s)') . "<br>";
		$stmt=$dbo->prepare('UPDATE ' . PREFIX . 'members SET loginfails = ? WHERE nickname = ?;');
		$stmt->execute([0, $U['nickname']]);
		echo form_target('_self', 'login') . submit(_('Dismiss')) . '</form></td>';
		print_end();
	}
}

function approve_session () : void
{
	global $dbo;
	if (isset($_POST['what'])) {
		if ($_POST['what'] === 'allowchecked' && isset($_POST['csid'])) {
			$stmt	= $dbo->prepare('UPDATE ' . PREFIX . 'sessions SET entry=lastpost WHERE nickname=?;');
			foreach ($_POST['csid'] as $nick) {
				$stmt->execute([$nick]);
			}
		} elseif ($_POST['what'] === 'allowall' && isset($_POST['alls'])) {
			$stmt	= $dbo->prepare('UPDATE ' . PREFIX . 'sessions SET entry=lastpost WHERE nickname=?;');
			foreach ($_POST['alls'] as $nick) {
				$stmt->execute([$nick]);
			}
		} elseif ($_POST['what'] === 'denychecked' && isset($_POST['csid'])) {
			$time	= 60 * (get_setting('kickpenalty') - get_setting('guestexpire')) + time();
			$stmt	= $dbo->prepare('UPDATE ' . PREFIX . 'sessions SET lastpost=?, status=0, kickmessage=? WHERE nickname=? AND status=1;');
			foreach ($_POST['csid'] as $nick) {
				$stmt->execute([$time, $_POST['kickmessage'], $nick]);
			}
		} elseif ($_POST['what'] === 'denyall' && isset($_POST['alls'])) {
			$time	= 60 * (get_setting('kickpenalty') - get_setting('guestexpire')) + time();
			$stmt	= $dbo->prepare('UPDATE ' . PREFIX . 'sessions SET lastpost=?, status=0, kickmessage=? WHERE nickname=? AND status=1;');
			foreach ($_POST['alls'] as $nick) {
				$stmt->execute([$time, $_POST['kickmessage'], $nick]);
			}
		}
	}
}

function kill_session () : void
{
	global $U, $dbo, $chat_session, $language;

	$SendTo		 = "s *";
	$nocache	 = substr(time(), -6);
	$nicktags	 = get_setting('nicktags');
	$ExitMess	 = get_setting('msgexit');
	$sys_mess	 = 1;
	parse_sessions();
	check_expired();
	check_kicked();
	setcookie(COOKIENAME, false);
	$stmt=$dbo->prepare('UPDATE ' . PREFIX . 'members SET lastlogout=? WHERE nickname=?;');
	$stmt->execute([time(), $U['nickname']]);
	$chat_session = '';
	$stmt = $dbo->prepare('DELETE FROM ' . PREFIX . 'sessions WHERE session=?;');
	$stmt->execute([$U['session']]);

	if (get_setting('hide_sys_mess')) {
		if($U['hide_sysmess']){
			$sys_mess = 0;
		} else {
			$sys_mess = 1;
		}
	}
	if (get_setting('user_sys_mess')) {
		if (!empty($U['user_exit'])) {
			$ExitMess = stripslashes($U['user_exit']);
		}
	}
	if($U['status']>=3 && !$U['incognito']){
		if ($sys_mess == 1) {
			$nncc = '';
			if ($nicktags) {
				$lang = '&lang=' . $language;
				if (!empty($nocache)) {
					$nncc = '&nc=' . $nocache;
				}
				$nick = '&nickname='.$U['nickname'];
				$send = '&sendto=' . $SendTo;
				$nicklink   = '<a class="nicklink" href="'.$_SERVER['SCRIPT_NAME'].'?action=post'. $lang . $nncc . $nick . $send.'" target="post" >'. style_this(htmlspecialchars($U['nickname']), $U['style']) .'</a>';
				add_system_message(sprintf($ExitMess, $nicklink), '');
			} else {
				add_system_message(sprintf($ExitMess, style_this(htmlspecialchars($U['nickname']), $U['style'])), '');
			}
		}
	}
}


function check_session() : void
{
	global $U;
	check_is_mybbuser(false);
	parse_sessions();
	check_expired();
	check_kicked();
	if($U['entry'] == 0)
	{
		send_waiting_room();
	}
}

function check_expired() : void
{
	global $U, $chat_session;

	if(!isset($U['session'])){
		setcookie(COOKIENAME, false);
		$chat_session = '';
		send_error(_('Invalid or Expired session'));
	}
}

function check_kicked () : void
{
	global $U, $chat_session;

	if ($U['status'] == 0) {
		setcookie(COOKIENAME, false);
		$chat_session = '';
		send_error(_('You have been kicked!').'<br>'.$U['kickmessage']);
	}
}

function parse_sessions () : void
{
	global $U, $dbo, $chat_session;

	// look for our session
	if (!empty($chat_session)) {
		$stmt = $dbo->prepare('SELECT * FROM ' . PREFIX . 'sessions WHERE session = ?;');
		$stmt->execute([$chat_session]);
		if($tmp = $stmt->fetch(PDO::FETCH_ASSOC)){
			$U = $tmp;
		}
	}

	set_default_tz();
}


?>