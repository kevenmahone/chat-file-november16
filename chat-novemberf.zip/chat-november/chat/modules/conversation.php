<?php

function DoConversationModeQuery ($poster, $recipient, $direction) 
{
	global $dbo;

	$Req['poster'] 	 = $poster;
	$Req['receiver'] = $recipient;
	$Query			 = 'SELECT id, postdate, text, poststatus, delstatus, poster, recipient, roomid, allrooms FROM ' . PREFIX . 'messages WHERE ';
	$Query			.= 'poststatus = 9 AND ( poster = ?    AND recipient = ? ) OR  ( recipient = ? AND poster = ? ) ORDER BY id '.$direction.';';
	$stmt 			 = $dbo->prepare($Query);
	$stmt->execute([$Req['poster'], $Req['receiver'], $Req['poster'], $Req['receiver']]);

	return $stmt;
}

function del_conv_messages (string $filter) : void 
{
	global $dbo, $U;

	// Filter to select only one poster and his recipient for the conversation
	$Req['poster'] 		= $U['nickname'];
	$Req['receiver'] 	= $filter;
	$stmt = $dbo->prepare('DELETE FROM  ' . PREFIX . 'messages WHERE poststatus = 9 AND ( poster = ? AND recipient = ? ) OR  ( recipient = ? AND poster = ? );');
	$stmt->execute([$Req['poster'], $Req['receiver'], $Req['poster'], $Req['receiver']]);

	return;
}

function save_conversation (string $filter) : void
{
	global $U, $dbo;

	$dateformat  = get_setting('dateformat');

	$CurentDate  = date('Y-m-d');;

	if ($U['sortupdown']) {
		$direction	 = 'DESC';
	} else {
		$direction	 = 'ASC';
	}

	$FileName 	= $CurentDate.'_Conv_'.$filter.'.txt';
	$FilePath	= './temp/'.$FileName;
	$hFile 		= fopen( $FilePath, 'w') or die("Unable to open file!");

	$Req['poster'] = $U['nickname'];
	$Req['receiver'] = $filter;
	$stmt = $dbo->prepare('SELECT id, postdate, text, poststatus, delstatus, poster, recipient, roomid, allrooms FROM ' . PREFIX . 'messages WHERE '.
	'poststatus = 9 AND ( poster = ?    AND recipient = ? ) OR  ( recipient = ? AND poster = ? ) ORDER BY id '.$direction.';');
	$stmt->execute([$Req['poster'], $Req['receiver'], $Req['poster'], $Req['receiver']]);
	while ($message = $stmt->fetch(PDO::FETCH_ASSOC)) {
		prepare_message_print  ($message, true);

		$text	 = date($dateformat, $message['postdate']);
		$text 	.= ' - '.sprintf("%s\n",html_entity_decode(strip_tags($message['text'])));
		fwrite ($hFile, $text);
	}

	fclose($hFile);	

	header('Content-Type: text/plain');
	header('Content-Disposition: attachment; filename='.$FileName ); // will download your file
	readfile($FilePath);
	unlink($FilePath);
	exit;

	return;
}

?>