<?php

    /* a reference to another chat line from a reaction /

    // To add to prepare_stylesheets () 
    $styles['default'] .= '.refer-summary { width: 10px; height: 10px; } .refer-summary:hover + .refer-detail, .refer-detail:hover { display: inline-block; } .refer-detail { display: none;} .refer-msg div { font-size: 1rem;} ';

    */

function create_message_reference_link ( array $message, string $lang, string $nncc ) : string 
{
    global $dbo;

    $HtmlText		 = '';
    $HtmlMess        = '';
    $ref_id          = '';
    $DateFormat		 = (string) get_setting('dateformat');
    $Msg_Mention     = (bool)   get_setting('allow_msg_mention');


    $HtmlMess        = $message['text'];

    if ($Msg_Mention) {
        if (preg_match_all( '/#M-([0-9]{10})/', $message['text'], $Matches,  PREG_SET_ORDER | PREG_UNMATCHED_AS_NULL)) {
            $ref_id      = $Matches[0][1];
        }

        if ($ref_id != '') {
            // Look's like we have a ref to a message
            $msg_id      = sprintf("%010d", $message['id']);
            // Get the post with the given postdate ... so i am sure that's a reference to a post
            $RefMessage	 = $dbo->query('SELECT poster, text, postdate FROM '. PREFIX .'messages WHERE id = '. (int) $ref_id.';');
            if ($Refs = $RefMessage->fetch(PDO::FETCH_ASSOC)) {
                $Poster			 = $Refs['poster'];
                $PostTime        = date($DateFormat, $Refs['postdate']);
                $Reference		 = html_entity_decode(strip_tags($Refs['text']));
                $msg_ref		 = '#msg-'.$ref_id;
                $msg_this		 = '#msg-'.$msg_id;

                $ref_lnk         = $_SERVER['SCRIPT_NAME'].'?action=view'. $lang . $nncc . $msg_ref;

                $ExtraStyle		 = '<style>';
                $ExtraStyle		.= $msg_this.':hover ~ '.$msg_ref.' { background-color: rgb(20,50,20); } ';
                $ExtraStyle		.= $msg_this.':hover .refer-msg { background-color: rgb(20,20,20); } ';
                $ExtraStyle		.= '</style>';

                $HtmlText		 = '<a href="'.$ref_lnk.'" class="refer-msg">';
                $HtmlText		.= '<span class="refer-key" title="">';
                $HtmlText		.= '<span class="refer-summary"><img src="/Images/msg_ref.gif" title="'._('Reference to message').'" style="width: 10px; height: 15px"></span>';
                $HtmlText		.= '<span class="refer-detail"><label title="'.$Reference.'">'.$Poster.' @ '.$PostTime.'</label></span> ';
                $HtmlText		.= $ExtraStyle;
                $HtmlText		.= '</span></a> ';
            }
            $HtmlMess = preg_replace('/#M-[0-9]{10}/', $HtmlText, $message['text']);
        }
    }

    return $HtmlMess;
}

function PostStatus_to_SendTo ( int $iPostStatus ) : string 
{
    $SendTo     = '';

    if ($iPostStatus == 1 ) {
        $SendTo     = 's *';
    } elseif ($iPostStatus == 2 ) {
        $SendTo     = 's !';
    } elseif ($iPostStatus == 3 ) {
        $SendTo     = 's ?';
    } elseif ($iPostStatus == 5 ) {
        $SendTo     = 's %';
    } elseif ($iPostStatus == 6 ) {
        $SendTo     = 's _';
    } else {
        $SendTo     = '';
    }

    return $SendTo;
}

// function added to print_messages ()
function create_message_id  ( array $message ) : string 
{
	$Msg_Mention = (bool)   get_setting('allow_msg_mention');

    $HtmlText	 = '';

    $msgid		 = sprintf ("%010d", $message['id']);

    if ($Msg_Mention) {
        $HtmlText    = '<div class="msg" id="msg-'.$msgid.'">';
    } else {
        $HtmlText    = '<div class="msg">';
    }

    return $HtmlText;
}

function create_message_timestamp ( array $message, string $filter='' ) : string 
{
    global $U, $chat_language;

	$Msg_Mention = (bool)   get_setting('allow_msg_mention');
    $Date_Format = (string) get_setting('dateformat');


    $HtmlText	 = '';
    $HtmlStamp   = '';
    $mess        = '';
    $conv        = '';
    $lang        = '';
    $send        = '';
    $nncc        = '';


    $HtmlStamp   = date ($Date_Format, $message['postdate']);
    $msgid		 = sprintf ("%010d", $message['id']);
    $msg_link	 = "%23M-".$msgid;

    if ($message['poststatus'] == 9) {
        if ($message['recipient'] != $U['nickname']) {
            $SendTo      = $message['recipient'];
        } else {
            $SendTo      = $message['poster'];
        }
    } else {
        $SendTo      = PostStatus_to_SendTo ((int) $message['poststatus']);
    }

    if (!empty($filter)) {
        $SendTo      = $filter;
        $conv        = '&filter=' . $filter;
    }
    $mess        = '&msg='    . $msg_link;
    $lang        = '&lang='   . $chat_language;
    $nncc		 = '&nc='     . substr(time(), -6);
    $send        = '&sendto=' . $SendTo;



    if ($Msg_Mention && $message['poststatus'] != 4) {
        $HtmlText    = '<a class="msg_ref" title="'._('Reference to this line').'" ';
        $HtmlText   .= 'href="./chat.php?action=post'. $mess . $conv . $lang . $nncc . $send .'" target="post">';
        $HtmlText   .= '<small>' . $HtmlStamp . '</small></a>';
        $HtmlText   .= '<small> - </small>';    
    } else {
        $HtmlText    = '<small>' . $HtmlStamp . ' - </small>';
    }

    return $HtmlText;
}

?>