<?php

function delete_account (): void
{
	global $U, $dbo;
	if ($U['status'] < 8) {
		$stmt = $dbo->prepare('UPDATE ' . PREFIX . 'sessions SET status = 1, incognito = 0 WHERE nickname = ?;');
		$stmt->execute([$U['nickname']]);
		$U['status'] = 1;
		$stmt = $dbo->prepare('DELETE FROM ' . PREFIX . 'members WHERE nickname = ?;');
		$stmt->execute([$U['nickname']]);
		$stmt = $dbo->prepare('DELETE FROM ' . PREFIX . 'inbox WHERE recipient = ?;');
		$stmt->execute([$U['nickname']]);
		$stmt = $dbo->prepare('DELETE FROM ' . PREFIX . 'notes WHERE (type = 2 OR type = 3) AND editedby = ?;');
		$stmt->execute([$U['nickname']]);
		$stmt = $dbo->prepare('DELETE FROM ' . PREFIX . 'sessions WHERE nickname = ?;');
		$stmt->execute([$U['nickname']]);
	}
}

function register_guest (int $status, string $nick) : string 
{
	global $U, $dbo;

	// Upgrade status from Friend to Member
	$stmt = $dbo->prepare('SELECT style, status FROM ' . PREFIX . 'members WHERE nickname=?');
	$stmt->execute([$nick]);
	if ($tmp = $stmt->fetch(PDO::FETCH_ASSOC)) {
		if ($tmp['status'] == 2) {
			$stmt = $dbo->prepare('UPDATE ' . PREFIX . 'sessions SET status=3 WHERE nickname=?;');
			$stmt->execute([$nick]);
			$stmt = $dbo->prepare('UPDATE ' . PREFIX . 'members set status=3 WHERE nickname=?');
			$stmt->execute([$nick]);
			add_system_message(sprintf(get_setting('msgmemreg'), style_this(htmlspecialchars($nick), $tmp['style'])), $U['nickname']);
			return sprintf(_('%s is is now registered Member.'), style_this(htmlspecialchars($nick), $tmp['style']));
		} else {
			return sprintf(_('%s is already registered.'), style_this(htmlspecialchars($nick), $tmp['style']));
		}
	}

	// Register a new Guest directly to Friend or Member
	$stmt = $dbo->prepare('SELECT * FROM ' . PREFIX . 'sessions WHERE nickname=? AND status=1;');
	$stmt->execute([$nick]);
	if ($reg = $stmt->fetch(PDO::FETCH_ASSOC)) {
		$reg['status'] = $status;
		$stmt = $dbo->prepare('UPDATE ' . PREFIX . 'sessions SET status=? WHERE session=?;');
		$stmt->execute([$reg['status'], $reg['session']]);
	} else {
		return sprintf(_("Can't register %s"), htmlspecialchars($nick));
	}
	$stmt = $dbo->prepare('INSERT INTO ' . PREFIX . 'members (nickname, passhash, status, refresh, bgcolour, regedby, regedwhen, lastlogin, timestamps, embed, style, incognito, nocache, tz, eninbox, sortupdown, hidechatters, conv_mode, hide_sysmess, user_entry, user_exit, user_intro, nocache_old) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);');
	$reg['user_intro']	= '';
	$reg['embed']		= 1;
	$reg['conv_mode'] 	= 0;
	$reg['regedwhen']	= time();
	$reg['lastlogin']	= time();
	$stmt->execute([$reg['nickname'], $reg['passhash'], $reg['status'], $reg['refresh'], $reg['bgcolour'], $U['nickname'], $reg['regedwhen'], $reg['lastlogin'], $reg['timestamps'], $reg['embed'], $reg['style'], $reg['incognito'], $reg['nocache'], $reg['tz'], $reg['eninbox'], $reg['sortupdown'], $reg['hidechatters'], $reg['conv_mode'], $reg['hide_sysmess'], $reg['user_entry'], $reg['user_exit'], $reg['user_intro'], $reg['nocache_old']]);
	if ($reg['status'] == 3) {
		add_system_message(sprintf(get_setting('msgmemreg'), style_this(htmlspecialchars($reg['nickname']), $reg['style'])), $U['nickname']);
	} else {
		add_system_message(sprintf(get_setting('msgsureg'), style_this(htmlspecialchars($reg['nickname']), $reg['style'])), $U['nickname']);
	}
	return sprintf(_('%s successfully registered.'), style_this(htmlspecialchars($reg['nickname']), $reg['style']));
}

function register_new(string $nick, string $pass) : string 
{
	global $U, $dbo;

	$nick = preg_replace('/\s/', '', $nick);
	if (empty($nick)) {
		return '';
	}
	$stmt = $dbo->prepare('SELECT null FROM ' . PREFIX . 'sessions WHERE nickname=?');
	$stmt->execute([$nick]);
	if ($stmt->fetch(PDO::FETCH_NUM)) {
		return sprintf(_("Can't register %s"), htmlspecialchars($nick));
	}
	if (!valid_nick($nick)) {
		return sprintf(_('Invalid nickname (%1$d characters maximum and has to match the regular expression "%2$s")'), get_setting('maxname'), get_setting('nickregex'));
	}
	if (!valid_pass($pass)) {
		return sprintf(_('Invalid password (At least %1$d characters and has to match the regular expression "%2$s")'), get_setting('minpass'), get_setting('passregex'));
	}
	$stmt = $dbo->prepare('SELECT null FROM ' . PREFIX . 'members WHERE nickname=?');
	$stmt->execute([$nick]);
	if ($stmt->fetch(PDO::FETCH_NUM)) {
		return sprintf(_('%s is already registered.'), htmlspecialchars($nick));
	}
	$reg=[
		'nickname'	    => $nick,
		'passhash'	    => password_hash($pass, PASSWORD_DEFAULT),
		'status'	    => 3,
		'refresh'	    => get_setting('defaultrefresh'),
		'bgcolour'	    => get_setting('colbg'),
		'regedby'	    => $U['nickname'],
		'regedwhen'     => time(),
		'lastlogin'		=> time(),
		'timestamps'	=> get_setting('timestamps'),
		'style'		    => 'color:#'.get_setting('coltxt').';',
		'embed'		    => 1,
		'incognito'	    => 0,
		'conv_mode'		=> 0,
		'nocache'	    => 0,
		'nocache_old'	=> 1,
		'tz'		    => get_setting('defaulttz'),
		'eninbox'	    => 0,
		'sortupdown'	=> get_setting('sortupdown'),
		'hidechatters'	=> 0,
		'hide_sysmess'  => get_setting('hide_sys_mess'),
	];
	$stmt=$dbo->prepare('INSERT INTO ' . PREFIX . 'members (nickname, passhash, status, refresh, bgcolour, regedby, regedwhen, lastlogin, timestamps, style, embed, incognito, conv_mode, nocache, tz, eninbox, sortupdown, hidechatters, nocache_old) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);');
	$stmt->execute([$reg['nickname'], $reg['passhash'], $reg['status'], $reg['refresh'], $reg['bgcolour'], $reg['regedby'], $reg['regedwhen'], $reg['lastlogin'], $reg['timestamps'], $reg['style'], $reg['embed'], $reg['incognito'], $reg['conv_mode'], $reg['nocache'], $reg['tz'], $reg['eninbox'], $reg['sortupdown'], $reg['hidechatters'], $reg['nocache_old']]);

	return sprintf(_('%s successfully registered.'), htmlspecialchars($reg['nickname']));
}

function passreset (string $nick, string $pass) : string 
{
	global $U, $dbo;
	if (empty($nick)) {
		return '';
	}
	$stmt = $dbo->prepare('SELECT null FROM ' . PREFIX . 'members WHERE nickname=? AND status<?;');
	$stmt->execute([$nick, $U['status']]);
	if ($stmt->fetch(PDO::FETCH_ASSOC)) {
		$passhash = password_hash($pass, PASSWORD_DEFAULT);
		$stmt = $dbo->prepare('UPDATE ' . PREFIX . 'members SET passhash=? WHERE nickname=?;');
		$stmt->execute([$passhash, $nick]);
		$stmt = $dbo->prepare('UPDATE ' . PREFIX . 'sessions SET passhash=? WHERE nickname=?;');
		$stmt->execute([$passhash, $nick]);
		return sprintf(_('Successfully reset password for %s'), htmlspecialchars($nick));
	} else {
		return sprintf(_("Can't reset password for %s"), htmlspecialchars($nick));
	}
}

function valid_nick (string $nick) : bool
{
	$len = mb_strlen($nick);
	if ($len < 1 || $len > get_setting('maxname')) {
		return false;
	}
	return preg_match('/'.get_setting('nickregex').'/u', $nick);
}

function valid_pass (string $pass) : bool 
{
	if (mb_strlen($pass) < get_setting('minpass')) {
		return false;
	}
	return preg_match('/'.get_setting('passregex').'/u', $pass);
}

function get_member_style ($nickname) : string 
{
	global $dbo;

	$style = '';
	$Usr['nickname'] = $nickname;
	$stmt=$dbo->prepare('SELECT style FROM ' . PREFIX . 'members WHERE nickname = ?;');
	$stmt->execute([$Usr['nickname']]);
	if ($tmp = $stmt->fetch(PDO::FETCH_ASSOC)) {
		$style = $tmp['style'];
	}
	return $style;
}

function style_this (string $text, string $styleinfo) : string 
{
	return "<span style=\"$styleinfo\">$text</span>";
}

function send_delete_account () : void
{
	print_start('delete_account');
	echo '<table><tr><td colspan="2">'._('Are you sure?').'</td></tr><tr><td>';
	echo form('profile', 'delete').hidden('confirm', 'yes').submit(_('Yes'), 'class="delbutton"').'</form></td><td>';
	echo form('profile').submit(_('No'), 'class="backbutton"').'</form></td><tr></table>';
	print_end();
}

// --- inbox function ... to show inbox ...
function send_inbox () : void
{
	global $U, $dbo, $language;

	$lang		 = '&lang=' . $language;
	$nncc 		 = '&nc='   . substr(time(), -6);
	$removeEmbed = false;
	$timestamps	 = false;
	$direction	 = 'DESC';

	$DateFormat  = get_setting('dateformat');

	if (!$U['embed'] && get_setting('imgembed')) {
		$removeEmbed = true;
	}

	if ($U['timestamps'] && !empty($DateFormat)) {
		$timestamps	 = true;
	}

	if ($U['sortupdown']) {
		$direction	 = 'ASC';
	}

	print_start('inbox');

	echo '<br>';
	echo form('inbox', 'clean') . submit(_('Delete selected messages'), 'class="delbutton"') . '<br><br>';


	$stmt = $dbo->prepare('SELECT id, postdate, text FROM ' . PREFIX . "inbox WHERE recipient=? ORDER BY id $direction;");
	$stmt->execute([$U['nickname']]);
	while ($message = $stmt->fetch(PDO::FETCH_ASSOC)) {
		prepare_message_print($message, $removeEmbed);
		
		echo "<div class=\"msg\"><label><input type=\"checkbox\" name=\"mid[]\" value=\"$message[id]\">";

		if ($timestamps) {
			echo ' <small>'.date($DateFormat, $message['postdate']).' - </small>';
		}

		$message['text'] = create_message_reference_link ( $message, $lang, $nncc );

		echo " $message[text]</label></div>";
	}

	echo '</form>';
	echo '<br><br>'.form('view').submit(_('Back to the chat.'), 'class="backbutton"').'</form>';

	print_end();
}

// --- inbox function ... to delete selected message in inbox ...
function clean_inbox_selected () : void
{
	global $U, $dbo;

	if (isset($_POST['mid'])) {
		$stmt = $dbo->prepare('DELETE FROM ' . PREFIX . 'inbox WHERE id=? AND recipient=?;');
		foreach ($_POST['mid'] as $mid) {
			$stmt->execute([$mid, $U['nickname']]);
		}
	}
}

?>