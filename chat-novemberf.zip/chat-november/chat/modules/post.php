<?php

/*
	function send_alert ( string $alert ) : void
	{
		print_start();
		echo '<span style="color: var(--accent); font: bold italic large arial;">'.$alert.'</span><br><br>';
		echo form_target('post', 'post') . submit('close', 'class="backbutton"') . '</form>';
		print_end();
	}
	// Into the send_post
	if (!empty($alert)) {
		send_alert ();
	}

	// and in validate input you call it

	send_alert ('!!! Please TAG your pics !!!');
*/	 
	 

function build_firstline ($disablepm, $rejected, $multi, $where, $filter) : void
{
	global $U;

	echo '<table>';
	echo '<tr id="firstline">';
		// User's nickname (1)
		echo '<td>'.style_this(htmlspecialchars($U['nickname']), (string) $U['style']).'</td>';
		// double point (2)
		echo '<td>:</td>';
		// Text area (3)
		if ($multi == true) {
			echo "<td><textarea name=\"message\" rows=\"3\" cols=\"40\" style=\"$U[style]\" autofocus>$rejected</textarea></td>";
		} else {
			echo "<td><input type=\"text\" name=\"message\" value=\"$rejected\" size=\"40\" style=\"$U[style]\" autofocus></td>";
		}
		// Send To button (4)
		echo '<td>'.submit(_('Send to')).'</td>';
		// Dropdown box with where to send message (5)
		echo '<td>';
		if (empty($filter)) {
			build_sendto_drop ($disablepm, $where);
		} else {
			echo '<label style="font-size:20px;">'.style_this( $filter, get_member_style ($filter)).'</label>';
		}
		echo '</td>';
	echo '</tr>';
	echo '</table>';

	return;
}

function build_secondline ($disablepm) : void
{
	global $U;

	echo '<table>';
	echo '<tr id="secondline">';
		// File upload button (1)
		if (get_setting('enfileupload') > 0 && get_setting('enfileupload') <= $U['status']) {
			if (are_links_allowed($U['roomid'])) {
				printf('<td><input id="getfile" type="file" name="file"><small> '._('Max %d KB').' </small></td>', get_setting('maxuploadsize'));
			} else {
				echo '<td>&nbsp;</td>';
			}
		} else {
			echo '<td>&nbsp;</td>';
		}
		
		// Kick & Purge message check boxes
		if (!$disablepm && ($U['status'] >= 5 || ($U['status'] >= 3 && (get_setting('memkickalways') || (get_mods_count() == 0 && get_setting('memkick')))))) {
			// Kick (2)
			echo '<td><label><input type="checkbox" name="kick" id="kick" value="kick">'._(' Kick').'</label></td>';
			// Purge (3)
			echo '<td><label><input type="checkbox" name="what" id="what" value="purge" checked>'._(' Also purge messages').'</label></td>';
		} else {
			echo '<td>&nbsp;</td>';
			echo '<td>&nbsp;</td>';
		}

	echo '</tr>';
	echo '</table>';

	return;
}

function build_thirdline ($multi, $whos, $filter ) : void
{
	echo '<table>';
	echo '<tr id="thirdline">';

	// Delete only last message (1)
	echo '<td>';
	echo form('delete');
	if ($multi == true) {
		echo hidden('multi', 'on');
	}
	echo hidden('sendto', $filter);
	echo hidden('filter', $filter);
	echo hidden('sendto', htmlspecialchars($whos)).hidden('what', 'last');
	echo submit(_('Delete last message'), 'class="delbutton"');
	echo '</form></td>';

	// Delete all messages (2)
	echo '<td>'.form('delete');
	if ($multi == true) {
		echo hidden('multi', 'on');
	}
	if (empty($filter)) {
		echo hidden('sendto', htmlspecialchars($whos)).hidden('what', 'all');
		echo submit(_('Delete all messages'), 'class="delbutton"'); 
	} else {
		echo hidden('sendto', $filter);
		echo hidden('filter', $filter);
		echo hidden('sendto', htmlspecialchars($whos)).hidden('what', 'conv');
		echo submit(_('Delete conversation'), 'class="delbutton"');
	}
	echo '</form></td>';

	// Spacer (3)
	echo '<td class="spacer"></td>';

	// Switch from single to multi line (4)
	echo '<td>'.form('post');
	echo hidden('filter', $filter);
	echo hidden('sendto', htmlspecialchars($whos));
	if ($multi == true) {
		echo submit(_('Switch to single-line'));
	} else {
		echo hidden('multi', 'on').submit(_('Switch to multi-line'));
	}
	echo '</form></td>';

	// Leave conversation mode button 
	if (!empty($filter)) {
		// Spacer (5)
		echo '<td class="spacer"></td>';

		// Save conversation (6))
		echo '<td>';
		echo form('conv');
		echo hidden('save'	, $filter);
		echo hidden('filter', $filter);
		echo hidden('sendto', $filter);
		echo submit(_('Save conversation'), 'class="saveconv"');
		echo '</form>';
		echo '</td>';

		// Spacer (7)
		echo '<td class="spacer"></td>';

		// Leave conversation (8))
		echo '<td>';
		echo form_target('_top', 'conv');
		echo hidden('sendto', '');
		echo hidden('filter', '');
		echo submit(_('Leave conversation'), 'class="leaveconv"');
		echo '</form>';
		echo '</td>';
	}

	// Closing table for the thirdline
	echo '</tr>';
	echo '</table>';

	return;
}

function build_sendto_drop ( $disablepm, $where ) : void
{
	global $U, $dbo;

	echo '<select name="sendto" size="1">';
	echo '<option ';
	if ($where === 's *') {
		echo 'selected ';
	}
	echo 'value="s *">-'._('All chatters').'-</option>';
	// Modification added an option to send to all rooms.
	if (get_setting('allow_rooms')) {
		// Only Mod's and up can write to all room's
		if ($U['status'] >= 5) {
			echo '<option ';
			if ($where === 'r @') {
				echo 'selected ';
			}
			echo 'value="r @">-'._('All Rooms').'-</option>';
		}
	}
	if (get_setting('suguests')) {
		if ($U['status'] >= 2) {
			echo '<option ';
			if ($where === 's !') {
				echo 'selected ';
			}
			echo 'value="s !">-'._('Friends only').'-</option>';
		}	
	}
	if ($U['status'] >= 3) {
		echo '<option ';
		if ($where === 's ?') {
			echo 'selected ';
		}
		echo 'value="s ?">-'._('Members only').'-</option>';
	}
	if ($U['status'] >= 5) {
		echo '<option ';
		if ($where === 's %') {
			echo 'selected ';
		}
		echo 'value="s %">-'._('Staff only').'-</option>';
	}
	if ($U['status'] >= 6 ) {
		echo '<option ';
		if ($where === 's _') {
			echo 'selected ';
		}
		echo 'value="s _">-'._('Admin only').'-</option>';
	}

	// Si les pm's sont autorisés, on ajoute la liste des utilisateurs
	if (!$disablepm) {
		// preparation du tableau en filtrant les utiliseur deconnecté, et ceux ignonrés par l'utilisateur, ou en mode Incognito
		$users=[];
		$stmt=$dbo->prepare('SELECT * FROM (SELECT nickname, style, 0 AS offline FROM ' . PREFIX . 'sessions WHERE entry!=0 AND status>0 AND incognito=0 UNION SELECT nickname, style, 1 AS offline FROM ' . PREFIX . 'members WHERE eninbox!=0 AND eninbox<=? AND nickname NOT IN (SELECT nickname FROM ' . PREFIX . 'sessions WHERE incognito=0)) AS t WHERE nickname NOT IN (SELECT ign FROM '. PREFIX . 'ignored WHERE ignby=? UNION SELECT ignby FROM '. PREFIX . 'ignored WHERE ign=?) ORDER BY LOWER(nickname);');
		$stmt->execute([$U['status'], $U['nickname'], $U['nickname']]);
		while ($tmp=$stmt->fetch(PDO::FETCH_ASSOC)) {
			if ($tmp['offline']) {
				$users[] = ["$tmp[nickname] "._('(offline)'), $tmp['style'], $tmp['nickname']];
			} else {
				$users[] = [$tmp['nickname'], $tmp['style'], $tmp['nickname']];
			}
		}
		// Transfert du tableau vers les options de la dropdown
		foreach ($users as $user) {
			if ($U['nickname'] !== $user[2]) {
				echo '<option ';
				if ($where == $user[2]) {
					echo 'selected ';
				}
				echo 'value="'.htmlspecialchars($user[2])."\" style=\"$user[1]\">".htmlspecialchars($user[0]).'</option>';
			}
		}
	}
	echo '</select>';

	return;
}

function send_post (string $rejected = '', array $error = []) : void
{
	global $U;

	print_start('post');
	$SendTo				= '';
	$MultiLine			= false;
	$filter				= '';
	$hide_smiley_post	= (bool) get_setting('hide_smiley_post');
	$disablepm 			= (bool) get_setting('disablepm');

	if (!isset($_REQUEST['sendto'])) {
		$_REQUEST['sendto'] = '';
	} else {
		$SendTo		= $_REQUEST['sendto'];
	}

	if (isset($_REQUEST['msg'])) {
		$rejected	= $_REQUEST['msg'] . " " . $rejected;
	} elseif (isset($_REQUEST['nickname'])) {
		$rejected	= '@' . $_REQUEST['nickname'] . ", ". $rejected;
	} elseif (isset($_REQUEST['mention'])) {
		$rejected	= '@' . $_REQUEST['mention'] . ", ". $rejected;		
	}

	if (isset($_POST['multi'])) {
		$MultiLine	= true;
	}

	if (isset($_REQUEST['filter'])) {
		$filter		= $_REQUEST['filter'];
	}

	if (count($error)) {
		$MultiLine	= $error['multi'];
		$rejected	= $error['message'];
		$SendTo		= $error['sendto'];
		$ErrMess	= $error['error'];
	}


	// Main table with 3 areas ( start 20% middle 60% end 20% )
	echo '<table width="100%"><tr>';

	if (!empty($ErrMess)) {
		echo '<td colspan="3" style="background-color:#FF0000;color:#FFFFFF;font-size:14px;">'.$ErrMess.'</td>';
		echo '</tr><tr>';
	}

	// Start area (for tag's & extra buttons)
	echo '<td width="20%" valign="top">';
	echo '<table id="tagdrops"><tr>';
	if (get_setting('allow_emojis')) {
		if (!$hide_smiley_post) {
			echo '<td colspan="2">' . form_target( '_blank', 'smiley' ) . submit( _('Emojis'), 'id="smileybutton"' ) . '</form></td>';
			echo '</tr><tr>';
		}
	}

	// Post form ... Get all control's from tag's to text box, including member's list to send a pm ... and the SendTo button !!!
	echo form('post');
 	if (!empty($filter)) {
		echo hidden('filter', (string) $filter);
		echo hidden('sendto', $filter);
	}

	echo hidden('postid', $U['postid']);

	if (empty($filter))	{
		if (get_setting('allow_tags')) {
			$only_one = get_setting('only_one_tag');
	
			echo insert_tag_drop ( (bool) $only_one );
		}
	}
	echo '</tr></table>';

	// Middle area ( typing zone )
	echo '<td width="60%" valign="top">';
	echo '<table>';
	echo '<tr><td>';
	if ($MultiLine == true) {
		echo hidden('multi', 'on');
	}
	build_firstline ($disablepm, $rejected, $MultiLine, $SendTo, $filter);
	echo '</td></tr><tr><td>';
	build_secondline ($disablepm);
	// End of post form ... for the thirdline, there individual form's for each button
	echo '</form>';
	echo '</td></tr><tr><td>';
	build_thirdline ($MultiLine, $SendTo, $filter);
	echo '</td></tr>';
    echo '</table>';
	echo '</td>';

	// End area ( post rules & room's )
	echo '<td width="20%" valign="top">';
	echo '<table id="rooms">';

	echo '<tr>';

	if (empty($filter))	{
		if (get_setting('allow_news_button')) {
			echo '<td width="30%">' . form_target( 'view', 'news' ) . submit( _('News'), 'class="backbutton"' ) . '</form></td>';
		} else {
			echo '<td width="30%">&nbsp;</td>';
		}
		if ((int)get_setting('allow_posthelp')) {
			echo '<td width="40%">' . form_target( 'view', 'phelp' ) . submit( _('Post Rules'), 'class="backbutton"' ) . '</form></td>';
		} else {
			echo '<td width="30%">&nbsp;</td>';
		}
		if (get_setting('allow_links_button')) {
			echo '<td width="30%">' . form_target( 'view', 'links' ) . submit( _('Links'), 'class="backbutton"' ) . '</form></td>';
		} else {
			echo '<td width="30%">&nbsp;</td>';
		}
		echo '</tr>';

		if ($U['status'] >= (int)get_setting('roomaccess')) {
			if (get_setting('allow_rooms')) {
				echo '<tr><td colspan="3">';
				print_rooms();
				echo '</td>';
			}
		}
	}

	echo '</tr>';
	echo '</table>';

	echo '</td></tr></table>';


	print_end();
}

function are_links_allowed ($RoomId) : bool
{
	global $dbo;

	$bResult = true;

	// Check for main room
	if ($RoomId === null) {
		if (get_setting('allow_link_in_main') == 0) {
			$bResult = false;
		}
	// For room's
	} else {
		$stmt = $dbo->prepare('SELECT * FROM ' . PREFIX . 'rooms WHERE id = ?;');
		$stmt->execute([$RoomId]);
		$Room = $stmt->fetch(PDO::FETCH_ASSOC);
		if ($Room['withlink'] == 0) {
			$bResult = false;
		}
	}

	return $bResult;
}

function get_poststatus ($SendTo) : int 
{

	return 1;
}

function get_last_link_id () : int 
{
	$LinkId = 455;

	return $LinkId;
}

function validate_input () : string 
{
	global $U, $dbo, $language;

	$inbox			= false;
	$ReferTo		= '';
	$SendTo 		= '';
	$recipient		= '';
	$Urls			= [];
	$Count			= get_last_link_id ();
	$filter			= '';

	$maxmessage		= get_setting('maxmessage');
	$nicktags		= get_setting('nicktags');
	$allow_tags		= get_setting('allow_tags');
	$Deny_pms		= get_setting('disablepm');

	$message		= mb_substr($_POST['message'], 0, $maxmessage);
	$rejected		= mb_substr($_POST['message'], $maxmessage);
	$msgtime		= time();


	if (isset($_POST['filter'])) {
		$filter 	= $_POST['filter'];
	}

	if (isset($_POST['sendto'])) {
		$SendTo 	= $_POST['sendto'];
	}

	if (!are_links_allowed($U['roomid'])) {
		$bFileExist = false;
		$SendTo2c	= substr($SendTo, 0 ,2);
		$lSendTo	= strlen($SendTo);
		if ($lSendTo == 3 && $SendTo2c == 's ') {
			// Does we have a file to upload ??
			if (isset($_FILES['file'])) {
				if (!empty($_FILES['file']['name'])) {
					// Yes we have a file to upload !!
					$bFileExist = true;
				}
			}
			// Brutal way to check if there is a file link in the post
			$Lt 			= create_hotlinks( $message, $Count, $Urls );
			if ($Lt != $message) {
				// Yes there is a link in the message
				$bFileExist = true;
			}
			if ($bFileExist == true) {
				if (isset($_POST['multi'])) {
					$Multi		= $_POST['multi'];
				} else {
					$Multi		= '';
				}
				$Current['message']	= $_POST['message'];
				$Current['sendto']	= $SendTo;
				$Current['multi']	= $Multi;
				$Current['error']	= _('No links allowed in this room');
				send_post('', $Current);
			}		
		} else {
			// SendTo > 3 = NickName for a PM
		}
	}

	// auto-kick spammers not setting a postid
	if (!isset($_POST['postid'])) { 
		if ($U['status'] < 8 ) {
			kick_chatter([$U['nickname']], '', false);
		}
	}

	// reject bogus messages
	if ($U['postid'] !== $_POST['postid'] || (time() - $U['lastpost']) <= 1) { 
		$rejected = $_POST['message'];
		$message  = '';
	}

	/* */
	// ignore double post = reload from browser or proxy
	if ($U['postid'] === $_REQUEST['postid']) {
		// $message = '';
		$message = $message;
	// time between posts too short, reject!
	} elseif ((time() - $U['lastpost']) <= 1) {
		$rejected = $_REQUEST['message'];
		$message = '';
	}
	/* */
		 
		 

	if (!empty($rejected)) {
		$rejected = trim($rejected);
		$rejected = htmlspecialchars($rejected);
	}

	$message      = htmlspecialchars($message, ENT_NOQUOTES);
	$message      = preg_replace("/(\r?\n|\r\n?)/u", '<br>', $message);
	if (isset($_POST['multi'])) {
		$message  = preg_replace('/\s*<br>/u', '<br>', $message);
		$message  = preg_replace('/<br>(<br>)+/u', '<br><br>', $message);
		$message  = preg_replace('/<br><br>\s*$/u', '<br>', $message);
		$message  = preg_replace('/^<br>\s*$/u', '', $message);
	} else {
		$message  = str_replace('<br>', ' ', $message);
	}
	
	$message      = trim($message);
	$message      = preg_replace('/\s+/u', ' ', $message);

	$nncc		 = '';
	$nocache	 = substr(time(),-6);
	if ($nicktags) {
		$nncc = '';
		$lang = '&lang=' . $language;
		$nncc = '&nc=' . $nocache;
		$nick = '&nickname='.$U['nickname'];
		$send = '&sendto=' . $SendTo;
		$nicklink   = '<a class="nicklink" href="'.$_SERVER['SCRIPT_NAME'].'?action=post'. $lang . $nncc . $nick . $send.'" target="post" >'. style_this(htmlspecialchars($U['nickname']), $U['style']) .'</a>';
	}

	// Send to room
	if ($SendTo === 's *') {
		$poststatus = 1;
		if ($nicktags) {
			$displaysend=sprintf(get_setting('msgsendall'), $nicklink );
		} else {
			$displaysend=sprintf(get_setting('msgsendall'), style_this(htmlspecialchars($U['nickname']), $U['style']));
		}
	// Send to Friends channel
	} elseif ($SendTo === 's !' && $U['status'] >= 2) {
		$poststatus = 2;
		if ($nicktags) {
			$displaysend=sprintf(get_setting('msgsendsge'), $nicklink );
		} else {
			$displaysend=sprintf(get_setting('msgsendsge'), style_this(htmlspecialchars($U['nickname']), $U['style']));
		}
	// Send to Members channel
	} elseif ($SendTo === 's ?' && $U['status'] >=3 ) {
		$poststatus = 3;
		if ($nicktags) {
			$displaysend=sprintf(get_setting('msgsendmem'), $nicklink );
		} else {
			$displaysend=sprintf(get_setting('msgsendmem'), style_this(htmlspecialchars($U['nickname']), $U['style']));
		}
	// Send to Staff channel
	} elseif ($SendTo === 's %' && $U['status'] >= 5) {
		$poststatus = 5;
		if ($nicktags) {
			$displaysend=sprintf(get_setting('msgsendmod'), $nicklink );
		} else {
			$displaysend=sprintf(get_setting('msgsendmod'), style_this(htmlspecialchars($U['nickname']), $U['style']));
		}
   	// Modifcation added all rooms channel
	} elseif ($SendTo === 'r @' && $U['status'] >=5 ) {
		$poststatus = 1;
		if ($nicktags) {
			$displaysend=sprintf('[All Rooms] %s - ', $nicklink );
		} else {
			$displaysend=sprintf('[All Rooms] %s - ', style_this(htmlspecialchars($U['nickname']), $U['style']));
		}
	// Send to Admin channel
	} elseif ($SendTo === 's _' && $U['status'] >= 6) {
		$poststatus = 6;
		if ($nicktags) {
			$displaysend=sprintf(get_setting('msgsendadm'), $nicklink );
		} else {
			$displaysend=sprintf(get_setting('msgsendadm'), style_this(htmlspecialchars($U['nickname']), $U['style']));
		}
	// Send to yourself ????
	} elseif ($SendTo === $U['nickname']) {
		return '';
	// Send to a give nick (that is a PM)
	} else { 
		// Check if PM are enabled
		if ($Deny_pms) {
			return '';
		}

		// Is the given user ignoring you ??? 
		$stmt = $dbo->prepare('SELECT null FROM ' . PREFIX . 'ignored WHERE (ignby=? AND ign=?) OR (ign=? AND ignby=?);');
		$stmt->execute([$SendTo, $U['nickname'], $SendTo, $U['nickname']]);
		if ($stmt->fetch(PDO::FETCH_NUM)) {
			return '';
		}

		// Is the given user online ? or/and does he have the offline inbox enable ?
		$stmt = $dbo->prepare('SELECT s.style, 0 AS inbox FROM ' . PREFIX . 'sessions AS s LEFT JOIN ' . PREFIX . 'members AS m ON (m.nickname=s.nickname) WHERE s.nickname=? AND (s.incognito=0 OR (m.eninbox!=0 AND m.eninbox<=?));');
		$stmt->execute([$SendTo, $U['status']]);
		if (!$tmp = $stmt->fetch(PDO::FETCH_ASSOC)) {
			// The given user is off line now, but is his offline inbow open ? and does it accept posts from your level ??
			$stmt = $dbo->prepare('SELECT style, 1 AS inbox FROM ' . PREFIX . 'members WHERE nickname=? AND eninbox!=0 AND eninbox<=?;');
			$stmt->execute([$SendTo, $U['status']]);
			if (!$tmp = $stmt->fetch(PDO::FETCH_ASSOC)) {
				// You cannot send to his offline inbow for some reason
				return '';
			}
		}

		$recipient  = $SendTo;
		$poststatus = 9;

		if ($nicktags) {
			$lang		= '&lang=' . $language;
			$send 		= '&sendto=';
			$U1pmlink	= '<a class="nicklink" href="'.$_SERVER['SCRIPT_NAME'].'?action=post'. $lang . $nncc . $send . $U['nickname'] .'" target="post" ><span title="private message to '.$U['nickname'].'">'. style_this(htmlspecialchars($U['nickname']), $U['style']) .'</span></a>';
			$U2pmlink	= '<a class="nicklink" href="'.$_SERVER['SCRIPT_NAME'].'?action=post'. $lang . $nncc . $send . $recipient .'" target="post" ><span title="private message to '. $recipient .'">'. style_this(htmlspecialchars($recipient), $tmp['style']) .'</span></a>';
		} else {
			$U1pmlink	= style_this(htmlspecialchars($U['nickname']), $U['style']);
			$U2pmlink	= style_this(htmlspecialchars($recipient), $tmp['style']);
		}

		$displaysend=sprintf(get_setting('msgsendprv'), $U1pmlink , $U2pmlink );
		$inbox = $tmp['inbox'];
	}

	// found the /me directive and handle it
	if ($poststatus !==9 && preg_match('~^/me~iu', $message)) {
		$displaysend = style_this(htmlspecialchars("$U[nickname] "), $U['style']);
		$message     = preg_replace("~^/me\s?~iu", '', $message);
	}
	$message = apply_filter($message, $poststatus, $U['nickname']);

	$message = create_hotlinks ( $message, $Count,  $Urls );

	$message = apply_linkfilter ( $message );
	if ( $allow_tags ) {
		$tags = apply_tags();
		if (!empty($tags)) {
			$message = $tags . $message;
		}
	}
	if (!empty($ReferTo)) {
		$message = $ReferTo . $message;
	}

	// Validate an upload from a file to your server
	if (isset($_FILES['file']) && get_setting('enfileupload') > 0 && get_setting('enfileupload') <= $U['status']) {
		if ($_FILES['file']['error'] === UPLOAD_ERR_OK && $_FILES['file']['size'] <= (1024*get_setting('maxuploadsize'))) {
			$hash = sha1_file($_FILES['file']['tmp_name']);
			$name = htmlspecialchars($_FILES['file']['name']);
			$linkname = $name;
			if (strlen($name) >12 ) {
				$linkname = substr($name, strlen($name)-12, 12);
			}
			$id 		= '&id='.$hash;
			$lName		= '&name=' . $name;
			$message	= sprintf(get_setting('msgattache'), '<a class="attachement" href="'.$_SERVER['SCRIPT_NAME'].'?action=download'. $id . $lName . '" target="_blank"><span class="urlpict"><span class="urlpicta">'.$linkname.'</span></span></a>', $message);
		}
	}

	if (add_message($message, $recipient, $U['nickname'], (int) $U['status'], $poststatus, $displaysend, $U['style'], $msgtime)) {
		$U['lastpost'] = $msgtime;
		try {
			$U['postid'] = bin2hex( random_bytes( 3 ) );
		} catch(Exception $e) {
			$U['postid'] = substr(time(), -6);
		}
		$stmt = $dbo->prepare('UPDATE ' . PREFIX . 'sessions SET lastpost=?, postid=? WHERE session=?;');
		$stmt->execute([$U['lastpost'], $U['postid'], $U['session']]);
		$stmt = $dbo->prepare('SELECT id FROM ' . PREFIX . 'messages WHERE poster=? ORDER BY id DESC LIMIT 1;');
		$stmt->execute([$U['nickname']]);
		$id   = $stmt->fetch(PDO::FETCH_NUM);
		if ($inbox && $id) {
			$newmessage = [
				'postdate'	=> $msgtime,
				'poster'	=> $U['nickname'],
				'recipient'	=> $recipient,
				'text'		=> "<span class=\"usermsg\">$displaysend".style_this($message, $U['style']).'</span>'
			];
			if (MSGENCRYPTED) {
				try {
					$newmessage[ 'text' ] = base64_encode( sodium_crypto_aead_aes256gcm_encrypt( $newmessage[ 'text' ], '', AES_IV, ENCRYPTKEY ) );
				} catch (SodiumException $e) {
					send_error($e->getMessage());
				}
			}
			$stmt = $dbo->prepare('INSERT INTO ' . PREFIX . 'inbox (postdate, postid, poster, recipient, text) VALUES(?, ?, ?, ?, ?)');
			$stmt->execute([$newmessage['postdate'], $id[0], $newmessage['poster'], $newmessage['recipient'], $newmessage['text']]);
		}
		if (isset($hash) && $id) {
			if (function_exists('mime_content_type')) {
				$type = mime_content_type($_FILES['file']['tmp_name']);
			} elseif (!empty($_FILES['file']['type']) && preg_match('~^[a-z0-9/\-.+]*$~i', $_FILES['file']['type'])){
				$type = $_FILES['file']['type'];
			}else{
				$type = 'application/octet-stream';
			}
			$name = htmlspecialchars($_FILES['file']['name']);
			// Write uploaded image or file to the db
			$stmt = $dbo->prepare('INSERT INTO ' . PREFIX . 'files (postid, hash, filename, type, data) VALUES (?, ?, ?, ?, ?);');
			$stmt->execute([$id[0], $hash, str_replace('"', '\"', $name), $type, base64_encode(file_get_contents($_FILES['file']['tmp_name']))]);
			unlink($_FILES['file']['tmp_name']);
		}
	}
	return $rejected;
}

function create_hotlinks ( string $message, int &$LinkCount, array &$LinkUrls ) : string 
{
	//Make hotlinks for URLs, redirect through dereferrer script to prevent session leakage
	// 1. all explicit schemes with whatever xxx://yyyyyyy
	$message = preg_replace('~(^|[^\w"])(\w+://[^\s<>]+)~iu', "$1<<$2>>", $message);
	// 2. valid URLs without scheme:
	$message = preg_replace('~((?:[^\s<>]*:[^\s<>]*@)?[a-z0-9\-]+(?:\.[a-z0-9\-]+)+(?::\d*)?/[^\s<>]*)(?![^<>]*>)~iu', "<<$1>>", $message);						// server/path given
	$message = preg_replace('~((?:[^\s<>]*:[^\s<>]*@)?[a-z0-9\-]+(?:\.[a-z0-9\-]+)+:\d+)(?![^<>]*>)~iu', "<<$1>>", $message);									// server:port given
	$message = preg_replace('~([^\s<>]*:[^\s<>]*@[a-z0-9\-]+(?:\.[a-z0-9\-]+)+(?::\d+)?)(?![^<>]*>)~iu', "<<$1>>", $message);									// au:th@server given
	// 3. likely servers without any hints but not filenames like *.rar zip exe etc.
	$message = preg_replace('~((?:[a-z0-9\-]+\.)*(?:[a-z2-7]{55}d|[a-z2-7]{16})\.onion)(?![^<>]*>)~iu', "<<$1>>", $message);									// *.onion
	$message = preg_replace('~([a-z0-9\-]+(?:\.[a-z0-9\-]+)+(?:\.(?!rar|zip|exe|gz|7z|bat|doc)[a-z]{2,}))(?=[^a-z0-9\-.]|$)(?![^<>]*>)~iu', "<<$1>>", $message);	// xxx.yyy.zzz
	// Convert every <<....>> into proper links:
	$message = preg_replace_callback('/<<([^<>]+)>>/u',
		function ($matches) use (&$LinkCount, &$LinkUrls) {
			$FoundUrl	= $matches[1];
			if ( strpos($FoundUrl, '://') === false ) {
				$FoundDes = $FoundUrl;
				$FoundUrl = 'http://'.$FoundUrl;
			} else {
				$FoundDes = substr( $FoundUrl, strpos($FoundUrl, '://') + 3);
			}
			$LinkCount++;
			$linkNbr 	= sprintf ('link-%06d', $LinkCount);
			$LinkUrls[] = $FoundUrl;
			$HotLink 	= '<span class="'.$linkNbr.'"><a href="'.$FoundUrl.'" target="_blank" rel="noreferrer noopener">'.$FoundDes.'</a><span class="trigger"></span></span>';

			return $HotLink;
		}
	, $message);

	return $message;
}

function apply_mention (string $message) : string 
{
	return preg_replace_callback ('/@([^\s]+)/iu', function ($matched) {
		global $dbo;

		$nick	= htmlspecialchars_decode($matched[1]);
		$rest	= '';
		for ($i = 0; $i <= 3; ++$i) {
			// match case-sensitive present nicknames
			$stmt	= $dbo->prepare('SELECT style FROM ' . PREFIX . 'sessions WHERE nickname = ?;');
			$stmt->execute([$nick]);
			if ($tmp	= $stmt->fetch(PDO::FETCH_NUM)) {
				return style_this(htmlspecialchars("@$nick"), $tmp[0]).$rest;
			}

			// match case-insensitive present nicknames
			$stmt	= $dbo->prepare('SELECT style FROM ' . PREFIX . 'sessions WHERE LOWER(nickname) = LOWER(?);');
			$stmt->execute([$nick]);
			if ($tmp	= $stmt->fetch(PDO::FETCH_NUM)) {
				return style_this(htmlspecialchars("@$nick"), $tmp[0]).$rest;
			}

			// match case-sensitive members
			$stmt	= $dbo->prepare('SELECT style FROM ' . PREFIX . 'members WHERE nickname = ?;');
			$stmt->execute([$nick]);
			if ($tmp	= $stmt->fetch(PDO::FETCH_NUM)) {
				return style_this(htmlspecialchars("@$nick"), $tmp[0]).$rest;
			}

			// match case-insensitive members
			$stmt	= $dbo->prepare('SELECT style FROM ' . PREFIX . 'members WHERE LOWER(nickname) = LOWER(?);');
			$stmt->execute([$nick]);
			if ($tmp	= $stmt->fetch(PDO::FETCH_NUM)) {
				return style_this(htmlspecialchars("@$nick"), $tmp[0]).$rest;
			}
			if (strlen($nick) === 1) {
				break;
			}
			$rest	= mb_substr($nick, -1).$rest;
			$nick	= mb_substr($nick, 0, -1);
		}
		return $matched[0];
	}, $message);
}

function add_message (string $message, string $recipient, string $poster, int $delstatus, int $poststatus, string $displaysend, string $style, $postdate) : bool 
{
	global $dbo, $U;
	if ($message==='') {
		return false;
	}

	//Modifications for chat rooms
	$roomid = $U['roomid'];
	if(isset($_POST['sendto']) && $_POST['sendto']==='r @' && $U['status'] >= 5) {
		$allrooms = 1;
		$roomid   = null;
	}else{
		$allrooms = 0;
	}

	$newmessage = [
		'postdate'		=> $postdate,
		'poststatus'	=> $poststatus,
		'poster'		=> $poster,
		'recipient'		=> $recipient,
		'text'			=> '<span class="usermsg">'. $displaysend . style_this($message, $style).'</span>',
		'delstatus'		=> $delstatus,
		'roomid'		=> $roomid,
		'allrooms'		=> $allrooms
	];

	//Modifcation chat rooms
	if ($newmessage['roomid'] === NULL) {
		// Prevent posting the same message twice, if no other message was posted in-between.
		$stmt = $dbo->prepare('SELECT id FROM ' . PREFIX . 'messages WHERE poststatus=? AND poster=? AND recipient=? AND text=? AND roomid IS NULL AND id IN (SELECT * FROM (SELECT id FROM ' . PREFIX . 'messages ORDER BY id DESC LIMIT 1) AS t);');
		$stmt->execute([$newmessage['poststatus'], $newmessage['poster'], $newmessage['recipient'], $newmessage['text']]);
	} else {
		$stmt = $dbo->prepare('SELECT id FROM ' . PREFIX . 'messages WHERE poststatus=? AND poster=? AND recipient=? AND text=? AND roomid=? AND id IN (SELECT * FROM (SELECT id FROM ' . PREFIX . 'messages ORDER BY id DESC LIMIT 1) AS t);');
		$stmt->execute([$newmessage['poststatus'], $newmessage['poster'], $newmessage['recipient'], $newmessage['text'], $newmessage['roomid']]);
	}
	if ($stmt->fetch(PDO::FETCH_NUM)) {
		return false;
	}

	$MsgId = write_message($newmessage);
	return true;
}

function add_system_message ($mes, $doer, $roomid=NULL)
{
	if ($mes==='') {
		return;
	}
	if($doer==='' || !get_setting('namedoers')){
		$sysmessage=[
			'postdate'		=> time(),
			'poststatus'	=> 4,
			'poster'		=> '',
			'recipient'		=> '',
			'text'			=> '<span class="sysmsg">'.$mes.'</span>',
			'delstatus'		=> 4,
			'roomid'    	=> $roomid,
			'allrooms'		=> 0
			];

	} else {
		$sysmessage=[
			'postdate'		=> time(),
			'poststatus'	=> 4,
			'poster'		=> '',
			'recipient'		=> '',
			'text'			=> '<span class="sysmsg">'.$mes.' ('.$doer.')</span>',
			'delstatus'		=> 4,
			'roomid'    	=> $roomid,
			'allrooms'		=> 0
			];
	}
	write_message($sysmessage);
}
	
function write_message (array $message) 
{
	global $dbo;
	if (MSGENCRYPTED) {
		try {
			$message['text']=base64_encode(sodium_crypto_aead_aes256gcm_encrypt($message['text'], '', AES_IV, ENCRYPTKEY));
		} catch (SodiumException $e){
			send_error($e->getMessage());
		}
	}
	// Modification rooms .. insert roomid & allrooms to be saved to the message
	$stmt	= $dbo->prepare('INSERT INTO ' . PREFIX . 'messages (postdate, poststatus, poster, recipient, text, delstatus, roomid, allrooms) VALUES (?, ?, ?, ?, ?, ?, ?, ?);');
	$stmt->execute([$message['postdate'], $message['poststatus'], $message['poster'], $message['recipient'], $message['text'], $message['delstatus'], $message['roomid'], $message['allrooms']]);
	$LastId = $dbo->LastInsertId();
	if ($message['poststatus'] < 9 && get_setting('sendmail')) {
		$subject	= 'New Chat message';
		$headers	= 'From: '.get_setting('mailsender')."\r\nX-Mailer: PHP/".phpversion()."\r\nContent-Type: text/html; charset=UTF-8\r\n";
		$body='<html><body style="background-color:#'.get_setting('colbg').';color:#'.get_setting('coltxt').";\">$message[text]</body></html>";
		mail(get_setting('mailreceiver'), $subject, $body, $headers);
	}
	return $LastId;
}

function send_del_confirm () : void
{
	print_start ('del_confirm');
	echo '<br>';
	echo '<table><tr>';
	echo '<td colspan="2">'._('Are you sure?').'</td>';
	echo '</tr><tr>';

	echo '<td>'.form('delete');
	if (isset($_POST['multi'])) {
		echo hidden('multi', 'on');
	}
	if (isset($_POST['sendto'])) {
		echo hidden('sendto', $_POST['sendto']);
	}
	if (isset($_POST['filter'])) {
		echo hidden('filter', $_POST['filter']);
	}
	echo hidden('confirm', 'yes');
	echo hidden('what', $_POST['what']);
	echo submit(_('Yes'), 'class="delbutton"');
	echo '</form></td>';

	echo '<td>'.form('post');
	if (isset($_POST['multi'])) {
		echo hidden('multi', 'on');
	}
	if (isset($_POST['sendto'])) {
		echo hidden('sendto', $_POST['sendto']);
	}
	if (isset($_POST['filter'])) {
		echo hidden('filter', $_POST['filter']);
	}
	echo submit(_('No'), 'class="backbutton"');
	echo '</form></td>';

	echo '<tr></table>';
	print_end();
}


?>