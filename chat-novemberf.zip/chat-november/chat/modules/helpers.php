<?php

function prepare_stylesheets (string $class) : void
{
	global $U, $dbo, $scripts, $styles;
	if ($class === 'fatal_error') {
		$styles[ 'fatal_error' ] = 'body {background-color:#000000;color:#FF0033;}';
	}
	$styles['default']  = 'body,iframe { background-color: #000000; color: #FFFFFF; font-size: 16px; text-align: center; width: 100%; height: 100%; margin: 0; padding: 0; border: none} ';
	$styles['default'] .= 'a:visited { color:#808080; } a:link { color:#808080; } a:active { color:#808080; }';
	$styles['default'] .= 'input, select, textarea { color:#FFFFFF; background-color: #000000; } ';
	$styles['default'] .= '.error { color: #FF0033; text-align: left; } .delbutton { background-color:#660000; } .backbutton { background-color:#004400; } #exitbutton { background-color:#AA0000; } ';
	$styles['default'] .= '#adminbutton { background-color: #808080; color: white; } #gallerybutton { background-color: #C0C000; color: black; } #roombutton { background-color: #008000; color: black;} #smileybutton { background-color: #00C0C0; color: black; }';
	$styles['default'] .= '.leaveconv { background-color: #00FF00; color: #0000C0; } .saveconv { background-color: #008080; color: #0000C0; } ';
	$styles['default'] .= '.setup table table,.admin table table,.profile table table {width:100%;text-align:left;} ';
	$styles['default'] .= '.alogin table,.init table,.destroy_chat table,.delete_account table,.sessions table,.rooms table,.table,.notes table,.approve_waiting table,.del_confirm table,.profile table,.admin table,.backup table,.setup table {margin-left:auto;margin-right:auto;} ';
	$styles['default'] .= '.setup table table table,.admin table table table,.profile table table table {border-spacing:0px;margin-left:auto;margin-right:unset;width:unset;} ';
	$styles['default'] .= '.setup table table td,.backup #restoresubmit,.backup #backupsubmit,.admin table table td,.profile table table td,.login td+td,.alogin td+td {text-align:right;} ';
	$styles['default'] .= '.init td,.backup #restorecheck td,.admin #clean td,.admin #regnew td,.session td,.messages,.inbox,.approve_waiting td,.choose_messages,.greeting,.help,.login td,.alogin td {text-align:left;} ';
	$styles['default'] .= '.approve_waiting #action td:only-child,.help #backcredit,.login td:only-child,.alogin td:only-child,.init td:only-child {text-align:center} .sessions td,.sessions th,.approve_waiting td,.approve_waiting th {padding: 5px;} ';
	$styles['default'] .= '.sessions td td {padding: 1px} .notes textarea {height:80vh;width:80%;} ';
	$styles['default'] .= '.post table,.controls table,.login table{border-spacing:0px;margin-left:auto;margin-right:auto;} .login table{border:2px solid;} .controls{overflow-y:none;} ';
	$styles['default'] .= '.notinroom {display:none; font-size: xx-small;} .inroom {display:block;} #roomtable {border-radius: 5px;border-spacing: 5px;margin-left:auto;margin-right:auto;border: 1px solid White;} ';
	$styles['default'] .= 'body.rooms {background-color: transparent !important; } ';
	$styles['default'] .= 'input, select, textarea, button { padding: 0.2em; border: 1px solid #ffffff; border-radius: 0.5em } ';

	if ($class === 'init' || ! $dbo instanceof PDO) {
		return;
	}

	// Specific pages default CSS style
	if ($class === 'frameset') {
		/*
		if (($U['status'] >= 5 || ($U['status'] > 2 && get_mods_count() == 0)) && get_setting('enfileupload') > 0 && get_setting('enfileupload') <= $U['status']) {
			$postheight = '120px';
		}else{
			$postheight = '120px';
		}
		*/
		$postheight = '120px';

		if ((!isset($_REQUEST['sort']) && !$U['sortupdown']) || (isset($_REQUEST['sort']) && $_REQUEST['sort'] == 0)) {
			$styles[ 'frameset' ]  = "#frameset-mid{position:fixed;top:$postheight;bottom:45px;left:0;right:0;margin:0;padding:0;overflow:hidden}";
			$styles[ 'frameset' ] .= "#frameset-top{position:fixed;top:0;left:0;right:0;height:$postheight;margin:0;padding:0;overflow:hidden;border-bottom: 1px solid}";
			$styles[ 'frameset' ] .= "#frameset-bot{position:fixed;bottom:0;left:0;right:0;height:45px;margin:0;padding:0;overflow:hidden;border-top:1px solid}";
		} else{
			$styles[ 'frameset' ]  =" #frameset-mid{position:fixed;top:45px;bottom:$postheight;left:0;right:0;margin:0;padding:0;overflow:hidden}";
			$styles[ 'frameset' ] .= "#frameset-top{position:fixed;top:0;left:0;right:0;height:45px;margin:0;padding:0;overflow:hidden;border-bottom:1px solid}";
			$styles[ 'frameset' ] .= "#frameset-bot{position:fixed;bottom:0;left:0;right:0;height:$postheight;margin:0;padding:0;overflow:hidden;border-top:1px solid}";
		}
	}
	// Default style for the filter setting page
	if ($class === 'filter') {
		$styles['filter']  = '.'. $class .' table{margin-left:auto;margin-right:auto;} ';
		$styles['filter'] .= 'table table{width:100%;} ';
		$styles['filter'] .= 'table table td:nth-child(1){width:8em;font-weight:bold;} ';
		$styles['filter'] .= 'table table td:nth-child(2),table table td:nth-child(3){width:12em;} ';
		$styles['filter'] .= 'table table td:nth-child(4){width:8em;} ';
		$styles['filter'] .= 'table table td:nth-child(5){width:9em;} ';
		$styles['filter'] .= 'table table td:nth-child(6),table table td:nth-child(7),table table td:nth-child(8),table table td:nth-child(9){width:5em;} ';
	}
	// Default style for the linkfilter setting page
	if ($class === 'linkfilter') {
		$styles['linkfilter']  = '.'. $class .' table{margin-left:auto;margin-right:auto;} ';
		$styles['linkfilter'] .= 'table table{width:100%;} ';
		$styles['linkfilter'] .= 'table table td:nth-child(1){width:8em;font-weight:bold;} ';
		$styles['linkfilter'] .= 'table table td:nth-child(2),table table td:nth-child(3){width:12em;} ';
		$styles['linkfilter'] .= 'table table td:nth-child(4){width:8em;} ';
		$styles['linkfilter'] .= 'table table td:nth-child(5),table table td:nth-child(6){width:5em;} ';
	}
	// Default style for the admin Tag setting page
	if ($class === 'tags') {
		$styles['tags']  = '.'. $class .' table{margin-left:auto;margin-right:auto;} ';
		$styles['tags'] .= 'table table{width:100%} ';
		$styles['tags'] .= 'table table td:nth-child(1){width:8em; font-weight:bold;} '; // Tag ID
		$styles['tags'] .= 'table table td:nth-child(2){width:6em;} '; // DropDown
		$styles['tags'] .= 'table table td:nth-child(3){width:3em;} '; // ID
		$styles['tags'] .= 'table table td:nth-child(4){width:11em;} '; // Text
		$styles['tags'] .= 'table table td:nth-child(5){width:16em;} '; // Enh Text
		$styles['tags'] .= 'table table td:nth-child(6){width:5em;} '; // Btn Change / Add
	}

	// Default style for the admin Rooms setting page
	if ($class === 'roomadmin') {
		$styles['roomadmin']  = '.'. $class .' table{margin-left:auto;margin-right:auto;} ';
		$styles['roomadmin'] .= 'table table{width:100%;} ';
		$styles['roomadmin'] .= 'table table td:nth-child(1){width:8em; font-weight:bold;} ';	// Romm ID
		$styles['roomadmin'] .= 'table table td:nth-child(2){width:12em;} ';					// Name
		$styles['roomadmin'] .= 'table table td:nth-child(3){width:12em;} ';					// Password
		$styles['roomadmin'] .= 'table table td:nth-child(4){width:10em;} ';					// Access ( who can access )
		$styles['roomadmin'] .= 'table table td:nth-child(5){width:10em;} ';					// Permanent
		$styles['roomadmin'] .= 'table table td:nth-child(6){width:5em;} ';						// Type (Visible / Hidden / Secret)
		$styles['roomadmin'] .= 'table table td:nth-child(7){width:8em;} ';						// Display ( all / messages / pm)
		$styles['roomadmin'] .= 'table table td:nth-child(8){width:5em;} ';						// Link ( enable / disable)
		$styles['roomadmin'] .= 'table table td:nth-child(9){width:6em;} ';						// Apply / Add
		$styles['roomadmin'] .= 'table table td:nth-child(10){width:5em;} ';					// Expire
	}

	// Default style for the User/Creator Rooms setting page
	if ($class === 'btnrooms') {
		$styles['btnrooms']  = '.'. $class .' table{margin-left:auto;margin-right:auto;} ';
		$styles['btnrooms'] .= 'table table{width:100%;} ';
		$styles['btnrooms'] .= 'table table td:nth-child(1){width:6em; font-weight:bold;} ';	// Romm ID
		$styles['btnrooms'] .= 'table table td:nth-child(2){width:12em;} ';						// Name
		$styles['btnrooms'] .= 'table table td:nth-child(3){width:12em;} ';						// Password
		$styles['btnrooms'] .= 'table table td:nth-child(4){width:10em;} ';						// Access ( Who can access )
		$styles['btnrooms'] .= 'table table td:nth-child(5){width:5em;} ';						// Type ( Visible / Hidden )
		$styles['btnrooms'] .= 'table table td:nth-child(6){width:8em;} ';						// Display ( Messages & Pm's / Messages only / Pm's only)
		$styles['btnrooms'] .= 'table table td:nth-child(7){width:5em;} ';						// Link ( enable / disable)
		$styles['btnrooms'] .= 'table table td:nth-child(8){width:6em;} ';						// Button zone (Switch / Add)
	}

	// Default style for the admin Last seen Member page
	if ($class === 'lastseen') {
		$styles['lastseen']  = '.'. $class .' table{margin-left:auto;margin-right:auto;} ';
		$styles['lastseen'] .= 'table table{width:100%;} ';
		$styles['lastseen'] .= 'table table td:nth-child(1){width:8em;font-weight:bold;} ';
		$styles['lastseen'] .= 'table table td:nth-child(2){text-align:left;width:14em;} ';
		$styles['lastseen'] .= 'table table td:nth-child(3){text-align:left;width:8em;} ';
		$styles['lastseen'] .= 'table table td:nth-child(4){text-align:left;width:8em;} ';
		$styles['lastseen'] .= 'table table td:nth-child(5){width:8em;} ';
		$styles['lastseen'] .= 'table table td:nth-child(6){text-align:left;width:8em;} ';
		$styles['lastseen'] .= 'table table td:nth-child(7){text-align:left;width:8em;} ';
		$styles['lastseen'] .= 'table table td:nth-child(8){text-align:right;width:8em;} ';
	}
	// Default style for the Gallery page
	if ($class === 'gallery') {
		$styles['gallery']  = '.'. $class .' table{margin-left:auto;margin-right:auto} ';
		$styles['gallery'] .= '#gallery_navigation_table td {vertical-align: bottom;} ';
		$styles['gallery'] .= '#gallery_navigation_table {margin-left:auto;margin-right:auto;} ';
		$styles['gallery'] .= '.imgdiv img {max-width: 100%;max-height: 500px;} ';
		$styles['gallery'] .= '.imgdiv a {text-decoration: none;} ';
		$styles['gallery'] .= '.imgdiv {display:none;} ';
		$styles['gallery'] .= '.imgdiv:target {display:block;} ';
		$styles['gallery'] .= '#live_gallery_table {border-collapse: collapse;margin-left:auto;margin-right:auto;table-layout: fixed;max-width: 90%;} ';
		$styles['gallery'] .= '#live_gallery_table img {max-height: 100px;max-width: 100%;} ';
		$styles['gallery'] .= '#live_gallery_table td {border: 2px solid grey;} ';
		$styles['gallery'] .= '#current_page_button {border:none;} ';
		$styles['gallery'] .= '#pagination_controls_table {margin-left:auto;margin-right:auto;max-width: 90%;} ';
		$styles['gallery'] .= '#pagination_controls_table tr {display:flex;flex-direction:row;flex-wrap:wrap;justify-content:center;} ';
		$styles['gallery'] .= '#pagination_controls_table td {vertical-align:middle;} ';
		$styles['gallery'] .= 'body.gallery h1 {margin: auto; text-align: center; color: #000000; width: 50%; background-color: #C0C0C0;} ';
	}
	 
	// Default style for the Emoji's page
	if ($class === 'emojis') {
		$styles['emojis']   = '.'. $class .' table{margin-left:auto;margin-right:auto} ';
		$styles['emojis']  .= 'body.emojis {background-color:#000000; color:#FFFFFF; overflow-x: hidden; background-repeat:no-repeat; height: 100%; background-position: top; background-size: cover; background-attachment: fixed;} ';
		$styles['emojis']  .= 'body.emojis h1 {margin: auto; text-align: center; color: #000000; width: 50%; background-color: #C0C0C0;} ';
		$styles['emojis']  .= 'body.emojis h3 {text-align: center; color:#808080;} ';
		$styles['emojis']  .= 'body.emojis table {border-spacing: 10px; margin-left:auto; margin-right:auto;} ';
		$styles['emojis']  .= 'body.emojis td {width: 20%; text-align: center; font-size: 14px; text-decoration-line: underline; border: 1px solid #404040;} ';
		$styles['emojis']  .= 'body.emojis img {height:35px;} ';
		$styles['emojis']  .= '.emoji {font-size: x-large; transition: 0.2s all;} ';
		$styles['emojis']  .= '.emoji:hover {font-size: x-large;} ';
	}

	if ($class === 'post') {
		$styles['post']  = '.spacer{width:10px} #firstline, #secondline, #thirdline {vertical-align:top}';
	}
	if ($class === 'messages') {
		$ManualRefresh		 = $U['refresh'] + 20;
		$styles['messages']  = '.msg { padding: 0.5em; padding-right: 5px; border-bottom: 1px dashed #404040; max-height: 350px; overflow-y: auto; } ';
		$styles['messages'] .= '.msg a { text-decoration: none; font-weight: bold; } ';
		$styles['messages'] .= '.msg a:hover { color: Gold; } ';
		$styles['messages'] .= '.msg small { font-size: 0.8em; color: #C0C0C0; } ';
		$styles['messages'] .= '.msg a small { text-decoration: none; font-weight: 200; } ';
		$styles['messages'] .= '.msg a small:hover { color: Gold; } ';
		$styles['messages'] .= '.nicklink { text-decoration: none } .channellink { text-decoration: underline } ';
		$styles['messages'] .= '#manualrefresh { display: block; position: fixed; text-align: center; left: 25%; width: 50%; top: -200%; animation: timeout_messages ';
		$styles['messages'] .= $ManualRefresh. 's forwards; z-index: 2; background-color: #500000; border: 2px solid #ff0000 } ';
		$styles['messages'] .= '@keyframes timeout_messages { 0% {top: -200% } 99% { top: -200% } 100% { top: 0% } } ';
		$styles['messages'] .= '@keyframes topic_banner {0%, 100% { background-position: 0 0; } 50% {background-position: 100% 0;} } ';
		$styles['messages'] .= '#bottom_link {position: fixed; top: 0.5em; right: 0.5em} #top_link { position: fixed; bottom: 0.5em; right: 0.5em } ';

		if (get_setting('allow_inline_commands')) {
			$styles['messages'] .= '.inline-tool { float: right !important; } ';
			$styles['messages'] .= '.inline-tool-button { border: 1px solid grey; color: white; font-weight: bold; padding-left: 3px; padding-right: 3px; opacity: 0.25; } ';
			$styles['messages'] .= '.inline-tool-button:hover { background-color: green; border: 1px solid gold; opacity: 1; } ';
		}

		if (get_setting('allow_msg_mention')) {
			$styles['messages'] .= '.refer-summary { width: 10px; height: 10px; } .refer-summary:hover + .refer-detail, .refer-detail:hover { display: inline-block; } .refer-detail { display: none; } .refer-msg div { font-size: 1rem; } ';
		}

		if (get_setting('show_chatter_on_top')) {
			$styles['messages'] .= '#chatters { max-height: 100px; overflow-y: auto } #chatters, #chatters table { border-spacing: 0px } ';
			$styles['messages'] .= '#chatters th, #chatters td { vertical-align: top } a img { width:15% } a:hover img { width:35% }';
			$styles['messages'] .= '#messages { word-wrap: break-word } ';
			$styles['messages'] .= '.msg { max-height: 180px; overflow-y: auto } ';
			$styles['messages'] .= '.messages #topic { display: block; text-align: center; font-family: arial; font-weight: bold; font-size: 16px; padding-top: 5px; padding-bottom: 5px; } ';
			$styles['messages'] .= '.messages #internal_topic { display: block; text-align: center; font-family: arial; font-size: 14px; color: orange; padding-bottom: 5px; } ';
			$styles['messages'] .= '.messages #staff_topic { display: block; text-align: center; font-family: arial; font-size: 14px; color: aqua; padding-bottom: 5px; } ';
		} else {
			$styles['messages'] .= '#messages { margin-top: 10px; margin-left: 5px; display: block; width: 74% } ';
			$styles['messages'] .= '.messages #chatters { display: block; float:right; width: 25%; overflow-y: auto; position: fixed; right: 0; max-height: 100%; bottom: 2em; top: 2em; } ';
			$styles['messages'] .= '.messages #chatters table {	width: 100%;	border-collapse: collapse; } ';
			$styles['messages'] .= '.messages #chatters table a { display: inline-block; } ';
			$styles['messages'] .= '.messages #chatters th { display: block; line-height: 0.9em; padding-bottom: 2px; } ';
			$styles['messages'] .= '.messages #chatters td, #chatters tr { display: table-row; line-height: 0.9em; padding-top: 2px; } ';
			$styles['messages'] .= '.messages #chatters span { display:inline-block; margin-right:0px; white-space: nowrap } ';
			$styles['messages'] .= '.messages #topic { display: block; width: 74%; text-align: center; font-family: arial; font-weight: bold; font-size: 16px; padding-top: 5px; padding-bottom: 5px; } ';
			$styles['messages'] .= '.messages #internal_topic { display: block; width: 74%; text-align: center; font-family: arial; font-size: 14px; color: orange; padding-bottom: 5px; } ';
			$styles['messages'] .= '.messages #staff_topic { display: block; width: 74%; text-align: center; font-family: arial; font-size: 14px; color: aqua; padding-bottom: 5px; } ';
			}
		$styles['messages'] .= '#chatters .channellink, #chatters .channellink a, #chatters .channellink a:hover { font-family: Arial; color: white; text-decoration: none; } ';
	}

	$css	= get_setting('css');
	$css	= preg_replace("/  /u", '', $css);
	
	$coltxt	= get_setting('coltxt');
	if (!empty($U['bgcolour'])) {
		$colbg	= $U['bgcolour'];
	} else {
		$colbg	= get_setting('colbg');
	}

	$styles['custom'] = preg_replace("/(\r?\n|\r\n?)/u", '', 'body,iframe { background-color:#'.$colbg.'; color:#'.$coltxt.' } '.$css );
	$allow_js 	 = (bool) get_setting('allow_js');
	$JsEnabled	 = get_setting('msg_java_on');
	$NoLoginIfJs = (bool) get_setting('no_login_with_js');

	if ($allow_js) {
		$scripts['default'] = 'if (window.history.replaceState) { window.history.replaceState(null,""); }';
		if($class === 'frameset') {
			$scripts['frameset'] = 'window.addEventListener("message", (e)=> {
				if (e.data === "post_box_loaded") {
					let autofocus = document.querySelector("iframe[name=post").contentDocument.querySelector("input[autofocus]");
					if (autofocus) {
						autofocus.focus();
					}
				}
			});';
		}
		if ($class === 'post') {
			$scripts['post'] = 'window.addEventListener("load", (e)=> {
				window.top.postMessage("post_box_loaded", window.location.origin);
			})';
		}
	} else {
		// Only script needed to determine is Js is or is not enabled
		$scripts['login'] = 'window.onload = function JavaTest () { 
			var div = document.getElementById("JsText"); 
			var box = document.getElementById("JsLogin");
			div.innerHTML += "'.$JsEnabled.'";';
		if ($NoLoginIfJs) {
			$scripts['login'] .= 'box.style.display = "none"; ';
		}
		$scripts['login'] .= '}';
	}
}

function send_headers (string $class='') : void
{
	global $U, $scripts, $styles;
	header('Content-Type: text/html; charset=UTF-8');
	header('Pragma: no-cache');
	header('Cache-Control: no-cache, no-store, must-revalidate, max-age=0, private');
	header('Expires: 0');
	header('Referrer-Policy: no-referrer');
	if ($class!='gallery') {
		header("Permissions-Policy: accelerometer=(), ambient-light-sensor=(), autoplay=(), battery=(), camera=(), cross-origin-isolated=(), display-capture=(), document-domain=(), encrypted-media=(), execution-while-not-rendered=(), execution-while-out-of-viewport=(), fullscreen=(), geolocation=(), gyroscope=(), magnetometer=(), microphone=(), midi=(), navigation-override=(), payment=(), picture-in-picture=(), publickey-credentials-get=(), screen-wake-lock=(), sync-xhr=(), usb=(), web-share=(), xr-spatial-tracking=(), clipboard-read=(), clipboard-write=(), gamepad=(), speaker-selection=(), conversion-measurement=(), focus-without-user-activation=(), hid=(), idle-detection=(), sync-script=(), vertical-scroll=(), serial=(), trust-token-redemption=(), interest-cohort=(), otp-credentials=()");
		if (!get_setting('imgembed') || !($U['embed'] ?? false)) {
			header("Cross-Origin-Embedder-Policy: require-corp");
		}
		header("Cross-Origin-Opener-Policy: same-origin");
		header("Cross-Origin-Resource-Policy: same-origin");
	}
	$style_hashes  = '';
	foreach ($styles as $style) {
		$style_hashes .= " 'sha256-".base64_encode(hash('sha256', $style, true))."'";
	}
	$script_hashes = '';
	foreach ($scripts as $script) {
		$script_hashes .= " 'sha256-".base64_encode(hash('sha256', $script, true))."'";
	}
	if ($class != 'login') {
		header("Content-Security-Policy: base-uri 'self'; default-src 'none'; font-src 'self'; form-action 'self'; frame-ancestors 'self'; frame-src 'self'; img-src * data:; media-src * data:; style-src 'self' 'unsafe-inline';" . (empty($script_hashes) ? '' : " script-src $script_hashes;")); 
	} else {
		header("Content-Security-Policy: base-uri 'self'; font-src 'self'; form-action 'self'; frame-ancestors 'self'; frame-src 'self'; img-src * data:; media-src * data:; style-src 'self' 'unsafe-inline';"); //. (empty($script_hashes) ? '' : " script-src $script_hashes;") ); 
	}
	header('X-Content-Type-Options: nosniff');
	header('X-Frame-Options: sameorigin');
	header('X-XSS-Protection: 1; mode=block');
	if ($_SERVER['REQUEST_METHOD'] === 'HEAD') {
		exit; // headers sent, no further processing needed
	}
}

function print_stylesheet (string $class) : string
{
	global $scripts, $styles;

	$sResult	 = '';
	// default css
	$sResult	 =  '<style>'.$styles['default'].'</style>';
	if ( $class !== 'init' ) {
		if (isset($styles[$class])) {
			$sResult	.= '<style>'.$styles[$class].'</style>';
		}
		
		// overwrite with custom css
		$sResult	.= '<style>'.$styles['custom'].'</style>';
		$allow_js = (bool) get_setting( 'allow_js' );
		if ( $allow_js ) {
			$sResult	.= '<script>'.$scripts['default'].'</script>';
			if (isset($scripts[$class])) {
				$sResult	.= '<script>'.$scripts[$class].'</script>';
			}
		}
	}

	return $sResult;
}

function send_frameset ($WithFilter='') : void
{
	global $U, $dbo, $language, $dir;

	prepare_stylesheets('frameset');
	send_headers();
	echo '<!DOCTYPE html><html lang="'.$language.'" dir="'.$dir.'"><head>';
	echo meta_html();
	echo '<title>'.get_setting('chatname').'</title>';
	echo print_stylesheet('frameset');
	echo '</head><body>';
	if (isset($_POST['sort'])) {
		if ($_POST['sort'] == 1) {
			$U['sortupdown']	= 1;
		} else {
			$U['sortupdown']	= 0;
		}
		$tmp				= $U['nocache'];
		$U['nocache']		= $U['nocache_old'];
		$U['nocache_old']	= $tmp;
		$stmt	= $dbo->prepare('UPDATE ' . PREFIX . 'sessions SET sortupdown=?, nocache=?, nocache_old=? WHERE nickname=?;');
		$stmt->execute([$U['sortupdown'], $U['nocache'], $U['nocache_old'], $U['nickname']]);
		if ($U['status'] > 1) {
			$stmt=$dbo->prepare('UPDATE ' . PREFIX . 'members SET sortupdown=?, nocache=?, nocache_old=? WHERE nickname=?;');
			$stmt->execute([$U['sortupdown'], $U['nocache'], $U['nocache_old'], $U['nickname']]);
		}
	}

	$lang			= '';
	$sess			= '';		
	$bottom			= '';
	$filter			= '';

	if (isset($U['session'])) {
		$sess			= '&session='.$U['session'];
	}

	if (get_setting('enablegreeting')) {
		$action_mid		= 'greeting';
	} else {
		if ($U['sortupdown']) {
			$bottom		= '#bottom';
		}
		$action_mid		= 'view';
	}

	if (!empty($WithFilter)) {
		$filter			= '&filter='.$WithFilter;
	}

	if (!empty($language)) {
		$lang			= '&lang='.$language;
	}

	$name_mid		= 'view';
	if ((!isset($_REQUEST['sort']) && !$U['sortupdown']) || (isset($_REQUEST['sort']) && $_REQUEST['sort'] == 0)) {
		$name_top = $action_top		= 'post';
		$name_bot = $action_bot		= 'controls';
		$sort_bot		= '&sort=1';
	}else{
		$name_top = $action_top		= 'controls';
		$name_bot = $action_bot		= 'post';
		$sort_bot		= '';
	}

	echo '<div id="frameset-mid"><iframe name="'.$name_mid.'" src="'.$_SERVER['SCRIPT_NAME'].'?action='. $action_mid . $sess . $filter . $lang . $bottom .'">'.noframe_html().'</iframe></div>';
	echo '<div id="frameset-top"><iframe name="'.$name_top.'" src="'.$_SERVER['SCRIPT_NAME'].'?action='. $action_top . $sess . $filter . $lang .'">'.noframe_html().'</iframe></div>';
	echo '<div id="frameset-bot"><iframe name="'.$name_bot.'" src="'.$_SERVER['SCRIPT_NAME'].'?action='. $action_bot . $sess . $filter . $lang . $sort_bot .'">'.noframe_html().'</iframe></div>';

	echo '</body></html>';
	exit;
}

function credit () : string 
{
	$title   = get_setting('chatname');
	$credit  = '<p id="credits"><small><br>';
	$credit .= '<a target="_blank" href="'.$_SERVER['SCRIPT_NAME'].'" rel="noreferrer noopener">'.$title.' v '. MAJOR .'-'.SUBREL.'-'. DBVERSION .'</a> based on ';
	$credit .= '<a target="_blank" href="https://github.com/DanWin/le-chat-php" rel="noreferrer noopener">LE CHAT-PHP - ' . VERSION . '</a>';
	$credit .= '</small></p>';
	return $credit;
}

function language_selector () : string
{
	$HtmlText		 = '';
	$ShowLanguages	 = false;

	if ($ShowLanguages == true) {
		$HtmlText	.= '<p id="changelang">'._('Change language:');
		foreach (LANGUAGES as $lang=>$data) {
			$HtmlText	.= ' <a href="'.$_SERVER['SCRIPT_NAME'].'?lang='.$lang.'">'.$data['name'].'</a>';
		}
		$HtmlText	.= '</p>';	
	}

	return $HtmlText;
}

function meta_html () : string 
{
	global $U, $dbo;
	$colbg = '000000';
	$description = '';
	if(!empty($U['bgcolour'])){
		$colbg = $U['bgcolour'];
	}else{
		if($dbo instanceof PDO){
			$colbg = get_setting('colbg');
			$description = '<meta name="description" content="'.htmlspecialchars(get_setting('metadescription')).'">';
		}
	}
	return '<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><meta name="referrer" content="no-referrer"><meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=yes"><meta name="theme-color" content="#'.$colbg.'"><meta name="msapplication-TileColor" content="#'.$colbg.'">' . $description;
}

function form (string $action, string $do='') : string 
{
	global $language, $chat_session;
	$form="<form action=\"$_SERVER[SCRIPT_NAME]\" enctype=\"multipart/form-data\" method=\"post\">".hidden('lang', $language).hidden('nc', substr(time(), -6)).hidden('action', $action);
	if(!empty($chat_session)){
		$form.=hidden('session', $chat_session);
	}
	if($do!==''){
		$form.=hidden('do', $do);
	}
	return $form;
}

function form_target (string $target, string $action, string $do='') : string 
{
	global $language, $chat_session;
	$form  = "<form action=\"$_SERVER[SCRIPT_NAME]\" enctype=\"multipart/form-data\" method=\"post\" target=\"$target\">";
	$form .= hidden('lang', $language);
	$form .= hidden('nc', substr(time(), -6));
	$form .= hidden('action', $action);
	if(!empty($chat_session)){
		$form .= hidden('session', $chat_session);
	}
	if($do!==''){
		$form .= hidden('do', $do);
	}
	return $form;
}

function hidden (string $name='', string $value='') : string 
{
	return "<input type=\"hidden\" name=\"$name\" value=\"$value\">";
}

function submit (string $value='', string $extra_attribute='') : string 
{
	return "<input type=\"submit\" value=\"$value\" $extra_attribute>";
}

function thr (): void
{
	echo '<tr><td><hr></td></tr>';
}

function v_print_start (string $class='', int $ref=0, string $url='') : string
{
	global $language, $dir;
	$sResult	 = '';
	
	prepare_stylesheets($class);
	//	send_headers($class);
	if (!empty($url)) {
		$url	= str_replace('&amp;', '&', $url);// Don't escape "&" in URLs here, it breaks some (older) browsers and js refresh!
		header("Refresh: $ref; URL=$url");
	}
	$sResult	 = '<!DOCTYPE html><html lang="'.$language.'" dir="'.$dir.'"><head>'.meta_html();
	if (!empty($url)) {
		$sResult	.= '<meta http-equiv="Refresh" content="'.$ref.'; URL='.$url.'">';
	}
	if ($class === 'init') {
		$sResult	.= '<title>'._('Initial Setup').'</title>';
	} else {
		$sResult	.= '<title>'.get_setting('chatname').'</title>';
	}
	$sResult	.= print_stylesheet($class);
	if ($class == 'login') {
		$sResult	.= '</head><body onload="javascript:JavaTest ()" class="'.$class.'">';
	} else {
		$sResult	.= '</head><body class="'.$class.'">';
	}
	if ($class !== 'init' && ($externalcss=get_setting('externalcss')) != '') {
		//external css - in body to make it non-renderblocking
		$sResult	.= '<link rel="stylesheet" type="text/css" href="'.$externalcss.'">';
	}
	return $sResult;
}

function print_start (string $class='', int $ref=0, string $url='') : void
{
	global $language, $dir;

	prepare_stylesheets($class);
	send_headers($class);
	if (!empty($url)) {
		$url	= str_replace('&amp;', '&', $url);// Don't escape "&" in URLs here, it breaks some (older) browsers and js refresh!
		header("Refresh: $ref; URL=$url");
	}
	echo '<!DOCTYPE html><html lang="'.$language.'" dir="'.$dir.'"><head>'.meta_html();
	if (!empty($url)) {
		echo "<meta http-equiv=\"Refresh\" content=\"$ref; URL=$url\">";
	}
	if ($class === 'init') {
		echo '<title>'._('Initial Setup').'</title>';
	} else {
		echo '<title>'.get_setting('chatname').'</title>';
	}
	echo print_stylesheet($class);
	if ($class == 'login') {
		echo '</head><body onload="javascript:JavaTest ()" class="'.$class.'">';
	} else {
		echo '</head><body class="'.$class.'">';
	}
	if ($class !== 'init' && ($externalcss=get_setting('externalcss')) != '') {
		//external css - in body to make it non-renderblocking
		echo '<link rel="stylesheet" type="text/css" href="'.$externalcss.'">';
	}
}

function v_print_end (string $class='') : string
{
	global $scripts;

	$sResult	 = '';
	$sResult	 =  '</body>';
	if ($class == 'login') {
		if (isset($scripts['login'])) {
			$sResult	.= '<script>'.$scripts['login'].'</script>';
		}
	}
	$sResult	.= '</html>';
	return $sResult;
}

function print_end (string $class='') : void
{
	global $scripts;

	echo '</body>';
	if ($class == 'login') {
		if (isset($scripts['login'])) {
			echo '<script>'.$scripts['login'].'</script>';
		}
	}
	echo '</html>';
	exit;
}

function noframe_html () : string 
{
	return _('This chat uses <b>frames</b>. Please enable frames in your browser or use a suitable one!').form_target('_parent', '').submit(_('Back to the login page.'), 'class="backbutton"').'</form>';
}

function send_colours (): void
{
	print_start('colours');

	echo '<h2>'._('Colourtable').'</h2><kbd><b>';
	for ($red = 0x00; $red <= 0xFF; $red += 0x33) {
		for ($green = 0x00; $green <= 0xFF; $green += 0x33) {
			for ($blue = 0x00; $blue <= 0xFF; $blue += 0x33) {
				$hcol = sprintf('%02X%02X%02X', $red, $green, $blue);
				echo '<span style="color:#'.$hcol.'">'.$hcol.'</span> ';
			}
			echo '<br>';
		}
		echo '<br>';
	}
	echo '</b></kbd>'.form('profile').submit(_('Back to your Profile'), ' class="backbutton"').'</form>';
	print_end();
}

function send_chat_disabled () : void
{
	print_start('disabled');
	echo get_setting('disabletext');
	print_end();
}

function send_error (string $err) : void
{
	print_start('error');
	echo '<h2>'.sprintf(_('Error: %s'),  $err).'</h2>'.form_target('_parent', '').submit(_('Back to the login page.'), 'class="backbutton"').'</form>';
	print_end();
}

function send_fatal_error (string $err) : void
{
	global $language, $styles, $dir;
	prepare_stylesheets('fatal_error');
	send_headers();
	echo '<!DOCTYPE html><html lang="'.$language.'" dir="'.$dir.'"><head>'. meta_html();
	echo '<title>'._('Fatal error').'</title>';
	echo '<style>'.$styles['fatal_error'].'</style>';
	echo '</head><body>';
	echo '<h2>'.sprintf(_('Fatal error: %s'),  $err).'</h2>';
	print_end();
}

function print_colours () : string
{
	// Prints a short list with selected named HTML colours and filters out illegible text colours for the given background.
	// It's a simple comparison of weighted grey values. This is not very accurate but gets the job done well enough.
	// name=>[colour, greyval(colour), translated name]
	$colours = [
		'Beige'			=> ['F5F5DC',  242.25, _('Beige')		 ],
		'Black'			=> ['000000', 		0, _('Black')		 ],
		'Blue'			=> ['0000FF', 	28.05, _('Blue')		 ],
		'BlueViolet'	=> ['8A2BE2', 	91.63, _('Blue violet')	 ],
		'Brown'			=> ['A52A2A', 	 78.9, _('Brown')		 ],
		'Cyan'			=> ['00FFFF', 	178.5, _('Cyan')		 ],
		'DarkBlue'		=> ['00008B', 	15.29, _('Dark blue')	 ],
		'DarkGreen'		=> ['006400', 	   59, _('Dark green')	 ],
		'DarkRed'		=> ['8B0000', 	 41.7, _('Dark red')	 ],
		'DarkViolet'	=> ['9400D3', 	67.61, _('Dark violet')	 ],
		'DeepSkyBlue'	=> ['00BFFF',  140.74, _('Sky blue')	 ],
		'Gold'			=> ['FFD700',  203.35, _('Gold')		 ],
		'Grey'			=> ['808080', 	  128, _('Grey')		 ],
		'Green'			=> ['008000', 	75.52, _('Green')		 ],
		'HotPink'		=> ['FF69B4',  158.25, _('Hot pink')	 ],
		'Indigo'		=> ['4B0082', 	 36.8, _('Indigo')		 ],
		'LightBlue'		=> ['ADD8E6',  204.64, _('Light blue')	 ],
		'LightGreen'	=> ['90EE90',  199.46, _('Light green')	 ],
		'LimeGreen'		=> ['32CD32',  141.45, _('Lime green')	 ],
		'Magenta'		=> ['FF00FF',  104.55, _('Magenta')		 ],
		'Olive'			=> ['808000',  113.92, _('Olive')		 ],
		'Orange'		=> ['FFA500',  173.85, _('Orange')		 ],
		'OrangeRed'		=> ['FF4500',  117.21, _('Orange red')	 ],
		'Purple'		=> ['800080', 	52.48, _('Purple')		 ],
		'Red'			=> ['FF0000', 	 76.5, _('Red')			 ],
		'RoyalBlue'		=> ['4169E1', 	106.2, _('Royal blue')	 ],
		'SeaGreen'		=> ['2E8B57',  105.38, _('Sea green')	 ],
		'Sienna'		=> ['A0522D',  101.33, _('Sienna')		 ],
		'Silver'		=> ['C0C0C0', 	  192, _('Silver')		 ],
		'Tan'			=> ['D2B48C', 	184.6, _('Tan')			 ],
		'Teal'			=> ['008080', 	 89.6, _('Teal')		 ],
		'Violet'		=> ['EE82EE',  174.28, _('Violet')		 ],
		'White'			=> ['FFFFFF', 	  255, _('White')		 ],
		'Yellow'		=> ['FFFF00',  226.95, _('Yellow')		 ],
		'YellowGreen'	=> ['9ACD32',  172.65, _('Yellow green') ],
	];

	$sResult	 = '';
	$greybg		 =	greyval (get_setting('colbg'));
	foreach ($colours as $name => $colour) {
		if (abs ($greybg - $colour[1]) > 75) {
			$sResult 	.= '<option value="'.$colour[0].'" style="color:#'.$colour[0].';">'.$colour[2].'</option>';
		}
	}

	return $sResult;
}

function greyval (string $colour) : string 
{
	return hexdec(substr($colour, 0, 2)) * 0.3 + hexdec(substr($colour, 2, 2)) * 0.59 + hexdec(substr($colour, 4, 2)) * 0.11;
}

function load_fonts () : array 
{
	return [
		'Arial'				=> "font-family:Arial,Helvetica,sans-serif;",
		'Book Antiqua'		=> "font-family:'Book Antiqua','MS Gothic',serif;",
		'Comic'				=> "font-family:'Comic Sans MS',Papyrus,sans-serif;",
		'Courier'			=> "font-family:'Courier New',Courier,monospace;",
		'Cursive'			=> "font-family:Cursive,Papyrus,sans-serif;",
		'Fantasy'			=> "font-family:Fantasy,Futura,Papyrus,sans;",
		'Garamond'			=> "font-family:Garamond,Palatino,serif;",
		'Georgia'			=> "font-family:Georgia,'Times New Roman',Times,serif;",
		'Serif'				=> "font-family:'MS Serif','New York',serif;",
		'System'			=> "font-family:System,Chicago,sans-serif;",
		'Times New Roman'	=> "font-family:'Times New Roman',Times,serif;",
		'Verdana'			=> "font-family:Verdana,Geneva,Arial,Helvetica,sans-serif;",
	];
}

function load_lang () : void
{
	global $language, $locale, $dir;

	if (isset($_REQUEST['lang']) && isset(LANGUAGES[$_REQUEST['lang']])) {
		$locale 	= LANGUAGES[$_REQUEST['lang']]['locale'];
		$language 	= $_REQUEST['lang'];
		$dir 		= LANGUAGES[$_REQUEST['lang']]['dir'];
		set_secure_cookie('language', $language);
	} elseif (isset($_COOKIE['language']) && isset(LANGUAGES[$_COOKIE['language']])) {
		$locale 	= LANGUAGES[$_COOKIE['language']]['locale'];
		$language 	= $_COOKIE['language'];
		$dir 		= LANGUAGES[$_COOKIE['language']]['dir'];
	} elseif (!empty($_SERVER['HTTP_ACCEPT_LANGUAGE'])) {
		$prefLocales = array_reduce(
			explode(',', $_SERVER['HTTP_ACCEPT_LANGUAGE']),
			function (array $res, string $el) {
				list($l, $q) 	= array_merge(explode(';q=', $el), [1]);
				$res[$l] 		= (float) $q;
				return $res;
			}, []);
		arsort($prefLocales);
		foreach ($prefLocales as $l => $q) {
			$lang 	= locale_lookup(array_keys(LANGUAGES), $l);
			if (!empty($lang)) {
				$locale 	= LANGUAGES[$lang]['locale'];
				$language 	= $lang;
				$dir 		= LANGUAGES[$lang]['dir'];
				set_secure_cookie('language', $language);
				break;
			}
		}
	}
}

function is_definitely_ssl () : bool 
{
	if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
		return true;
	}
	if (isset($_SERVER['SERVER_PORT']) && ('443' == $_SERVER['SERVER_PORT'])) {
		return true;
	}
	if (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && ('https' === $_SERVER['HTTP_X_FORWARDED_PROTO'])) {
		return true;
	}
	return false;
}

function set_secure_cookie(string $name, string $value) : void
{
	if (version_compare(PHP_VERSION, '7.3.0') >= 0) {
		setcookie($name, $value, ['expires' => 0, 'path' => '/', 'domain' => '', 'secure' => is_definitely_ssl(), 'httponly' => true, 'samesite' => 'Strict']);
	}else{
		setcookie($name, $value, 0, '/', '', is_definitely_ssl(), true);
	}
}



?>