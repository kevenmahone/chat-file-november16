<?php

function apply_filter (string $message, int $poststatus, string $nickname) : string 
{
	global $U, $chat_session;

	$message	= str_replace('<br>', "\n", $message);
	$message	= apply_mention($message);
	$filters	= get_filters();
	foreach ($filters as $filter) {
		if ($poststatus !== 9 || $filter['allowinpm']) {
			if ($filter['cs']) {
				$message	= preg_replace("/$filter[match]/u", $filter['replace'], $message, -1, $count);
			} else {
				$message	= preg_replace("/$filter[match]/iu", $filter['replace'], $message, -1, $count);
			}
		}
		if (isset($count) && $count > 0 && $filter['kick'] && ($U['status'] < 5 || get_setting('filtermodkick'))) {
			kick_chatter([$nickname], $filter['replace'], false);
			setcookie(COOKIENAME, false);
			$chat_session = '';
			send_error(_('You have been kicked!')."<br>$filter[replace]");
		}
	}

	$message	= str_replace("\n", '<br>', $message);
	return $message;
}

function apply_linkfilter (string $message) : string 
{
	$LinkUrl	= [];
	$filters	= get_linkfilters();
	foreach ($filters as $filter) {
		$message = preg_replace_callback('/<a href="([^"]+)" target="_blank" rel="noreferrer noopener">([^<]*)<\/a>/iu',
			function ($matched) use (&$filter, &$LinkUrl) {
			
				$Des_F = preg_replace('/'.$filter['match'].'/iu', $filter['replace'], $matched[2], -1, $count);
				if ( $count ) {
					if ($matched[1] != $matched[2]) {
						$LinkUrl[] 	 = $matched[1];
					}
				}
				return '<a href="'.$matched[1].'" target="_blank" rel="noreferrer noopener">'.$Des_F.'</a>';
			}
		, $message);
	}
	$redirect = get_setting('redirect');

	if (get_setting('imgembed')) {
		$message = preg_replace_callback('/\[img]\s?<a href="([^"]+)" target="_blank" rel="noreferrer noopener">([^<]*)<\/a>/iu',
			function ($matched) {
				return str_ireplace('[/img]', '', "<br><a href=\"$matched[1]\" target=\"_blank\" rel=\"noreferrer noopener\"><img src=\"$matched[1]\" rel=\"noreferrer\" loading=\"lazy\"></a><br>");
			}
		, $message);
	}
	if (empty($redirect)) {
		$redirect = "$_SERVER[SCRIPT_NAME]?action=redirect&amp;url=";
	}
	if (get_setting('forceredirect')) {
		$message = preg_replace_callback('/<a href="([^"]+)" target="_blank" rel="noreferrer noopener">([^<]*)<\/a>/u',
			function ($matched) use ($redirect) {
				return "<a href=\"$redirect".rawurlencode($matched[1])."\" target=\"_blank\" rel=\"noreferrer noopener\">$matched[2]</a>";
			}
		, $message);
	} elseif (preg_match_all('/<a href="([^"]+)" target="_blank" rel="noreferrer noopener">([^<]*)<\/a>/u', $message, $matches)) {
		foreach ($matches[1] as $match) {
			if (!preg_match('~^http(s)?://~u', $match)) {
				$message = preg_replace_callback('/<a href="('.preg_quote($match, '/').')\" target=\"_blank\" rel=\"noreferrer noopener\">([^<]*)<\/a>/u',
					function ($matched) use ($redirect) {
						return "<a href=\"$redirect".rawurlencode($matched[1])."\" target=\"_blank\" rel=\"noreferrer noopener\">$matched[2]</a>";
					}
				, $message);
			}
		}
	}

	return $message;
}

function valid_regex (string &$regex) : bool 
{
	$regex = preg_replace('~(^|[^\\\\])/~', "$1\/u", $regex); // Escape "/" if not yet escaped
	return (@preg_match("/$_POST[match]/u", '') !== false);
}

function check_filter_match (int &$reg) : string 
{
	$_POST['match']=htmlspecialchars($_POST['match']);
	if(isset($_POST['regex']) && $_POST['regex']==1){
		if(!valid_regex($_POST['match'])){
			return _('Incorrect regular expression!').'<br>'.sprintf(_('Your match was as follows: %s'), htmlspecialchars($_POST['match']));
		}
		$reg=1;
	}else{
		$_POST['match']=preg_replace('/([^\w\d])/u', "\\\\$1", $_POST['match']);
		$reg=0;
	}
	if(mb_strlen($_POST['match'])>255){
		return _('Your match was too long. You can use max. 255 characters. Try splitting it up.')."<br>".sprintf(_('Your match was as follows: %s'), htmlspecialchars($_POST['match']));
	}
	return '';
}

function manage_filter () : string 
{
	global $dbo, $memcached;
	if (isset($_POST['id'])) {
		$reg  = 0;
		if (($tmp  = check_filter_match($reg)) !== '') {
			return $tmp;
		}
		if (isset($_POST['allowinpm']) && $_POST['allowinpm']==1) {
			$pm   = 1;
		} else {
			$pm   = 0;
		}
		if (isset($_POST['kick']) && $_POST['kick']==1) {
			$kick = 1;
		} else {
			$kick = 0;
		}
		if (isset($_POST['cs']) && $_POST['cs']==1) {
			$cs   = 1;
		} else {
			$cs   = 0;
		}
		if (preg_match('/^[0-9]+$/', $_POST['id'])) {
			if (empty($_POST['match'])) {
				$stmt = $dbo->prepare('DELETE FROM ' . PREFIX . 'filter WHERE id=?;');
				$stmt->execute([$_POST['id']]);
			} else {
				$stmt = $dbo->prepare('UPDATE ' . PREFIX . 'filter SET filtermatch=?, filterreplace=?, filtercom=?, allowinpm=?, regex=?, kick=?, cs=? WHERE id=?;');
				$stmt->execute([$_POST['match'], $_POST['replace'], $_POST['comment'], $pm, $reg, $kick, $cs, $_POST['id']]);
			}
		} elseif ($_POST['id']==='+') {
			$stmt = $dbo->prepare('INSERT INTO ' . PREFIX . 'filter (filtermatch, filterreplace, filtercom, allowinpm, regex, kick, cs) VALUES (?, ?, ?, ?, ?, ?, ?);');
			$stmt->execute([$_POST['match'], $_POST['replace'], $_POST['comment'], $pm, $reg, $kick, $cs]);
		}
		if (MEMCACHED) {
			$memcached->delete(DBNAME . '-' . PREFIX . 'filter');
		}
	}
	return '';
}

function manage_linkfilter () : string 
{
	global $dbo, $memcached;
	if(isset($_POST['id'])){
		$reg=0;
		if(($tmp=check_filter_match($reg)) !== ''){
			return $tmp;
		}
		if(preg_match('/^[0-9]+$/', $_POST['id'])){
			if(empty($_POST['match'])){
				$stmt=$dbo->prepare('DELETE FROM ' . PREFIX . 'linkfilter WHERE id=?;');
				$stmt->execute([$_POST['id']]);
			}else{
				$stmt=$dbo->prepare('UPDATE ' . PREFIX . 'linkfilter SET filtermatch=?, filterreplace=?, filtercom=?, regex=? WHERE id=?;');
				$stmt->execute([$_POST['match'], $_POST['replace'], $_POST['comment'], $reg, $_POST['id']]);
			}
		}elseif($_POST['id']==='+'){
			$stmt=$dbo->prepare('INSERT INTO ' . PREFIX . 'linkfilter (filtermatch, filterreplace, filtercom, regex) VALUES (?, ?, ?, ?);');
			$stmt->execute([$_POST['match'], $_POST['replace'], $_POST['comment'], $reg]);
		}
		if(MEMCACHED){
			$memcached->delete(DBNAME . '-' . PREFIX . 'linkfilter');
		}
	}
	return '';
}

function get_filters () : array 
{
	global $dbo, $memcached;
	$filters=[];
	if(MEMCACHED){
		$filters=$memcached->get(DBNAME . '-' . PREFIX . 'filter');
	}
	if(!MEMCACHED || $memcached->getResultCode()!==Memcached::RES_SUCCESS){
		$filters=[];
		$result=$dbo->query('SELECT id, filtermatch, filterreplace, filtercom, allowinpm, regex, kick, cs FROM ' . PREFIX . 'filter;');
		while($filter=$result->fetch(PDO::FETCH_ASSOC)){
			$filters[]=['id'=>$filter['id'], 'match'=>$filter['filtermatch'], 'replace'=>$filter['filterreplace'], 'comment'=>$filter['filtercom'], 'allowinpm'=>$filter['allowinpm'], 'regex'=>$filter['regex'], 'kick'=>$filter['kick'], 'cs'=>$filter['cs']];
		}
		if(MEMCACHED){
			$memcached->set(DBNAME . '-' . PREFIX . 'filter', $filters);
		}
	}
	return $filters;
}

function get_linkfilters () : array 
{
	global $dbo, $memcached;
	$filters=[];
	if(MEMCACHED){
		$filters=$memcached->get(DBNAME . '-' . PREFIX . 'linkfilter');
	}
	if(!MEMCACHED || $memcached->getResultCode()!==Memcached::RES_SUCCESS){
		$filters=[];
		$result=$dbo->query('SELECT id, filtermatch, filterreplace, filtercom, regex FROM ' . PREFIX . 'linkfilter;');
		while($filter=$result->fetch(PDO::FETCH_ASSOC)){
			$filters[]=['id'=>$filter['id'], 'match'=>$filter['filtermatch'], 'replace'=>$filter['filterreplace'], 'comment'=>$filter['filtercom'], 'regex'=>$filter['regex']];
		}
		if(MEMCACHED){
			$memcached->set(DBNAME . '-' . PREFIX . 'linkfilter', $filters);
		}
	}
	return $filters;
}

function send_filter (string $arg=''): void
{
	global $U;
	
	print_start('filter');
	echo '<h2>'._('Filter')."</h2><i>$arg</i><table>";
	thr();
	echo '<tr><th><table><tr>';
	echo '<td>'._('Filter ID:').'</td>';
	echo '<td>'._('Match').'</td>';
	echo '<td>'._('Replace').'</td>';
	echo '<td>'._('Comment').'</td>';
	echo '<td>'._('Allow in PM').'</td>';
	echo '<td>'._('Regex').'</td>';
	echo '<td>'._('Kick').'</td>';
	echo '<td>'._('Case sensitive').'</td>';
	echo '<td>'._('Apply').'</td>';
	echo '</tr></table></th></tr>';
	$filters=get_filters();
	foreach($filters as $filter){
		if($filter['allowinpm']==1){
			$check=' checked';
		}else{
			$check='';
		}
		if($filter['regex']==1){
			$checked=' checked';
		}else{
			$checked='';
			$filter['match']=preg_replace('/(\\\\(.))/u', "$2", $filter['match']);
		}
		if($filter['kick']==1){
			$checkedk=' checked';
		}else{
			$checkedk='';
		}
		if($filter['cs']==1){
			$checkedcs=' checked';
		}else{
			$checkedcs='';
		}
		if (!empty($filter['comment'])) {
			$comment = htmlspecialchars($filter['comment']);
		} else {
			$comment = '';
		}
		echo '<tr><td>';
		echo form('admin', 'filter').hidden('id', $filter['id']);
		echo '<table><tr><td>'._('Filter')." $filter[id]:</td>";
		echo '<td><input type="text" name="match" value="'.$filter['match'].'" size="18" style="'.$U['style'].'"></td>';
		echo '<td><input type="text" name="replace" value="'.htmlspecialchars($filter['replace']).'" size="18" style="'.$U['style'].'"></td>';
		echo '<td><input type="text" name="comment" value="'.$comment.'" size="14" style="'.$U['style'].'"></td>';
		echo '<td><label><input type="checkbox" name="allowinpm" value="1"'.$check.'>'._('Allow in PM').'</label></td>';
		echo '<td><label><input type="checkbox" name="regex" value="1"'.$checked.'>'._('Regex').'</label></td>';
		echo '<td><label><input type="checkbox" name="kick" value="1"'.$checkedk.'>'._('Kick').'</label></td>';
		echo '<td><label><input type="checkbox" name="cs" value="1"'.$checkedcs.'>'._('Case sensitive').'</label></td>';
		echo '<td class="filtersubmit">'.submit(_('Change')).'</td></tr></table></form></td></tr>';
	}
	echo '<tr><td>';
	echo form('admin', 'filter').hidden('id', '+');
	echo '<table><tr><td>'._('New filter:').'</td>';
	echo '<td><input type="text" name="match" value="" size="18" style="'.$U['style'].'"></td>';
	echo '<td><input type="text" name="replace" value="" size="18" style="'.$U['style'].'"></td>';
	echo '<td><input type="text" name="comment" value="" size="14" style="'.$U['style'].'"></td>';
	echo '<td><label><input type="checkbox" name="allowinpm" id="allowinpm" value="1">'._('Allow in PM').'</label></td>';
	echo '<td><label><input type="checkbox" name="regex" id="regex" value="1">'._('Regex').'</label></td>';
	echo '<td><label><input type="checkbox" name="kick" id="kick" value="1">'._('Kick').'</label></td>';
	echo '<td><label><input type="checkbox" name="cs" id="cs" value="1">'._('Case sensitive').'</label></td>';
	echo '<td class="filtersubmit">'.submit(_('Add')).'</td></tr></table></form></td></tr>';
	echo '</table><br>';
	echo form('admin', 'filter').submit(_('Reload')).'</form>';
	print_end();
}

function send_linkfilter (string $arg=''): void
{
	global $U;
	print_start('linkfilter');
	echo '<h2>'._('Linkfilter')."</h2><i>$arg</i><table>";
	thr();
	echo '<tr><th><table><tr>';
	echo '<td>'._('Filter ID:').'</td>';
	echo '<td>'._('Match').'</td>';
	echo '<td>'._('Replace').'</td>';
	echo '<td>'._('Comment').'</td>';
	echo '<td>'._('Regex').'</td>';
	echo '<td>'._('Apply').'</td>';
	echo '</tr></table></th></tr>';
	$filters=get_linkfilters();
	foreach($filters as $filter){
		if($filter['regex']==1){
			$checked=' checked';
		}else{
			$checked='';
			$filter['match']=preg_replace('/(\\\\(.))/u', "$2", $filter['match']);
		}
		if (!empty($filter['comment'])) {
			$comment = htmlspecialchars($filter['comment']);
		} else {
			$comment = '';
		}
		echo '<tr><td>';
		echo form('admin', 'linkfilter').hidden('id', $filter['id']);
		echo '<table><tr><td>'._('Filter')." $filter[id]:</td>";
		echo '<td><input type="text" name="match" value="'.$filter['match'].'" size="18" style="'.$U['style'].'"></td>';
		echo '<td><input type="text" name="replace" value="'.htmlspecialchars($filter['replace']).'" size="18" style="'.$U['style'].'"></td>';
		echo '<td><input type="text" name="comment" value="'.$comment.'" size="14" style="'.$U['style'].'"></td>';
		echo '<td><label><input type="checkbox" name="regex" value="1"'.$checked.'>'._('Regex').'</label></td>';
		echo '<td class="filtersubmit">'.submit(_('Change')).'</td></tr></table></form></td></tr>';
	}
	echo '<tr><td>';
	echo form('admin', 'linkfilter').hidden('id', '+');
	echo '<table><tr><td>'._('New filter:').'</td>';
	echo '<td><input type="text" name="match" value="" size="18" style="'.$U['style'].'"></td>';
	echo '<td><input type="text" name="replace" value="" size="18" style="'.$U['style'].'"></td>';
	echo '<td><input type="text" name="comment" value="" size="14" style="'.$U['style'].'"></td>';
	echo '<td><label><input type="checkbox" name="regex" value="1">'._('Regex').'</label></td>';
	echo '<td class="filtersubmit">'.submit(_('Add')).'</td></tr></table></form></td></tr>';
	echo '</table><br>';
	echo form('admin', 'linkfilter').submit(_('Reload')).'</form>';
	print_end();
}


?>