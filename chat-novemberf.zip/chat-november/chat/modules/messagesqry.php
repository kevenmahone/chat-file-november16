<?php

// Full Message list with messages & PMs
function DoMessageListQry_0 ($status, $nickname, $entry, $direction)
{
    global $dbo;

    $stmt = $dbo->prepare('SELECT id, postdate, text, poststatus, delstatus, poster, recipient, roomid, allrooms FROM ' . PREFIX . 'messages WHERE '.
    '(poststatus <= ? OR poststatus = 4 '.
    'OR (poststatus = 9 AND ((poster = ? AND recipient NOT IN (SELECT ign FROM ' . PREFIX . 'ignored WHERE ignby = ?)) OR recipient = ?) AND postdate >= ?)) '.
    'AND poster NOT IN (SELECT ign FROM ' . PREFIX . 'ignored WHERE ignby = ?) '.
    'ORDER BY id '.$direction.';');
    $stmt->execute([$status, $nickname, $nickname, $nickname, $entry, $nickname]);

    return $stmt;
}

// Message list with only the messages
function DoMessageListQry_1 ($status, $nickname, $entry, $direction)
{
    global $dbo;

    $stmt = $dbo->prepare('SELECT id, postdate, text, poststatus, delstatus, poster, recipient, roomid, allrooms FROM ' . PREFIX . 'messages WHERE '.
    '(poststatus <= ? '.
    'OR (poststatus <= ? AND ((poster = ? AND recipient NOT IN (SELECT ign FROM ' . PREFIX . 'ignored WHERE ignby = ?)) OR recipient = ?) AND postdate >= ?)) '.
    'AND poster NOT IN (SELECT ign FROM ' . PREFIX . 'ignored WHERE ignby = ?) '.
    'ORDER BY id '.$direction.';');
    $stmt->execute([$status, $status, $nickname, $nickname, $nickname, $entry, $nickname]);

    return $stmt;
}

// Message list with only the PMs
function DoMessageListQry_2 ($status, $nickname, $entry, $direction)
{
    global $dbo;

    $stmt = $dbo->prepare('SELECT id, postdate, text, poststatus, delstatus, poster, recipient, roomid, allrooms FROM ' . PREFIX . 'messages WHERE '.
    '(poststatus = 9 '.
    'AND ((poster = ? AND recipient NOT IN (SELECT ign FROM ' . PREFIX . 'ignored WHERE ignby = ?)) OR recipient = ?) AND postdate >= ?)'.
    'AND poster NOT IN (SELECT ign FROM ' . PREFIX . 'ignored WHERE ignby = ?) '.
    'ORDER BY id '.$direction.';');
    $stmt->execute([$nickname, $nickname, $nickname, $entry, $nickname]);

    return $stmt;
}

?>