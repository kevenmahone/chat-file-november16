<?php

function send_login() : void
{
	$sResult		 = '';
	$GuestAccess	 = (int) get_setting('guestaccess');
	$javascript 	 = false;
	if ($GuestAccess === 4) {
		send_chat_disabled();
	}
	$sResult		 = v_print_start('login');

	$englobal		 = (int) get_setting('englobalpass');
	$JsDisabled		 = get_setting('msg_java_off');
	$sResult		.= '<h1 id="chat_name">'.get_setting('chatname').'</h1>';

	$sResult		.= '<center>';
	$sResult		.= '<noscript><div id="rules"><span style="color:white">'.$JsDisabled.'</span></div></noscript>';
	$sResult		.= '<div id="JsText" style="color:red"></div>';
	$sResult		.= '<br>';
	$sResult		.= '</center>';

	if ($javascript == false) {

		$sResult		.= '<div id="JsLogin">'. form_target('_parent', 'login');
		if ($englobal === 1 && isset($_POST['globalpass'])) {
			$sResult		.= hidden('globalpass', htmlspecialchars($_POST['globalpass']));
		}
		$sResult		.= '<table>';
		if ($englobal !== 1 || (isset($_POST['globalpass']) && $_POST['globalpass'] == get_setting('globalpass'))) {
			$sResult		.= '<tr><td>'._('Nickname:').'</td><td><input type="text" name="nick" size="15" autocomplete="username" autofocus></td></tr>';
			$sResult		.= '<tr><td>'._('Password:').'</td><td><input type="password" name="pass" size="15" autocomplete="current-password"></td></tr>';
			$sResult		.= send_captcha();
			if ($GuestAccess !== 0) {
				if (get_setting('guestreg') != 0) {
					$sResult		.= '<tr><td>'._('Repeat password<br>to register').'</td><td><input type="password" name="regpass" size="15" placeholder="'._('(optional)').'" autocomplete="new-password"></td></tr>';
				}
				if ($englobal === 2) {
					$sResult		.= '<tr><td>'._('Global Password:').'</td><td><input type="password" name="globalpass" size="15"></td></tr>';
				}
				$sResult		.= '<tr><td colspan="2">'._('Guests, choose a colour:').'<br><select name="colour"><option value="">* '._('Random Colour').' *</option>';
				$sResult		.= print_colours ();
				$sResult		.= '</select></td></tr>';
			} else {
				$sResult		.= '<tr><td colspan="2">'._('Sorry, currently members only!').'</td></tr>';
			}
			$sResult		.= '<tr><td colspan="2">'.submit(_('Enter Chat')).'</td></tr></table></form><br>';
			$sResult		.= print_nowchatting();
			$sResult		.= '<br><div id="topic">';
			$sResult		.= get_setting('topic');
			$sResult		.= '</div>';
			$rulestxt		 = preg_replace("/(\r?\n|\r\n?)/u", '', get_setting('rulestxt'));
			if (!empty($rulestxt)) {
				$sResult		.= '<div id="rules"><h2>'._('Rules').'</h2><b>'.$rulestxt.'</b></div>';
			}
		} else {
			$sResult		.= '<tr><td>'._('Global Password:').'</td><td><input type="password" name="globalpass" size="15" autofocus></td></tr>';
			if ($GuestAccess === 0) {
				$sResult		.= '<tr><td colspan="2">'._('Sorry, currently members only!').'</td></tr>';
			}
			$sResult		.= '<tr><td colspan="2">'.submit(_('Enter Chat')).'</td></tr></table></form>';
		}
		$sResult		.= '</div>';			// Close '<div id="JsLogin">'
		$sResult		.= '<br>';
		$sResult		.= language_selector();
		$sResult		.= credit();
	}
	$sResult		.= v_print_end('login');

	// Display the complete page at once
	send_headers('login');
	
	echo $sResult;
}

function send_logout () : void
{
	global $U;
	print_start('logout');
	echo '<h1>'.sprintf(_('Bye %s, visit again soon!'), style_this(htmlspecialchars($U['nickname']), $U['style'])).'</h1>'.form_target('_parent', '').submit(_('Back to the login page.'), 'class="backbutton"').'</form>';
	print_end();
}

function send_captcha () : string
{
	global $dbo, $memcached;

	$sResult		 = '';

	$difficulty		 = (int) get_setting('captcha');
	if ($difficulty === 0 || !extension_loaded('gd')) {
		$sResult		 = '';
	} else {
		$captchachars	 = get_setting('captchachars');
		$length			 = strlen($captchachars) -1;
		$code			 = '';
		for ($i = 0; $i < 5; ++$i) {
			$code		.= $captchachars[mt_rand(0, $length)];
		}
		$randid			 = mt_rand();
		$time			 = time();
		if (MEMCACHED) {
			$memcached->set(DBNAME . '-' . PREFIX . 'captcha-'.$randid.', '.$code.', '.get_setting('captchatime'));
		} else {
			$stmt = $dbo->prepare('INSERT INTO ' . PREFIX . 'captcha (id, time, code) VALUES (?, ?, ?);');
			$stmt->execute([$randid, $time, $code]);
		}
		$sResult		 = '<tr id="captcha"><td>'._('Copy:').'<br>';
		if ($difficulty === 1) {
			$im			 = imagecreatetruecolor(55, 24);
			$bg			 = imagecolorallocate($im, 0, 0, 0);
			$fg			 = imagecolorallocate($im, 255, 255, 255);
			imagefill($im, 0, 0, $bg);
			imagestring($im, 5, 5, 5, $code, $fg);
			$sResult	.= '<img alt="" width="55" height="24" src="data:image/gif;base64,';
		} elseif ($difficulty === 2) {
			$im			 = imagecreatetruecolor(55, 24);
			$bg			 = imagecolorallocate($im, 0, 0, 0);
			$fg			 = imagecolorallocate($im, 255, 255, 255);
			imagefill($im, 0, 0, $bg);
			imagestring($im, 5, 5, 5, $code, $fg);
			$line		 = imagecolorallocate($im, 255, 255, 255);
			for ($i = 0; $i < 2; ++$i) {
				imageline($im, 0, mt_rand(0, 24), 55, mt_rand(0, 24), $line);
			}
			$dots		 = imagecolorallocate($im, 255, 255, 255);
			for ($i = 0; $i < 100; ++$i) {
				imagesetpixel($im, mt_rand(0, 55), mt_rand(0, 24), $dots);
			}
			$sResult	.= '<img alt="" width="55" height="24" src="data:image/gif;base64,';
		}else{
			$im			 = imagecreatetruecolor(150, 200);
			$bg			 = imagecolorallocate($im, 0, 0, 0);
			$fg			 = imagecolorallocate($im, 255, 255, 255);
			imagefill($im, 0, 0, $bg);
			$chars		 = [];
			$x = $y = 0;
			for ($i = 0; $i < 10; ++$i) {
				$found		 = false;
				while(!$found) {
					$x			 = mt_rand(10, 140);
					$y			 = mt_rand(10, 180);
					$found		 = true;
					foreach ($chars as $char) {
						if ($char['x'] >= $x && ($char['x'] - $x) < 25) {
							$found	= false;
						} elseif ($char['x'] < $x && ($x - $char['x']) < 25) {
							$found	= false;
						}
						if (!$found) {
							if ($char['y'] >= $y && ($char['y'] - $y) < 25) {
								break;
							} elseif ($char['y'] < $y && ($y - $char['y']) < 25) {
								break;
							} else {
								$found	= true;
							}
						}
					}
				}
				$chars[]		= ['x', 'y'];
				$chars[$i]['x']	= $x;
				$chars[$i]['y']	= $y;
				if ($i < 5) {
					imagechar($im, 5, $chars[$i]['x'], $chars[$i]['y'], $captchachars[mt_rand(0, $length)], $fg);
				} else {
					imagechar($im, 5, $chars[$i]['x'], $chars[$i]['y'], $code[$i-5], $fg);
				}
			}
			$follow		 = imagecolorallocate($im, 200, 0, 0);
			imagearc($im, $chars[5]['x'] + 4, $chars[5]['y'] + 8, 16, 16, 0, 360, $follow);
			for ($i=5;$i<9;++$i) {
				imageline($im, $chars[$i]['x']+4, $chars[$i]['y']+8, $chars[$i+1]['x']+4, $chars[$i+1]['y']+8, $follow);
			}
			$line		 = imagecolorallocate($im, 255, 255, 255);
			for ($i = 0; $i < 5; ++$i) {
				imageline($im, 0, mt_rand(0, 200), 150, mt_rand(0, 200), $line);
			}
			$dots		 = imagecolorallocate($im, 255, 255, 255);
			for ($i = 0; $i < 1000; ++$i) {
				imagesetpixel($im, mt_rand(0, 150), mt_rand(0, 200), $dots);
			}
			$sResult	.= '<img alt="" width="150" height="200" src="data:image/gif;base64,';
		}
		ob_start();
		imagegif($im);
		imagedestroy($im);
		$sResult	.= base64_encode(ob_get_clean()).'">';
		$sResult	.= '</td><td>'.hidden('challenge', $randid).'<input type="text" name="captcha" size="15" autocomplete="off"></td></tr>';
	}

	return $sResult;
}

function check_login () : void
{
	global $U;

	$GuestAccess	= (int) get_setting('guestaccess');
	parse_sessions();
	if (isset($U['session'])) {
		check_kicked();
	} elseif (get_setting('englobalpass') == 1 && (!isset($_POST['globalpass']) || $_POST['globalpass'] != get_setting('globalpass'))) {
		send_error(_('Wrong global Password!'));
	} elseif (!isset($_POST['nick']) || !isset($_POST['pass'])) {
		send_login();
	} else {
		if ($GuestAccess === 4) {
			send_chat_disabled();
		}
		if (!empty($_POST['regpass']) && $_POST['regpass'] !== $_POST['pass']) {
			send_error(_('Password confirmation does not match!'));
		}
		create_session(false, $_POST['nick'], $_POST['pass']);
		if (!empty($_POST['regpass'])) {
			$guestreg	= (int) get_setting('guestreg');
			if ($guestreg === 1) {
				register_guest(2, $_POST['nick']);
				$U['status'] = 2;
			} elseif ($guestreg === 2) {
				register_guest(3, $_POST['nick']);
				$U['status'] = 3;
			}
		}
	}
	if (isset($U['status'])) {
		if ($U['status'] == 1) {
			if (in_array($GuestAccess, [2, 3], true)) {
				send_waiting_room();
			}
		}
	}
}

function check_captcha (string $challenge, string $captcha_code) : void
{
	global $dbo, $memcached;

	$captcha	= (int) get_setting('captcha');
	if ($captcha !== 0) {
		if (empty($challenge)) {
			send_error(_('Wrong Captcha'));
		}
		$code = '';
		if (MEMCACHED) {
			if (!$code=$memcached->get(DBNAME . '-' . PREFIX . "captcha-$_POST[challenge]")) {
				send_error(_('Captcha already used or timed out.'));
			}
			$memcached->delete(DBNAME . '-' . PREFIX . "captcha-$_POST[challenge]");
		} else {
			$stmt	= $dbo->prepare('SELECT code FROM ' . PREFIX . 'captcha WHERE id=?;');
			$stmt->execute([$challenge]);
			$stmt->bindColumn(1, $code);
			if (!$stmt->fetch(PDO::FETCH_BOUND)) {
				send_error(_('Captcha already used or timed out.'));
			}
			$time	= time();
			$stmt	= $dbo->prepare('DELETE FROM ' . PREFIX . 'captcha WHERE id=? OR time<(?-(SELECT value FROM ' . PREFIX . "settings WHERE setting='captchatime'));");
			$stmt->execute([$challenge, $time]);
		}
		if ($captcha_code !== $code) {
			if ($captcha !== 3 || strrev($captcha_code) !== $code) {
				send_error(_('Wrong Captcha'));
			}
		}
	}
}

function print_nowchatting () : string
{
	global $dbo;

	$sResult	 = '';

	parse_sessions();
	$stmt	= $dbo->query('SELECT COUNT(*) FROM ' . PREFIX . 'sessions WHERE entry != 0 AND status > 0 AND incognito = 0;');
	$count	= $stmt->fetch(PDO::FETCH_NUM);
	$sResult		 = '<div id="chatters">'.sprintf(_('Currently %d chatter(s) in room:'), $count[0]).'<br>';
	if (!get_setting('hidechatters')) {
		$stmt	= $dbo->query('SELECT nickname, style FROM ' . PREFIX . 'sessions WHERE entry!=0 AND status>0 AND incognito=0 ORDER BY status DESC, lastpost DESC;');
		while ($user	 = $stmt->fetch(PDO::FETCH_NUM)) {
			$sResult	.= style_this(htmlspecialchars($user[0]), $user[1]).' &nbsp; ';
		}
	}
	$sResult	.= '</div>';

	return $sResult;
}

?>