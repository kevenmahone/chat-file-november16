<?php
/*
* LE CHAT-PHP - a PHP Chat based on LE CHAT - Main program
*
* Copyright (C) 2015-2021 Daniel Winzen <daniel@danwin1210.me>
*
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/*
* status codes
* 0 - Kicked/Banned
* 1 - Guest
* 2 - Applicant
* 3 - Member
* 4 - System message
* 5 - Moderator	
* 6 - Super-Moderator
* 7 - Admin
* 8 - Super-Admin
* 9 - Private messages
*/





// Rate Limiting - Limits requests per minute for each user
session_start();

// Define the maximum number of requests per minute
define('MAX_REQUESTS_PER_MINUTE', 20);
define('TIME_WINDOW', 60); // 60 seconds

// Initialize request tracking in session if not already done
if (!isset($_SESSION['request_times'])) {
    $_SESSION['request_times'] = [];
}

// Get the current time
$current_time = time();

// Filter out timestamps that are outside the time window (older than 60 seconds)
$_SESSION['request_times'] = array_filter($_SESSION['request_times'], function($timestamp) use ($current_time) {
    return ($current_time - $timestamp) <= TIME_WINDOW;
});

// Check if the user has exceeded the limit
if (count($_SESSION['request_times']) >= MAX_REQUESTS_PER_MINUTE) {
    // Too many requests, deny the request
    die('Rate limit exceeded. Please try again in 60 second..');
}

// Otherwise, proceed with the chat logic
// Add the current request time to the session
$_SESSION['request_times'][] = $current_time;






if (!file_exists(dirname(__FILE__).'/core/chat-conf.php')) {
	echo 'Please copy /core/chat-conf.default.php to /core/chat-conf.php and edit /core/chat-conf.php to add the connexion infos to access your bdd.';
	return;
}

if (!is_writable('./temp')) {
    echo 'Please check out if you have created /temp folder and if it is writable from the script ( sudo chmod -R 777 ./temp from your script root)';
	return;
}

define("IN_MYBB", 1);
define('THIS_SCRIPT', 'chat.php');

require_once dirname(__FILE__).'/modules/helpers.php';

require_once dirname(__FILE__).'/core/config.php';
require_once dirname(__FILE__).'/core/update_db.php';
require_once dirname(__FILE__).'/core/cron.php';

require_once dirname(__FILE__).'/modules/interface.php';
require_once dirname(__FILE__).'/modules/conversation.php';
require_once dirname(__FILE__).'/modules/msgreference.php';
require_once dirname(__FILE__).'/modules/inline.php';
require_once dirname(__FILE__).'/modules/login.php';
require_once dirname(__FILE__).'/modules/members.php';
require_once dirname(__FILE__).'/modules/lastseen.php';
require_once dirname(__FILE__).'/modules/msgfilter.php';
require_once dirname(__FILE__).'/modules/chatters.php';
require_once dirname(__FILE__).'/modules/profile.php';
require_once dirname(__FILE__).'/modules/admin.php';
require_once dirname(__FILE__).'/modules/setup.php';
require_once dirname(__FILE__).'/modules/notes.php';
require_once dirname(__FILE__).'/modules/help.php';
require_once dirname(__FILE__).'/modules/backup.php';
require_once dirname(__FILE__).'/modules/filters.php';
require_once dirname(__FILE__).'/modules/sessions.php';
require_once dirname(__FILE__).'/modules/smileys.php';
require_once dirname(__FILE__).'/modules/post.php';
require_once dirname(__FILE__).'/modules/controls.php';
require_once dirname(__FILE__).'/modules/tags.php';
//MPYGERrequire_once dirname(__FILE__).'/modules/gallery.php';
require_once dirname(__FILE__).'/modules/rooms.php';
require_once dirname(__FILE__).'/modules/messagesqry.php';
require_once dirname(__FILE__).'/modules/messages.php';
require_once dirname(dirname(__FILE__)).'/global.php';

define('RESET_SUPERADMIN_PASSWORD', ''); 			//comment this line and uncomment next to reset superadmin password
//define('RESET_SUPERADMIN_PASSWORD', 'changeme');	//Use this to reset your superadmin password in case you forgot it

// initialize and load variables/configuration
const LANGUAGES = [
	'ar' 		=> ['name' => 'العربية', 'locale' => 'ar', 'dir' => 'rtl'],
	'bg' 		=> ['name' => 'Български', 'locale' => 'bg_BG', 'dir' => 'ltr'],
	'cs' 		=> ['name' => 'čeština', 'locale' => 'cs_CZ', 'dir' => 'ltr'],
	'de' 		=> ['name' => 'Deutsch', 'locale' => 'de_DE', 'dir' => 'ltr'],
	'en' 		=> ['name' => 'English', 'locale' => 'en_GB', 'dir' => 'ltr'],
	'es' 		=> ['name' => 'Español', 'locale' => 'es_ES', 'dir' => 'ltr'],
	'fi' 		=> ['name' => 'Suomi', 'locale' => 'fi_FI', 'dir' => 'ltr'],
	'fr' 		=> ['name' => 'Français', 'locale' => 'fr_FR', 'dir' => 'ltr'],
	'id' 		=> ['name' => 'Bahasa Indonesia', 'locale' => 'id_ID', 'dir' => 'ltr'],
	'it' 		=> ['name' => 'Italiano', 'locale' => 'it_IT', 'dir' => 'ltr'],
	'pt' 		=> ['name' => 'Português', 'locale' => 'pt_PT', 'dir' => 'ltr'],
	'ru' 		=> ['name' => 'Русский', 'locale' => 'ru_RU', 'dir' => 'ltr'],
	'tr' 		=> ['name' => 'Türkçe', 'locale' => 'tr_TR', 'dir' => 'ltr'],
	'uk' 		=> ['name' => 'Українська', 'locale' => 'uk_UA', 'dir' => 'ltr'],
	'zh-Hans' 	=> ['name' => '简体中文', 'locale' => 'zh_CN', 'dir' => 'ltr'],
	'zh-Hant' 	=> ['name' => '正體中文', 'locale' => 'zh_TW', 'dir' => 'ltr'],
];
load_config();
$U            = [];									// This user data
$dbo; 												// = null;// Database connection
$nocache;											// random value to avoid browser use a cached page
$memcached; 										// = null;// Memcached connection
$chat_language     = LANG;								// user selected language
$locale       = LANGUAGES[LANG]['locale'];			// user selected locale
$chat_dir          = LANGUAGES[LANG]['dir'];				// user selected language direction
$chat_scripts      = []; 								// js enhancements
$styles       = []; 								// css styles
$chat_session      = $_REQUEST['session'] ?? ''; 		//requested session

// set session variable to cookie if cookies are enabled
if (!isset($_REQUEST['session']) && isset($_COOKIE[COOKIENAME])) {
	$chat_session = $_COOKIE[COOKIENAME];
}
$chat_session = preg_replace('/[^0-9a-zA-Z]/', '', $chat_session);

load_lang();
check_db();
	//Logout from mybb IF Timeout Arrived
	global $dbo,$mybb,$db,$session;

	if(!isPOST() && $mybb->user["uid"] > 0)
	{

		$GuestTimeout	 = time() - 60 * get_setting('guestexpire');
		$MemberTimeout	 = time() - 60 * get_setting('memberexpire');
		$tm_q	= $dbo->query("SELECT COUNT(id) FROM ".PREFIX."sessions WHERE nickname = '{$mybb->user["username"]}' AND (( status <= 2 AND lastpost < '{$GuestTimeout}') OR (status > 2 AND lastpost < '{$MemberTimeout}' ));");
		$tm_count	= $tm_q->fetch(PDO::FETCH_NUM);
		
		if($tm_count[0] > 0)
		{
		$stmt = $dbo->prepare('DELETE FROM ' . PREFIX . 'sessions WHERE nickname=? ;');
		$stmt->execute([$mybb->user["username"]]);
		my_unsetcookie("mybbuser");
		my_unsetcookie("sid");

		if($mybb->user['uid'])
		{
			$time = TIME_NOW;
			// Run this after the shutdown query from session system
			$db->shutdown_query("UPDATE ".TABLE_PREFIX."users SET lastvisit='{$time}', lastactive='{$time}' WHERE uid='{$mybb->user['uid']}'");
			//$db->delete_query("sessions", "sid = '{$session->sid}'");
		}
		setcookie(COOKIENAME, false);
		$chat_session = '';
		send_error(_('Hello, your session has expired. Please log in again to continue'));
		}
		//Logout from mybb IF Timeout Arrived
	}

cron();
route();

//MYPGR

		
function check_is_mybbuser($is_home = true)
{

	global $dbo,$U,$mybb,$db,$session,$chat_session;

	
	if($mybb->user['uid'] > 0 && 
	$mybb->settings['km_csp_vgroups'] == "-1" || ($mybb->settings['km_csp_vgroups'] != "" && in_array($mybb->user['usergroup'],explode(",",$mybb->settings['km_csp_vgroups'])))) 
	{

		//Check User
			$stmt	= $dbo->query("SELECT COUNT(id) FROM " . PREFIX . "members WHERE nickname = '{$mybb->user['username']}';");
			$count	= $stmt->fetch(PDO::FETCH_NUM);
			//Register User If not Exist
			if($count[0] <= 0)
			{
				switch($mybb->user['usergroup'])
				{
					case 4 :
					$status = 9; //Senior admin
					break;
					case 3 :
					$status = 8;//Admin
					break;
					case 6 :
					$status = 5;//Moderatror
					break;
					case 8 :
					$status = 3;//Member
					break;
					default :
					$status = 3;//Member
					
				}

				$pass = md5(time());
				
					$reg = [
						'nickname'	    => $mybb->user['username'],
						'passhash'	    => password_hash($pass, PASSWORD_DEFAULT),
						'status'	    => $status,
						'refresh'	    => get_setting('defaultrefresh'),
						'bgcolour'	    => get_setting('colbg'),
						'regedby'	    => "Owner",
						'regedwhen'     => time(),
						'lastlogin'		=> time(),
						'timestamps'	=> get_setting('timestamps'),
						'style'		    => 'color:#'.get_setting('coltxt').';',
						'embed'		    => 1,
						'incognito'	    => 0,
						'conv_mode'		=> 0,
						'nocache'	    => 0,
						'nocache_old'	=> 1,
						'tz'		    => get_setting('defaulttz'),
						'eninbox'	    => 0,
						'sortupdown'	=> get_setting('sortupdown'),
						'hidechatters'	=> 0,
						'hide_sysmess'  => get_setting('hide_sys_mess'),
					];
					$iuq = $dbo->prepare('INSERT INTO ' . PREFIX . 'members (nickname, passhash, status, refresh, bgcolour, regedby, regedwhen, lastlogin, timestamps, style, embed, incognito, conv_mode, nocache, tz, eninbox, sortupdown, hidechatters, nocache_old) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);');
					$iuq->execute([$reg['nickname'], $reg['passhash'], $reg['status'], $reg['refresh'], $reg['bgcolour'], $reg['regedby'], $reg['regedwhen'], $reg['lastlogin'], $reg['timestamps'], $reg['style'], $reg['embed'], $reg['incognito'], $reg['conv_mode'], $reg['nocache'], $reg['tz'], $reg['eninbox'], $reg['sortupdown'], $reg['hidechatters'], $reg['nocache_old']]);

			}
			//Register User If not Exist

				$query = $dbo->prepare('SELECT * FROM ' . PREFIX . 'members WHERE nickname = ?;');
				$query->execute([$mybb->user['username']]);
				if($row = $query->fetch(PDO::FETCH_ASSOC)){
					$U = $row;
				}
			
				$useragent	= isset($_SERVER['HTTP_USER_AGENT'])?htmlspecialchars($_SERVER['HTTP_USER_AGENT']):'';
				
				$ip = (get_setting('trackip')) ? $_SERVER['REMOTE_ADDR']:'';
				$U['useragent'] = $useragent;
				$U['ip'] = $ip;
				$U['roomid'] = null;

		

				switch($mybb->user['usergroup'])
				{
					case 4 :
					$U['status'] = 9; //Senior admin
					break;
					case 3 :
					$U['status'] = 8;//Admin
					break;
					case 6 :
					$U['status'] = 5;//Moderatror
					break;
					case 8 :
					$U['status'] = 3;//Member
					break;
					default :
					$U['status'] = 3;//Member
					
				}

				//Login
				$scq	= $dbo->query("SELECT COUNT(id) FROM ".PREFIX."sessions WHERE nickname = '{$mybb->user['username']}';");
				$scount	= $scq->fetch(PDO::FETCH_NUM);

				if((int)$scount[0] == 0)
				{
					$chat_session = bin2hex(random_bytes(16));
					$U['session'] = $chat_session;
					$U['entry'] = $U['lastpost'] = time();
					try {
					$U['postid'] = bin2hex(random_bytes(3));
					} catch(Exception $e) {
					$U['postid'] = substr(time(), -6);
					}
					$stmt = $dbo->prepare('INSERT INTO ' . PREFIX . 'sessions (session, nickname, status, refresh, style, lastpost, passhash, useragent, bgcolour, entry, timestamps, embed, incognito, ip, nocache, tz, eninbox, sortupdown, hidechatters, conv_mode, hide_sysmess, user_entry, user_exit, user_caption, nocache_old, postid) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);');
					$stmt->execute([$U['session'], $mybb->user['username'], $U['status'], $U['refresh'], $U['style'], $U['lastpost'], "6pZ7bOftS0IRtsrM4LBNFfI49poAaczn", $useragent, $U['bgcolour'], $U['entry'], $U['timestamps'], $U['embed'], $U['incognito'], $ip, $U['nocache'], $U['tz'], $U['eninbox'], $U['sortupdown'], $U['hidechatters'], $U['conv_mode'], $U['hide_sysmess'], $U['user_entry'], $U['user_exit'], $U['user_caption'], $U['nocache_old'], $U['postid']]);
					
					//Update Last login
						$stmt = $dbo->prepare('UPDATE ' . PREFIX . 'members SET lastlogin=? WHERE nickname=?;');
						$stmt->execute([time(), $mybb->user['username']]);

					if (get_setting('hide_sys_mess'))
					{
						if((int)$U['hide_sysmess']){
							
							$sys_mess = 0;
						} else {
							$sys_mess = 1;
							
						}
					}
					if (get_setting('user_sys_mess')) {
						if (!empty($U['user_entry'])) {
							$EnterMess =  stripslashes($U['user_entry']);
						}
					}
					$EnterMess	 = get_setting('msgenter');
							if (get_setting('user_sys_mess')) {
						if (!empty($U['user_entry'])) {
							$EnterMess =  stripslashes($U['user_entry']);
						}
					}
		
						if ($U['status'] >= 3 && !$U['incognito']) {		

						if ($sys_mess == 1) {		

							$nncc = '';
							if ($nicktags) {
								$lang = '&lang=' . $chat_language;
								if (!empty($nocache)) {
									$nncc = '&nc=' . $nocache;
								}
								$nick = '&nickname='.$U['nickname'];
								$send = '&sendto=' . $SendTo;
								$nicklink   = '<a class="nicklink" href="'.$_SERVER['SCRIPT_NAME'].'?action=post'. $lang . $nncc . $nick . $send.'" target="post" >'. style_this(htmlspecialchars($U['nickname']), $U['style']) .'</a>';
								add_system_message(sprintf($EnterMess, $nicklink), '');
							} else {
								add_system_message(sprintf($EnterMess, style_this(htmlspecialchars($U['nickname']), $U['style'])), '');
							}	
						}
					}
					
				}
				else
				{
					$squery = $dbo->prepare('SELECT session,entry,lastpost,postid,kickmessage,status FROM ' . PREFIX . 'sessions WHERE nickname = ?;');
					$squery->execute([$mybb->user['username']]);
					if($srow = $squery->fetch(PDO::FETCH_ASSOC))
					{
						if ($srow['status'] == 0) 
						{
						    setcookie(COOKIENAME, false);
							$chat_session = '';

							if($is_home)
							{
							redirect($mybb->settings['bburl'] ."/index.php", 'You have been kicked!'.'<br>'.$U['kickmessage']);
							}
							else
							{
							send_error(_('You have been kicked!') . '<br>'.$U['kickmessage']);
	
							}
						}
					$U['session'] = $srow['session'];
					$chat_session = $U['session'];
					$U['entry'] = $srow['entry'];
					$U['lastpost'] = $srow['lastpost'];
					$U['postid'] = $srow['postid'];
					$U['kickmessage'] = $srow['kickmessage'];
					}

					$stmt= $dbo->prepare('UPDATE ' . PREFIX . 'sessions SET session = ?,nickname = ?,status = ?,refresh = ?,style = ?,lastpost = ?,passhash = ?,useragent = ?,bgcolour = ?,entry = ?,timestamps = ?,embed = ? ,incognito = ? , ip = ? , nocache = ? , tz = ? , eninbox = ? , sortupdown = ? , hidechatters = ? , conv_mode = ? , hide_sysmess = ? , user_entry = ? , user_exit = ? , user_caption = ? , nocache_old = ? , postid = ? WHERE nickname = ?');
					$stmt->execute([$U['session'], $mybb->user['username'], $U['status'], $U['refresh'], $U['style'], $U['lastpost'], "6pZ7bOftS0IRtsrM4LBNFfI49poAaczn", $useragent, $U['bgcolour'], $U['entry'], $U['timestamps'], $U['embed'], $U['incognito'], $ip, $U['nocache'], $U['tz'], $U['eninbox'], $U['sortupdown'], $U['hidechatters'], $U['conv_mode'], $U['hide_sysmess'], $U['user_entry'], $U['user_exit'], $U['user_caption'], $U['nocache_old'], $U['postid'],$mybb->user['username']]);
				}
			
		//Check User
		$query	= $dbo->query("SELECT COUNT(id) FROM ".PREFIX."sessions WHERE session = '{$U['session']}' AND nickname = '{$mybb->user["username"]}' AND status >=3 AND passhash = '6pZ7bOftS0IRtsrM4LBNFfI49poAaczn';");
		$count	= $query->fetch(PDO::FETCH_NUM);
		if($count[0] > 0)
		{

		set_secure_cookie(COOKIENAME, $U['session']);
		//$remove = ['regedby','regedwhen','lastlogin','lastlogout','loginfails','user_intro','user_avatar'];
		//$U = array_diff_key($U, array_flip($remove));
			if($is_home)
			{
			send_frameset();
			}
		}
		else
		{
		if($is_home)
		{
			send_redirect($mybb->settings['bburl']."/member.php?action=login");
		}
		else
		{
		setcookie(COOKIENAME, false);
		$chat_session = '';
		send_error(_('Hello, your session has expired. Please log in again to continue'));
		}
		}
	}
	else
	{
		if($is_home)
		{
			send_redirect($mybb->settings['bburl']."/member.php?action=login");
		}
		else
		{
		setcookie(COOKIENAME, false);
		$chat_session = '';
		send_error(_('Hello, your session has expired. Please log in again to continue'));
		}
	}
	

	
	
}

//MYPGR
//  main program: decide what to do based on queries
function route () : void
{
	global $U;
	if (!isset($_REQUEST['action'])) {
		check_is_mybbuser();
		//send_login();
	} elseif ($_REQUEST['action'] === 'view') {
		check_session();
		//Modification chat rooms
		if (isset($_REQUEST['room'])) {
			$switch = change_room();
			if ($switch == '') {
				check_session();
			} else {
				rooms($switch);
			}
		}
		send_messages();
	} elseif ($_REQUEST['action'] === 'conv') {
		check_session();
		$filter = '';
		if (isset($_POST['filter'])) {
			$filter		 = $_POST['filter'];
		} elseif (isset($_REQUEST['filter'])) {
			$filter		 = $_REQUEST['filter'];
		}
		if ($U['nickname'] == $filter) {
			$filter 	 = '';
		}
		if (!empty($filter)) {
			if (isset($_POST['save'])) {
				save_conversation ($filter);
				send_post();
				return;
			} 
		} 
		send_frameset($filter);

	} elseif ($_REQUEST['action'] === 'redirect' && !empty($_GET['url'])) {
		send_redirect($_GET['url']);
	} elseif ($_REQUEST['action'] === 'rooms') {
        check_session();
        rooms();
	} elseif ($_REQUEST['action'] === 'wait') {
		parse_sessions();
		send_waiting_room();
	} elseif ($_REQUEST['action'] === 'post') {
		check_session();
		if (isset($_POST['kick']) && isset($_POST['sendto']) && $_POST['sendto'] !== 's _') {
			if ($U['status'] >=5 || ($U['status'] >=3 && (get_setting('memkickalways') || (get_mods_count() == 0 && get_setting('memkick'))))) {
				if (isset($_POST['what']) && $_POST['what'] === 'purge') {
					kick_chatter([$_POST['sendto']], $_POST['message'], true);
				} else {
					kick_chatter([$_POST['sendto']], $_POST['message'], false);
				}
			}
		} elseif (isset($_POST['message']) && isset($_POST['sendto']) ) {
			send_post(validate_input());
		}
		send_post();
	} elseif ($_REQUEST['action'] === 'login' && isPOST()) {
		check_login();
		show_fails();
		send_frameset();
	} elseif ($_REQUEST['action'] === 'controls') {
		check_session();
		send_controls();
	} elseif ($_REQUEST['action'] === 'greeting') {
		check_session();
		send_greeting();
	} elseif ($_REQUEST['action'] === 'delete' && isPOST()) {
		check_session();
		if (!isset($_POST['what'])) {
			// i dont what to delete .. so i delete nothing
		} elseif ($_POST['what'] === 'conv') {
			if (isset($_POST['filter'])) {
				if (isset($_POST['confirm'])) {
					del_conv_messages( $_POST['filter'] );
				} else {
					send_del_confirm();
				}
			}
		} elseif ($_POST['what'] === 'all') {
			if (isset($_POST['confirm'])) {
				del_all_messages('', (int) ($U['status'] == 1 ? $U['entry'] : 0));
			} else {
				send_del_confirm();
			}
		} elseif ($_POST['what'] === 'last') {
			del_last_message();
		}
		send_post();
	} elseif ($_REQUEST['action'] === 'profile' && isPOST()) {
		check_session();
		$arg = '';
		if (!isset($_POST['do'])) {
		} elseif ($_POST['do'] === 'save') {
			$arg = save_profile();
		} elseif ($_POST['do'] === 'delete') {
			if (isset($_POST['confirm'])) {
				delete_account();
			} else {
				send_delete_account();
			}
		}
		send_profile($arg);
	} elseif ($_REQUEST['action'] === 'logout' && isPOST()) {
		global $mybb;
		kill_session();
		send_redirect($mybb->settings['bburl'] . "/member.php?action=logout&logoutkey={$mybb->user['logoutkey']}");
		//send_logout();
	} elseif ($_REQUEST['action'] === 'colours') {
		check_session();
		send_colours();
	} elseif ($_REQUEST['action'] === 'notes' & isPOST()) {
		check_session();
		if (!isset($_POST['do'])) {
		} elseif ($_POST['do'] === 'admin'  && $U['status'] >  6) {
			send_notes(0);
		} elseif ($_POST['do'] === 'staff'  && $U['status'] >= 5) {
			send_notes(1);
		} elseif ($_POST['do'] === 'public' && $U['status'] >= 3) {
			send_notes(3);
		}
		if ($U['status'] < 3 || (!get_setting('personalnotes') && !get_setting('publicnotes'))) {
			send_access_denied();
		}
		send_notes(2);
	} elseif ($_REQUEST['action'] === 'smiley') {
		check_session();
		send_smiley();
	} elseif ($_REQUEST['action'] === 'help') {
		check_session();
		send_help();
	} elseif ($_REQUEST['action'] === 'phelp') {
		check_session();
		send_post_help();
	} elseif ($_REQUEST['action'] === 'news') {
		check_session();
		send_news();
	} elseif ($_REQUEST['action'] === 'links') {
		check_session();
		send_links();
	} elseif ($_REQUEST['action'] === 'rules') {
		check_session();
		send_rules();
	} elseif ($_REQUEST['action'] === 'viewpublicnotes') {
		check_session();
		view_publicnotes();
	} elseif ($_REQUEST['action'] === 'inbox' && isPOST()) {
		check_session();
		if(isset($_POST['do'])){
			clean_inbox_selected();
		}
		send_inbox();
	} elseif ($_REQUEST['action'] === 'download') {
		send_download();
	} elseif ($_REQUEST['action'] === 'admin' && isPOST()) {
		check_session();
		send_admin(route_admin());
	} elseif ($_REQUEST['action'] === 'gallery') {
		check_session();
  		if (!isset($_REQUEST['do'])) {
	  		send_gallery();
  		} else {
			send_gallery($_REQUEST['do']);
		}
	} elseif ($_REQUEST['action'] === 'inline' && isPOST()) {
		check_session();
		route_inline();
	} elseif ($_REQUEST['action'] === 'gal_inline' && isPOST()) {
		check_session();
		route_gallery_inline();
	} elseif ($_REQUEST['action'] === 'setup' && isPOST()) {
		route_setup();
	} elseif ($_REQUEST['action'] === 'sa_password_reset') {
		send_sa_password_reset();
	} else {
		check_is_mybbuser();
		//send_login();
	}
}

function isPOST () {
    return $_SERVER['REQUEST_METHOD'] === 'POST';
}
