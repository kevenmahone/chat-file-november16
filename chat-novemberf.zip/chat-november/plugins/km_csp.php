<?php
/*
*
* Custom Scripts Plugin
* Copyright 2023 Mostafa Shiraali
* No one is authorized to redistribute or remove copyright without my expressed permission.
* No one is authorized to share this plugin with other.
* Only those who purchased this plugin are allowed to use it.
* Ways to buy this plugin or order a new plugin
* Telegram : @MostafaShiraali
* Discord : MostafaShiraali#7754
* Email : mr.m.shiraali@gmail.com
*/

	define("CHAT_PATH",'chat');
	define("SECRET_KEY","98329832895932898325");//Do not change without Programmer advise

	if(!defined("IN_MYBB"))
	{
	die("Direct initialization of this file is not allowed.<br /><br />Please make sure IN_MYBB is defined.");
	}

	if(defined('IN_ADMINCP'))
	{
		//...
	}
	else
	{
		
		$plugins->add_hook('member_do_login_end', 'km_csp_member_do_login_end');

		//...
	}
	
	function km_csp_info()
	{
		global $mybb, $db;

		return [
		"name" => "Custom Scripts",
		"description" => "Custom Scripts",
		"website" => "https://t.me/MostafaShiraali",
		"author" => "Mostafa Shiraali",
		"authorsite" => "https://t.me/MostafaShiraali",
		"version" => "1.0",
		"guid"=> "##7##km_csp##7##",
		"compatibility"	=> "*"
		];
	}

	function km_csp_activate()
	{
		global $mybb, $db;
		$gid = $db->insert_query("settinggroups", ["name" => "km_csp","title" => "Custom Scripts","description" => "Setting For Custom Scripts","disporder" => "88","isdefault" => "0"]);
		$settings = [
			["name" => "km_csp_vgroups","title" => "Valid Groups","description" => "Select user groups that can access to chat page","optionscode" => "groupselect","value" => -1,"disporder" => 1,"gid" => intval($gid)],
		];
	$db->insert_query_multiple("settings", $settings);
    rebuild_settings();
	
	}
	function km_csp_deactivate()
	{
		global $mybb, $db;
		$db->delete_query("settinggroups","name LIKE 'km_csp%'");
		$db->delete_query("settings","name LIKE 'km_csp_%'");
		rebuild_settings();
	}

	function km_csp_member_do_login_end()
	{
		global $mybb, $db;
		if(strpos($mybb->input['url'],'/' . CHAT_PATH . '/') !== false)
		{
			$mybb->input['url'] = $mybb->settings['bburl'] . '/' . CHAT_PATH . '/' . 'chat.php';
		}

	}


	

